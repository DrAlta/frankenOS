Here is the unofficial software update TESTED for T1 and T2 owners!
... this should also work for T3 owners, as well as Zire 71/72 and T/E.

You really should PRINT this file.

I've tried to be MINIMALIST on all the files.  The original T3 -> T5 update
really included EVERYTHING for the T3.  This, more generic file set, will
work on all other machines that run OS5, but is not as complete as the one
from Czo.

Also, some files have been modified so that they can be hot-synced, and will
be backed-up so that if you hard-reset the handheld, they will 'return' when
you hot-sync again.

This includes all the PIM files, as well as the Calculator files and the GRAFFITI
files ... yes, the GRAFFITI files are now hot-syncable :-)

The apps I use on my T1 have been marked with a star *

Of course, thanks to Czo, for his amazing original T3 -> T5 "update"...


This package includes:

About_T5        ----------  Makes the PIMs Options/About screen look like the T5 one.
                            Really pretty pointless, but cute.

Calc_T3         ----------  The T3 calculator for the Tungsten T or Zire 71.
Calc_T5       * ----------  The T5 calculator for any earlier handheld.
CardExport      ----------  Drive Mode from the T5 doesn't work, so use this instead.
                            There is an included key generator that runs under Windows
                            in the directory.

Docs2Go_hack  * ----------  Docs to Go 7 editors, minus stupid Pics to Go, plus the old
                            D2G version 6 FAST interface.
                            Launch WordToGo, and register with the included D2G7 registration.
                               Registration number: 7221760-8050
                               Activation key: 0032-QE00EQ5F48D8
                            Now, exit Word2Go, and in the interface app, select register, and
                            you will be magically registered under version 6 as well.

Favorites_T5  * ----------  The new T5 favorites app for any earlier handheld.
Files_T5      * ----------  The new T5 files application for any earlier handheld.
Graffiti_T1   * ----------  Installs the original graffiti (from the T1) for any newer handheld.
Launcher_T5   * ----------  The new T5 launcher for any earlier handheld.

Media_T5      * ----------  The new T5 Media (pictures) app for any earlier handheld.
                            This includes additional support files which I've determined
                            are absolutely necessary for it to work.  This will allow the
                            T5 Favorites, T5 Launcher, and T5 Calender applications to change
                            the background to ANY image. 
                            Because this came from a machine that has a newer processor, the 
                            video playing abilities cannot be used.
                            For some unknown reason, you cannot use draw on picture.

PIM_Addr_T3   * ----------  The T3 AddressBook replacement (Contacts) for the T1, T2, Zire 71...
                            The T5 version is slower, harder on memory, and the only appreciable
                            new feature is the ability to add pictures to records.
                            I didnt think it was worth it.

PIM_Cal_T3      ----------  The T3 DateBook replacement (Calendar) for the T1, T2, Zire 71, etc.
                            It is lighter on memory than the T5 version, but you cannot change
                            the background from the funky (but cool) blue shade.

PIM_Cal_T5    * ----------  The T5 DateBook replacement (Calendar) for all previous handhelds.
                            This includes additional support files which MUST be installed in
                            order for it to work.  On the T1 and Zire 71, you will want to use
                            JackSprat to remove the old WorldClock.  If you don't, you will have
                            TWO world-clocks, one of which will reset the handheld (the old one).
                            You can also just move the old WorldClock to the "unfiled" category.
                            THis doesn't happen on any other handheld.
                          * Note: The PIM_Cal_T5 files MUST NOT BE STORED IN FLASH using JackFlash!
                            Everthing works fine if you hot-sync them over, or copy them over.
                            If you put the ones that you can into FLASH, and then try to hard-reset
                            the device, the palmOS will fail to boot and you will be stuck!

PIM_Memo_T3  * -----------  The T3 Memo Pad replacement (Memos) for the T1, T2, Zire 71, etc.
                            It is the same as the one off the T5, but doesn't need special files.

PIM_Sup_T5   * -----------  If you use ANY of the new PIMs, you MUST install these two files
                            for HotSync to work.

PIM_Task_T3  * -----------  The T3 To Do replacement (Tasks) for the T1, T2, Zire 71, etc.
                            It is identical to the version from the T5.

RealPlay_T5  * -----------  T5 RealPlayer application for previous handhelds.
                          * Note: On my T2, the BackgroundPlay messes up the display in the Launcher
                            when a background image is enabled.  This DOESNT happen on my T1.
                            Nevertheless, I suggest disabling background play on any device, or
                            disabling the background image if you must use bacground play.

TouchScreen_T5 -----------  The cool TouchScreen Preference Panel app from the T5, replaces Digitizer.
                            Seems to work the same, except if you use JackSafe (from JackFlash) in which
                            case it acts a BIT flacky, but causes no problems.


FAQ
- What about the missing stuff?
        Look for the original T3 -> T5 update if you MUST, but if you use my version, and install the stuff I've
        marked with a star, you will use 5.5MB on your T1.  I doubt you want to spend more than that on a device
        with just 14MB of available RAM.
        
        Trust me, you've got ALMOST everything from the T5!  If you bought one now, you would be disappointed.

- How can I install it?
	The PIMs, calculator and Graffiti "downgrade" have been patched so that they can be double-cliced, and 
        installed via hot-sync.  CardExport can be installed via hotsync, and so can the Docs2Go Hack.

        You should still reset the device afterwards, particularly if you put in the PIMs.

        Other than that, copy the needed stuff on a memory card, then copy them into the machine's memory using
        CardExport to get the files on the card, and the included McFile to move them to the handheld.
        If it asks about owerwriting something, you can safely say Yes.

	Pictures must be copy to card's DCIM folder, or installed with hotsync.
    
- Do I have to install the whole package?
        No, they can be installed separately.  I have carefully weeded out most dependancies.  However, please be
        aware that Launcher_T5, Calendar_T5, and Favorites_T5 require Media_T5 (or Pictures on SOME earlier handhelds)
        in order to allow you to change the background pictures.
    
- Are there any problems with the packages?
        The only problem I've had is background playback on my T2.  It messes up the background image, and requires
        a reset.  It doesnt happen on the T1.

Enjoy !
-Laz