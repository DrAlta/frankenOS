//
//

//	Resource: tFRM 1100
#define MainForm                                  1100	//(Left Origin = 0, Top Origin = 0, Width = 160, Height = 160, Usable = 1, Modal = 0, Save Behind = 0, Help ID = 0, Menu Bar ID = 0, Default Button ID = 0)
#define MainGetButton                             1103	//(Left Origin = 5, Top Origin = 52, Width = 36, Height = 12, Usable = 1, Anchor Left = 1, Frame = 1, Non-bold Frame = 1, Font = Standard)
#define MainPostButton                            1105	//(Left Origin = 5, Top Origin = 137, Width = 36, Height = 12, Usable = 1, Anchor Left = 1, Frame = 1, Non-bold Frame = 1, Font = Standard)
#define MainURLField                              1101	//(Left Origin = 5, Top Origin = 35, Width = 150, Height = 12, Usable = 1, Editable = 1, Underline = 1, Single Line = 0, Dynamic Size = 0, Left Justified = 1, Max Characters = 255, Font = Standard, Auto Shift = 1, Has Scroll Bar = 0, Numeric = 0)
#define MainPostDataField                         1104	//(Left Origin = 5, Top Origin = 69, Width = 135, Height = 60, Usable = 1, Editable = 1, Underline = 1, Single Line = 0, Dynamic Size = 0, Left Justified = 1, Max Characters = 80, Font = Standard, Auto Shift = 0, Has Scroll Bar = 0, Numeric = 0)
#define MainResultDataField                       1106	//(Left Origin = 5, Top Origin = 69, Width = 135, Height = 60, Usable = 1, Editable = 1, Underline = 1, Single Line = 0, Dynamic Size = 0, Left Justified = 1, Max Characters = 80, Font = Standard, Auto Shift = 0, Has Scroll Bar = 0, Numeric = 0)
#define resMainResultDataScrollerID								1107
#define MainURLLabel                              1102	//(Left Origin = 5, Top Origin = 20, Usable = 1, Font = Standard)
//Accept-Encoding popup
#define rscMainAcceptEncodeList										1110
#define rscMainAcceptEncodePopTrigger							1111
//# iterations popup
#define rscMainRepeatList													1112
#define rscMainRepeatListPopTrigger								1113
// dormancy popup
#define rscMainDormancyList												1114
#define rscMainDormancyListPopTrigger							1115

#define NetworkSignalGadget				1040
#define NetworkBatteryGadget			1041


// Rsource Wait Dialog
#define rscWaitFormID															2000
#define rscWaitViewLabelID												2001


// MENU
#define rscMainFormMenuBarID											1300
#define rscMainViewCptCmd													1302
#define rscMainViewGenericCmd											1303
#define rscMainViewClearCmd												1304
#define rscMainViewSaveMemoCmd										1305

#define rscMainViewAbout													1310

//	Resource: Talt 1200
#define ErrorAlert                                1200
#define ErrorOK                                   0

#define AboutForm                                 	1400
#define AboutUnnamed1602Label						1401
#define AboutUnnamed1603Label						1402
#define AboutUnnamed1605Label 						1403
#define AboutUnnamed1606Button						1404
