/* pilrc generated file.  Do not edit!*/
#define MainLaunchCameraButton 1010
#define MainDescriptionField 1009
#define MainForm 1008
#define DebugAlert 1007
#define RomIncompatibleAlert 1006
#define EditOnlyMenuBar 1004
#define AboutPhotoCapturePreview 1003
#define MainMenuBar 1001
