 /****************************************************************************
 *
 * Copyright (c) 2007 Palm, Inc. All rights reserved.
 *
 * File: LogUtil.h
 *
 *****************************************************************************/
void LogPrintF(const char *format, ...);
void LogUtilUninit();