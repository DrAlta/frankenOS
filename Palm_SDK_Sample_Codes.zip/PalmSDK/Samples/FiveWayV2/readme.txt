---------------------------------------------------------------------------
Name

  FiveWay2

---------------------------------------------------------------------------
Description

  This sample code shows how to detect key presses, holds, and releases on 
  a Five-way enabled device.

  Files:
  - Common : Useful functions for PalmOS.
  - TestFiveWay : Main application.

---------------------------------------------------------------------------
Builds With

  CodeWarrior
  Gcc

---------------------------------------------------------------------------
Devices

  All Palm devices

---------------------------------------------------------------------------
Requirements


---------------------------------------------------------------------------
Libraries Used

  System Library

---------------------------------------------------------------------------
How to Run

  1. Launch the application
  2. Press/hold/release any/combination of the 5-way navigation keys
     - The key and state fields and checkboxes will respond correspondingly

--------------------------------------------------------------------
Note


---------------------------------------------------------------------------


