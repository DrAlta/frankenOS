--------------------------------------------------------------------------
Name

	_CDMAStatus

---------------------------------------------------------------------------
Description
	
	This sample code shows how to retreive radio connection status, operator name, and voicemail number on CDMA phones. It also shows how to get the base station info on Centro CDMA devices.
	
---------------------------------------------------------------------------
Builds With

	CodeWarrior9
	GCC command line (Please use GCC_makefile to build)
	
---------------------------------------------------------------------------
Devices

	Treo 650, Treo 755p, Centro

---------------------------------------------------------------------------
Requirements
	
	
---------------------------------------------------------------------------
Libraries Used

	Phone Library

---------------------------------------------------------------------------
How to Run
	
	1. Launch the 'CDMA Status' application
	2. If the phone radio is on, you will see connection status, operator name, voicemail number, radio status, signal quality, cell id, network id and system id info displayed on the main screen
	3. If the phone radio is off, tapping on 'refresh' will turn on the phone radio and the information above will be displayed.
   
---------------------------------------------------------------------------
Note
	This sample app works only on CDMA devices. The API PhnLibGetBaseStationIdInfo()
works only on Centro CDMA devices.

---------------------------------------------------------------------------