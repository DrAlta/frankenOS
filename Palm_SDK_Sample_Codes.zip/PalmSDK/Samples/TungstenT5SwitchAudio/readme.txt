Name

Tungsten T5 Switch Audio Sample Code

-----------------------------------------------------------------------------------------------------------------------
Description

This sample code shows how to switch audio from Speaker to Multi-connector and from Multi-connector
to Speaker on Tungsten T5.

-----------------------------------------------------------------------------------------------------------------------
Builds with

This project was built using CodeWarrior 9 and GCC.


--------------------------------------------------------------------------------------------------------
Note:

This sample code is not a standalone application. It needs to be run with higher level applications

WARNING: This sample code uses an ARMlet to Switch Audio.
This is not officially supported by palmOne. Please use this at your own risk.

Features:

- Switch Audio from Speaker to Multi-connector (On Tungsten T5).
- Switch Audio from Multi-connector to Speaker (On Tungsten T5).

Files:

- TungstenT5SwitchAudio: Shows how to switch audio from Speaker to Multi-connector on Tungsten T5.
                         Shows how to switch audio from Multi-connector to Speaker on Tungsten T5.
			
