/* pilrc generated file.  Do not edit!*/
#define InformationAlert 1007
#define RomIncompatibleAlert 1006
#define OptionsAbout 1005
#define MainSwitchAudioToSpeakerButton 1004
#define MainSwitchAudioToMultiConnectorButton 1003
#define OptionsMenu 1002
#define MainForm 1001
