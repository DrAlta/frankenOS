
//	Resource: tFRM 4300
#define PleasewaitForm                            4300	//(Left Origin = 2, Top Origin = 130, Width = 156, Height = 28, Usable = 1, Modal = 1, Save Behind = 1, Help ID = 0, Menu Bar ID = 0, Default Button ID = 0)
#define pleasewaitTextLabel                       4301	//(Left Origin = 28, Top Origin = 10, Usable = 1, Font = Bold)

//	Resource: tFRM 9500
#define ViewForm                                  9500	//(Left Origin = 2, Top Origin = 2, Width = 156, Height = 156, Usable = 1, Modal = 1, Save Behind = 1, Help ID = 0, Menu Bar ID = 0, Default Button ID = 0)
#define ViewDoneButton                            9502	//(Left Origin = 4, Top Origin = 139, Width = 25, Height = 12, Usable = 1, Anchor Left = 1, Frame = 1, Non-bold Frame = 1, Font = Standard)
#define ViewBodyField                             9501	//(Left Origin = 3, Top Origin = 16, Width = 142, Height = 120, Usable = 1, Editable = 0, Underline = 1, Single Line = 0, Dynamic Size = 0, Left Justified = 1, Max Characters = 10240, Font = Standard, Auto Shift = 0, Has Scroll Bar = 1, Numeric = 0)
#define ViewScrollbarScrollBar                    9503	//(Left Origin = 146, Top Origin = 17, Width = 7, Height = 120, Usable = 1, Value = 0, Minimum Value = 0, Maximum Value = 0, Page Size = 0)


#define VMTextPluginAlert								  1001
