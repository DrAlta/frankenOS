/* pilrc generated file.  Do not edit!*/
#define PleasewaitForm 1006
#define ViewBodyField 1005
#define ViewScrollbarScrollBar 1004
#define ViewDoneButton 1003
#define ViewForm 1002
#define VMTextPluginAlert 1001
