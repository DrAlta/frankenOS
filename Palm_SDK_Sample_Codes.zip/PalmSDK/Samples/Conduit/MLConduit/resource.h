//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MLConduit.rc
//
#define IDS_CONDUIT_NAME                1
#define IDD_CONDUIT_CFG_DETAILED        101
#define IDB_SYNC                        103
#define IDB_PCTOHH                      104
#define IDB_HHTOPC                      105
#define IDB_DONOTHING                   106
#define IDD_CONDUIT_ACTION              399
#define IDC_ACTIONGROUPBOXTEXT          403
#define IDC_RADIO_SYNC                  404
#define IDC_RADIO_PCTOHH                405
#define IDC_RADIO_HHTOPC                406
#define IDC_RADIO_DONOTHING             407
#define IDC_MAKEDEFAULT                 411
#define IDC_SYNC                        1000
#define IDC_PCTOHH                      1001
#define IDC_HHTOPC                      1002
#define IDC_DONOTHING                   1003
#define IDC_STATIC_PERMANENT            1004
#define IDC_STATIC_TEMPORARY            1005
#define IDC_CURRENT_SETTINGS_GROUP      1006
#define IDSTR_FIRSTLOG                  3300
#define IDS_CONNECTION                  3311
#define IDS_DEVICE_FULL                 3312
#define IDS_DESKTOP_FULL                3313
#define IDS_BAD_ADD_REC                 3315
#define IDS_BAD_PURGE_REMOTE            3316
#define IDS_BAD_DEL_REC                 3317
#define IDS_BAD_CHANGE_REC              3318
#define IDS_BAD_LOCALADD_REC            3319
#define IDS_REMOTE_BAD_CHANGE_CAT       3320
#define IDS_BAD_READ_RECORD             3322
#define IDS_REMOTE_TOOMANY_CATS         3323
#define IDS_REMOTE_CAT_DELETED          3325
#define IDS_DOUBLE_MODIFIED             3328
#define IDS_ARCH_DOUBLE_MOD1            3331
#define IDS_REVERSE_DELETE              3334
#define IDS_RECCOUNT_DESKTOP1           3338
#define IDS_RECCOUNT_PILOT1             3341
#define IDS_CUSTOM_LABEL                3343
#define IDS_BAD_XMAP                    3345
#define IDS_BAD_ARCHIVE_ERR             3346
#define IDS_BAD_RESET_FLAGS_REMOTE      3348
#define IDS_DOUBLE_MODIFY_SUBSC1        3358
#define IDS_LOG_SPACING                 3360
#define IDS_RECORD_COUNT_MISMATCH       3361
#define IDS_UNKNOWN_FATAL_ERROR         3362
#define IDS_BAD_PURGE_LOCAL             3363
#define IDS_BAD_LOCAL_SAVE              3364
#define IDS_BAD_RESET_FLAGS_LOCAL       3365
#define IDS_BAD_CLOSE_DB_REMOTE         3366
#define IDS_BAD_CLOSE_DB_LOCAL          3367
#define IDS_LOCAL_CAT_DELETED           3368
#define IDS_LOCAL_BAD_CHANGE_CAT        3369
#define IDS_LOCAL_TOOMANY_CATS          3370
#define IDS_DATABASE_DESCRIPTION        3371
#define IDS_DATABASE_SHORT_DESC         3372
#define IDS_PC_DB_CREATE_FAILURE        3373
#define IDS_HH_DB_CREATE_FAILURE        3374
#define IDS_PC_ADD_RECORD_ERROR         3375
#define IDS_HH_ADD_RECORD_ERROR         3376
#define IDS_PC_READ_REC_ERROR           3377
#define IDS_HH_READ_REC_ERROR           3378
#define IDS_RECORD_DESC_ID              3379
#define IDS_RECORD_DESC_INDEX           3380
#define IDSTR_LASTLOG                   3600
#define IDS_ADDRESS_TABLESTRING         8002
#define IDS_CUSTOM_TERMINATOR           8003
#define IDS_CURRENT_SETTINGS_GROUP      8004
#define IDS_SYNC_FILES                  8005
#define IDS_PCTOHH                      8006
#define IDS_HHTOPC                      8007
#define IDS_DO_NOTHING                  8008
#define IDS_SYNC_ACTION_TEXT            8009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
