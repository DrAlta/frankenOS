---------------------------------------------------------------------------
Name

  CameraV3

---------------------------------------------------------------------------
Description

  CameraV3 is a sample application that shows how to add basic 
  camera/imaging functionality by using the Camera library. The sample 
  also uses the new Camera Manager library. 

---------------------------------------------------------------------------
Builds With

  CodeWarrior
  Gcc

---------------------------------------------------------------------------
Devices

  All Palm devices with camera support

---------------------------------------------------------------------------
Requirements


---------------------------------------------------------------------------
Libraries Used

  Camera Library
  New Camera Manager Library

---------------------------------------------------------------------------
How to Run

  1. Launch the application
  2. Tap on 'Capture' to take a picture

---------------------------------------------------------------------------
Note

When you are in camera preview mode and leave the screen turned off for a long
period of time, it takes longer for the device to turn back on. Pressing the "Red" 
button a couple of times speeds it up. This is a known issue and is being 
worked on.

---------------------------------------------------------------------------

