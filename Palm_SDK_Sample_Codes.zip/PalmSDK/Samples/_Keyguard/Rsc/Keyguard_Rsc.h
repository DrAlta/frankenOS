/* pilrc generated file.  Do not edit!*/
#define MainOptionsAbout 1007
#define MainUnlockButton 1006
#define MainLockButton 1005
#define MainDescriptionField 1004
#define MainOptionsMenu 1003
#define MainForm 1002
#define RomIncompatibleAlert 1001
