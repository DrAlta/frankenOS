Name

_Keyguard

-----------------------------------------------------------------------------------------------------------------------
Description

This sample application shows how to activate the keyguard programmatically, and also disable it 
everytime an incoming SMS alert takes place.

-----------------------------------------------------------------------------------------------------------------------
Builds with

This project was built using Palm OS Developer Suite version 1.2.0.23.
This project also builds with Codewarrior 9 and
GCC command line (Please use GCC_makefile to build).

This wizard-generated code is based on code adapted from the
stationery files distributed as part of the Palm OS SDK 4.0.

------------------------------------------------------------------------------------------------------------------------
Devices

Should run on all Palm OS devices
Should not crash on other devices

------------------------------------------------------------------------------------------------------------------------

Requirements

No specific requirements

-----------------------------------------------------------------------------------------------------------------------
Libraries Used

Phone library
System library

------------------------------------------------------------------------------------------------------------------------
How to Run

1. Launch the "Keyguard"
application

2. Tap on 'Lock'
   - Check results

3. Click on center button to unlock device.
   - Check results


Expected Results:

2. The device should be locked.

3. The device should be unlocked.



-----------------------------------------------------------------------------------------------------------------------

Note

----------------------------------------------------------------------------------------------------------------------

