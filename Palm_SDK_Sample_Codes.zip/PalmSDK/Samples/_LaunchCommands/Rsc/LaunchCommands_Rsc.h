/* pilrc generated file.  Do not edit!*/
#define MainOptionsAbout 1015
#define MainDialButton 1014
#define MainDialPadFilledButton 1013
#define MainDialPadEmptyButton 1012
#define MainMaxBlazerButton 1011
#define MainMinBlazerButton 1010
#define MainCallLogButton 1009
#define MainFavoritesButton 1008
#define MainContactButton 1007
#define MainDescriptionField 1006
#define MainOptionsMenu 1005
#define MainForm 1004
#define UnsupportedFeature 1003
#define MissingUrlAlert 1002
#define RomIncompatibleAlert 1001
