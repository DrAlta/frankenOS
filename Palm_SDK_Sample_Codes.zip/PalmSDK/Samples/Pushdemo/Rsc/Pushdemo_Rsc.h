/* pilrc generated file.  Do not edit!*/
#define ConnectionAlert 1016
#define MainOptionsAbout 1015
#define MainDoneButton 1014
#define MainStartButton 1013
#define MainPortField 1012
#define MainPortLabel 1011
#define MainIP4Field 1010
#define MainIP3Field 1009
#define MainIP2Field 1008
#define MainIP1Field 1007
#define MainIPLabel 1006
#define MainStatusField 1005
#define MainStatusLabel 1004
#define MainOptionsMenu 1003
#define MainForm 1002
#define RomIncompatibleAlert 1001
