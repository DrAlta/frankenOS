/****************************************************************************
 * Copyright (c) 2007 Palm, Inc. All rights reserved.
 *
 * File: LogUtil.h
 *
*****************************************************************************/
void LogPrintF(const char *newstr, ...);
void LogUtilUninit();