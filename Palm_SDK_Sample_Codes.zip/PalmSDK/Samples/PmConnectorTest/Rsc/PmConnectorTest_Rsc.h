/* pilrc generated file.  Do not edit!*/
#define HelpMenu 1017
#define MainOutField 1015
#define MainDisableDetectionButton 1014
#define MainPowerOffButton 1013
#define MainPowerOnButton 1012
#define MainMenuBar 1011
#define MainForm 1010
#define AboutUnnamed1606Button 1009
#define AboutUnnamed1607Label 1008
#define AboutUnnamed1605Label 1007
#define AboutUnnamed1603Label 1006
#define AboutUnnamed1608Label 1005
#define AboutUnnamed1602Label 1004
#define AboutForm 1003
#define CustomAlert 1002
#define RomIncompatibleAlert 1001
