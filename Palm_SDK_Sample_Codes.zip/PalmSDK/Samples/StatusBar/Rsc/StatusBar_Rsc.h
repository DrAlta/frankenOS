/* pilrc generated file.  Do not edit!*/
#define RomIncompatibleAlert 1008
#define MainOptionsAbout 1007
#define MainSliderField 1006
#define MainStatusBarField 1005
#define MainGetStatusButton 1004
#define MainStatusBarLabel 1003
#define MainOptionsMenu 1002
#define MainForm 1001
