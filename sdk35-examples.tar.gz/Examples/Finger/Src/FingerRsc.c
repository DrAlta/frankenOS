/******************************************************************************
 *
 * Copyright (c) 1994-1999 Palm Computing, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: FingerRsc.c
 *
 * History:
 *		01/04/97		Gregory Toto, created.
 *
 *****************************************************************************/

#include <PalmOS.h>

char *AppResourceList[] =
{
	// this MUST be the path / name of the constructor file in this
	// example!
	
	"::Rsc:"RESOURCE_FILE_PREFIX"Finger.rsrc", 
	""
};

