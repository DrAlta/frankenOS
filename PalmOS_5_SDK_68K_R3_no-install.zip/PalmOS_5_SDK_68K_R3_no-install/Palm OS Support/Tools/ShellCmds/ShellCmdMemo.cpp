/******************************************************************************
 *
 * Copyright (c) 1996-2002 PalmSource, Inc. All rights reserved.
 *
 * File: ShellCmdMemo.cpp
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 * Description:
 *	  This file is where customized console shell comands are kept.
 * Currently this is a stub which the emulator calls when it doesn't
 * recognize a command.  The code here shows how to add a custom command.
 * The custom command is useless, but it does provide a template to add commands.
 * An application programmer can copy this file to their application 
 * folder and then customize it to handle as many commands as they wish.
 *
 *****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include <PalmTypes.h>
#include <DataMgr.h>
#include <SystemResources.h>

#include "ShellCmd.h"

#include "MemoDB.h"
#include "MemoRsc.h"
#include "MemoMain.h"

typedef void ShellCmdFuncType (int argc, Char * argv[]);
typedef ShellCmdFuncType * ShellCmdFuncPtr;
typedef struct {
	const char *		longName;
	const char *		shortName;
	ShellCmdFuncPtr	func;
} ShellCmdInfoType;



/***********************************************************************
 *
 * FUNCTION:    DoAppCommand
 *
 * DESCRIPTION: Execute a user defined command for the appliation. 
 *					 (It currently adds one to a number as an example)
 *
 *					 Syntax: UserCommand num
 *
 * PARAMETERS:  argc - number of arguments
 *              argv - argument list
 *
 * RETURNED:    false if the command was a ui command.
 *
 ***********************************************************************/
static void DoAppCommand (int argc, Char * argv[])
{
	int i;
	char text[256];
	Int16 num = 0;
	Boolean usageErr = false;

	// Parse the arguments passed.
	if ( argc > 1 && !strcmp(argv[1], "?") )
		goto Help;

	if (argc < 2) usageErr = true;
	for (i=1; i<argc; i++)
		{
		if (isxdigit(argv[i][0]))
			sscanf(argv[i], "%d", &num);
		else
			usageErr = true;
		}

	if (usageErr) {
		goto SyntaxOnly;
		}

	// Perform the command here
	sprintf(text, "\n%d + 1 = %d\n", num, num + 1);
	ShlInsertText(text);

	return;


	// Dislay help and or syntax.
Help:
	ShlInsertText("\nExecute a user defined command. (adds one to a number)\n"
		"You can customize this in the ShellCmdApp.cp file\n");
SyntaxOnly:
	sprintf(text, "\nSyntax: %s [number]\n", argv[0]);
	ShlInsertText(text);
	return;
}


//----------------------------------------------------------------------
// find an open memo database
//
// Parameters: none
//----------------------------------------------------------------------
static DmOpenRef FindOpenedMemoDatabase (void)
{
	DmOpenRef	dbP=0;
	LocalID		dbID;
	UInt16		mode;
	UInt16		cardNo;
	UInt32		dbType;
	UInt32		dbCreator;
	
	do {
		dbP = DmNextOpenDatabase(dbP);
		if (!dbP) break;

		Err err = DmOpenDatabaseInfo(dbP, &dbID, NULL, &mode, &cardNo, NULL);
		if (err) 
			{
			ShlInsertText("\n#ERROR getting info");
			}
		else
			{
			DmDatabaseInfo(cardNo, dbID, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				&dbType, &dbCreator);

			if ( (dbType == memoDBType) && (dbCreator == sysFileCMemo) )
				return (dbP);
			}
		} while (1);

	return (0);
}


//----------------------------------------------------------------------
// Function to read a char from a disk file for importing.
//----------------------------------------------------------------------
static UInt32 ReadFunction(const void * stream, Char * bufferP, UInt32 length)
{	UInt32 count = 0;
	Char c;
	
	while ((c = fgetc((FILE *) stream))!=EOF) bufferP[count++] = c;
	return count;
}



//----------------------------------------------------------------------
// Import from a text file.
//
// DoMemoImportMIME <access ptr> <file in>
//----------------------------------------------------------------------
static void DoMemoImportMIME(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	char			fileInName[64] = "\0";
	char			text[128];
	int			i;
	UInt32 		firstRecordImported = 0;
	UInt16		numRecordsReceived;


	// Parse the arguments passed.
	if ( argc > 1 && !strcmp(argv[1], "?") )
		goto Help;

	for (i=1; i<argc; i++) {
		if (i == 1)
			sscanf(argv[i], "%lx", &dbP);
		else
		if (!*fileInName)
			sscanf(argv[i], "%s", fileInName);
		else
			usageErr = true;
	
		}

	dbP = FindOpenedMemoDatabase();
	if (!dbP)
		usageErr = true;

	if (usageErr)
		goto SyntaxOnly;


	FILE*	fileIn=0;
	fileIn = fopen(fileInName, "rb");
	if (!fileIn) {
		sprintf(text, "\nUnknown input file: %s\n", fileInName);
		ShlInsertText(text);
		return;
		}
	
	
	// Keep importing records until it can't
	while (MemoImportMime(dbP, fileIn, ReadFunction, false, false, &numRecordsReceived, NULL, 0))
		{};
	
	fclose(fileIn);
	
	return;
	
	
	// Dislay help and or syntax.
Help:
	ShlInsertText("\nImport a text file, handle MIME encoding\n");
SyntaxOnly:
	sprintf(text, "\nSyntax: %s <cardno> <file>\n", argv[0]);
	ShlInsertText(text);
	return;
}


/***********************************************************************
 *
 * FUNCTION:    ShlDoAppCmd
 *
 * DESCRIPTION: This routine check if a command is a user defined shell 
 *					 command for the application.  If so is the command is executed.
 *
 * PARAMETERS:  argc - number of arguments
 *              argv - argument list
 *
 * RETURNED:    false if the command was handled.
 *
 ***********************************************************************/
int ShlDoAppCmd (int argc, Char * argv[])
{
	int i;
	ShellCmdInfoType cmd [] ={ 
		// Each command should have a customized line below	
		"UserComand", 		"uc",  	DoAppCommand,
		"MemoImportMIME", "im",  	DoMemoImportMIME,
		};
			
	for (i = 0; i < sizeof (cmd) / sizeof (ShellCmdInfoType); i++)
		{
		if ( (!ShlStrCmpi(argv[0], cmd[i].longName)) ||
			  (!ShlStrCmpi(argv[0], cmd[i].shortName)))
			{
			cmd[i].func (argc, argv);
			return 0;
			}
		}
	return 1;

}
