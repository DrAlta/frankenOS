/******************************************************************************
 *
 * Copyright (c) 1999-2002 PalmSource, Inc. All rights reserved.
 *
 * File: ShellCmdCalc.cpp
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 * Description:
 * This file contains test code for Pilot's Calculator & FloatManger
 *  that is used in both DOS and Windows apps
 *
 *****************************************************************************/

// Pilot Includes 
#include "SysAll.h"
#include "FloatMgr.h"

// Borland Includes
#include <new.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "ShellCmd.h"

#define	NON_PORTABLE
#include <SystemPrv.h>


typedef void ShellCmdFuncType (int argc, Char * argv[]);
typedef ShellCmdFuncType * ShellCmdFuncPtr;
typedef struct {
	Char *				longName;
	Char *				shortName;
	ShellCmdFuncPtr	func;
} ShellCmdInfoType;


#pragma pcrelstrings off


/************************************************************
 * add two floating pt numbers
 *************************************************************/
static void DoFloatAdd(int argc, Char ** argv)
{
	double		x1 = 99999999, x2 = 99999999, result;
	Err			err = 0;
	Boolean		usageErr = false;
	char			text[256];
	char 			*endP;

	// MemHandle help request
	if ( argc > 1 && !strcmp(argv[1], "?") )
		goto Help;

	// Disable execution of this command when the debugger is attached
	// tstDisableCmdIfDbgMacro;

	for (int i=1; i<argc; i++) {
		if (x1 == 99999999) {
			// strol allows for decimal, hex or octal format numbers
			// based on initial character of the string
			x1 = strtod(argv[i], &endP);
			}

		else if (x2 == 99999999)
			x2 = strtod(argv[i], &endP);

		else
			usageErr = true;
		}

	if (x1 == 99999999 || x2 == 99999999) usageErr = true;
	if (usageErr)
		goto SyntaxOnly;


	result = x1 + x2;
	sprintf(text, "Result : %f\n", result);
	ShlInsertText(text);

	return;

Help:
	ShlInsertText("\nFloating Add");
SyntaxOnly:
	sprintf(text, "\nSyntax: %s <x1> <x2> \n", argv[0]);
	ShlInsertText(text);
	return;
}


/************************************************************
 * multiply two floating pt numbers
 *************************************************************/
static void DoFloatMultiply(int argc, Char ** argv)
{
	double		x1 = 99999999, x2 = 99999999, result;
	Err			err = 0;
	Boolean		usageErr = false;
	char			text[256];
	char 			*endP;

	// MemHandle help request
	if ( argc > 1 && !strcmp(argv[1], "?") )
		goto Help;

	// Disable execution of this command when the debugger is attached
	// tstDisableCmdIfDbgMacro;

	for (int i=1; i<argc; i++) {
		if (x1 == 99999999) {
			// strol allows for decimal, hex or octal format numbers
			// based on initial character of the string
			x1 = strtod(argv[i], &endP);
			}

		else if (x2 == 99999999)
			x2 = strtod(argv[i], &endP);

		else
			usageErr = true;
		}

	if (x1 == 99999999 || x2 == 99999999) usageErr = true;
	if (usageErr)
		goto SyntaxOnly;


	result = x1 * x2;
	sprintf(text, "Result : %f\n", result);
	ShlInsertText(text);

	return;

Help:
	ShlInsertText("\nFloating Multiply");
SyntaxOnly:
	sprintf(text, "\nSyntax: %s <x1> <x2> \n", argv[0]);
	ShlInsertText(text);
	return;
}


/************************************************************
 * divide two floating pt numbers
 *************************************************************/
static void DoFloatDivide(int argc, Char ** argv)
{
	double		divisor = 99999999, dividend = 99999999, result;
	Err			err = 0;
	Boolean		usageErr = false;
	char			text[256];
	char 			*endP;

	// Handle help request
	if ( argc > 1 && !strcmp(argv[1], "?") )
		goto Help;

	// Disable execution of this command when the debugger is attached
	// tstDisableCmdIfDbgMacro;

	for (int i=1; i<argc; i++) {
		if (dividend == 99999999) {
			// strol allows for decimal, hex or octal format numbers
			// based on initial character of the string
			dividend = strtod(argv[i], &endP);
			}

		else if (divisor == 99999999)
			divisor = strtod(argv[i], &endP);

		else
			usageErr = true;
		}

	if (dividend == 99999999 || divisor == 99999999) usageErr = true;
	if (usageErr)
		goto SyntaxOnly;


	result = dividend / divisor;
	sprintf(text, "Result : %f\n", result);
	ShlInsertText(text);

	return;

Help:
	ShlInsertText("\nFloating Divide");
SyntaxOnly:
	sprintf(text, "\nSyntax: %s <dividend> <divisor> \n", argv[0]);
	ShlInsertText(text);
	return;
}


/************************************************************
 * Convert a floating pt number to ascii
 *************************************************************/
static void DoFplFToA(int argc, Char ** argv)
{
	FloatType		num = { 99999999, kExpInf, 1 };
	Err				err = 0;
	Boolean			usageErr = false;
	char				text[256], resultText[30];
	char 				*endP;

	// Handle help request
	if ( argc > 1 && !strcmp(argv[1], "?") )
		goto Help;

	// Disable execution of this command when the debugger is attached
	// tstDisableCmdIfDbgMacro;

	for (int i=1; i<argc; i++) {
		if (num.man == 99999999) {
			if (*argv[i] == '-') {
				num.sign = -1;		// save the sign in the float structure
				*argv[i] = ' ';	// clear the sign from the string
				}
			// strol allows for decimal, hex or octal format numbers
			// based on initial character of the string
			num.man = strtol(argv[i], &endP, 0);
			}

		else if (num.exp == kExpInf)
			num.exp = atoi(argv[i]);

		else
			usageErr = true;
		}

	if (num.man == 99999999 || num.exp == kExpInf) usageErr = true;

	if (usageErr) {
		goto SyntaxOnly;
		}

	if (!GFplGlobalsP)
		err = FplInit ();
	if (!err)
		err = FplFToA(num, resultText);

	if (err)
		ShlInsertText("\n## ERROR Occurred!\n");
	else {
		sprintf(text, "Result : %s\n", resultText);
		ShlInsertText(text);
		}

	return;

Help:
	ShlInsertText("\nFloating point number to ascii.");
SyntaxOnly:
	sprintf(text, "\nSyntax: %s <[-] [0x]mantissa> <[-]exponent> \n", argv[0]);
	ShlInsertText(text);
	return;
}


/************************************************************
 * Convert a number in ascii to floating pt 
 *************************************************************/
static void DoFplAToF(int argc, Char ** argv)
{
	FloatType		num;
	Err				err = 0;
	char				text[256];

	// Handle help request
	if ( argc > 1 && !strcmp(argv[1], "?") )
		goto Help;

	if ( argc != 2)
		goto SyntaxOnly;

	if (!GFplGlobalsP)
		err = FplInit ();
	if (!err)
		num = FplAToF(argv[1]);

	if (err)
		ShlInsertText("\n## ERROR Occurred!\n");
	else {
		sprintf(text, "mantissa : %lu (%#lx)\nexponent : %d\nsign :     %d\n", num.man, num.man, num.exp, num.sign);
		ShlInsertText(text);
		}

	return;

Help:
	ShlInsertText("\nAscii number to Floating point.");
SyntaxOnly:
	sprintf(text, "\nSyntax: %s <[-]decimalnumber> \n", argv[0]);
	ShlInsertText(text);
	return;

}


/**********************************************************************
 * Support for Calculator & FloatMgr commands
 *
 * returns 0 if successfully found command
 ***********************************************************************/
int ShlDoDBCmd(int argc, Char * argv[])
{
	int i;
	ShellCmdInfoType cmd [] ={ 	
		"FloatToAscii", 		"ftoa",  DoFplFToA,
		"AsciiToFloat",		"atof",	DoFplAToF,
		"FloatMultiply", 		"fmul",  DoFloatMultiply,
		"FloatDivide", 		"fdiv",  DoFloatDivide,
		"FloatAdd", 			"fadd",  DoFloatAdd,
		};
			
	for (i = 0; i < sizeof (cmd) / sizeof (ShellCmdInfoType); i++)
		{
		if ( (!ShlStrCmpi(argv[0], cmd[i].longName)) ||
			  (!ShlStrCmpi(argv[0], cmd[i].shortName)))
			{
			cmd[i].func (argc, argv);
			return 0;
			}
		}
	return 1;
}
