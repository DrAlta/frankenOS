/******************************************************************************
 *
 * Copyright (c) 1996-2002 PalmSource, Inc. All rights reserved.
 *
 * File: ShellCmdApp.cpp
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 * Description:
 *	  This file is where customized console shell comands are kept.
 * Currently this is a stub which the emulator calls when it doesn't
 * recognize a command.  The code here shows how to add a custom command.
 * The custom command is useless, but it does provide a template to add commands.
 * An application programmer can copy this file to their application 
 * folder and then customize it to handle as many commands as they wish.
 *
 *****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <ctype.h>

// Pilot Includes 
// general Palm OS includes
#include <PalmTypes.h>

#include "ShellCmd.h"

typedef void ShellCmdFuncType (int argc, Char * argv[]);
typedef ShellCmdFuncType * ShellCmdFuncPtr;
typedef struct {
	const Char *				longName;
	const Char *				shortName;
	ShellCmdFuncPtr	func;
} ShellCmdInfoType;



/***********************************************************************
 *
 * FUNCTION:    DoAppCommand
 *
 * DESCRIPTION: Execute a user defined command for the appliation. 
 *					 (It currently adds one to a number as an example)
 *
 *					 Syntax: UserCommand num
 *
 * PARAMETERS:  argc - number of arguments
 *              argv - argument list
 *
 * RETURNED:    false if the command was a ui command.
 *
 ***********************************************************************/
static void DoAppCommand (int argc, Char * argv[])
{
	int i;
	char text[256];
	Int16 num = 0;
	Boolean usageErr = false;

	// Parse the arguments passed.
	if ( argc > 1 && !strcmp(argv[1], "?") )
		goto Help;

	if (argc < 2) usageErr = true;
	for (i=1; i<argc; i++)
		{
		if (isxdigit(argv[i][0]))
			sscanf(argv[i], "%d", &num);
		else
			usageErr = true;
		}

	if (usageErr) {
		goto SyntaxOnly;
		}

	// Perform the command here
	sprintf(text, "\n%d + 1 = %d\n", num, num + 1);
	ShlInsertText(text);

	return;


	// Dislay help and or syntax.
Help:
	ShlInsertText("\nExecute a user defined command. (adds one to a number)\n"
		"You can customize this in the ShellCmdApp.cpp file\n");
SyntaxOnly:
	sprintf(text, "\nSyntax: %s [number]\n", argv[0]);
	ShlInsertText(text);
	return;
}


/***********************************************************************
 *
 * FUNCTION:    ShlDoAppCmd
 *
 * DESCRIPTION: This routine check if a command is a user defined shell 
 *					 command for the application.  If so is the command is executed.
 *
 * PARAMETERS:  argc - number of arguments
 *              argv - argument list
 *
 * RETURNED:    false if the command was handled.
 *
 ***********************************************************************/
int ShlDoAppCmd (int argc, Char * argv[])
{
	int i;
	ShellCmdInfoType cmd [] ={ 
		// Each command should have a customized line below	
		"UserComand", 		"uc",  	DoAppCommand,
		};
			
	for (i = 0; i < sizeof (cmd) / sizeof (ShellCmdInfoType); i++)
		{
		if ( (!ShlStrCmpi(argv[0], cmd[i].longName)) ||
			  (!ShlStrCmpi(argv[0], cmd[i].shortName)))
			{
			cmd[i].func (argc, argv);
			return 0;
			}
		}
	return 1;

}
