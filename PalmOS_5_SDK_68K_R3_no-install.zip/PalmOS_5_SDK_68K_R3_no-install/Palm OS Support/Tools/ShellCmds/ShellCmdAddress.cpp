/******************************************************************************
 *
 * Copyright (c) 1999-2002 PalmSource, Inc. All rights reserved.
 *
 * File: ShellCmdAddress.cpp
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 * Description:
 * This file contains test code for Pilot that is used in both
 *  DOS and Windows apps
 *
 *****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <ctype.h>

// Pilot Includes 
// general Palm OS includes
#include <PalmTypes.h>
#include <DataMgr.h>
#include <SystemResources.h>
#include <Preferences.h>
#include <Form.h>
#include <Chars.h>
#include <TimeMgr.h>

#include "ShellCmd.h"

// Address includes
#include "AddressDB.h"
#include "Address.h"

#ifdef __MC68K__ // PPC (and perhaps others?) don't like this pragma
#pragma pcrelstrings off
#endif

// Handles either '\n' or '\r' but not '\r\n' (MSDOS).
static char * myfgets(char *s, int n, FILE *stream)
{
	char *p = s;
	int c = '\n';
	
	n--;
	
	while (n > 0 && (c = fgetc(stream)) != EOF) {
		if (c == '\r') {
			c = '\n';
		}
		
		if (c == '\n')
			break;
		*p++ = c;
		n--;
	}
	
	if (p == s && c == EOF)
		return NULL;
	else
		{
		*p = '\0';
		return s;
		}
}


/**********************************************************************
 * find an open address database
 *
 * Parameters: none
 ***********************************************************************/
static DmOpenRef FindOpenedAddressDatabase (void)
{
	DmOpenRef	dbP=0;
	LocalID		dbID;
	UInt16			mode;
	UInt16			cardNo;
	UInt32			dbType;
	UInt32			dbCreator;
	
	do {
		dbP = DmNextOpenDatabase(dbP);
		if (!dbP) break;

		Err err = DmOpenDatabaseInfo(dbP, &dbID, NULL, &mode, &cardNo, NULL);
		if (err) 
			{
			ShlInsertText("\n#ERROR getting info");
			}
		else
			{
			DmDatabaseInfo(cardNo, dbID, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				&dbType, &dbCreator);

			if ( (dbType == addrDBType) && (dbCreator == sysFileCAddress) )
				return (dbP);
			}
		} while (1);


	return(0);
}


/**********************************************************************
 * Set the Address application chunk to the defaults.
 *
 * AddrSetInfoDefaults <access ptr>
 ***********************************************************************/
static void DoAddrSetInfoDefaults(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	char			text[256];
	int			i;

	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			usageErr = true;
		
		}

	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr>\n", argv[0]);
		ShlInsertText(text);
		return;
		}

	Err err = AddrDBAppInfoInit(dbP);
	if (err) {
		ShlInsertText("\n##ERROR Setting defaults\n");
		}
	else {
		ShlInsertText("Success!\n");
		}
}



/**********************************************************************
 * Create a Address database for sync testing.
 *
 * DoAddrBuildSyncDB <access ptr>
 ***********************************************************************/
static void DoAddrBuildSyncDB(int argc, Char * argv[])
{
	Boolean		usageErr = false, doArchive, doDelete;
	DmOpenRef	dbP=0;
	UInt16 			index, attr;
	char			text[256];
	int			i;
	UInt32			uID;
	LocalID		chunkID;

/* 
	AddrDBRecordType	testRecords []= {
		{0, ...  , "foo", ""},				// 30 add - cat 0
		{0, ...  , "foo", ""},				// 31 delete - cat 1
		{0, ...  , "foo", ""},				// 32 none - cat 2
		{0, ...  , "foo", ""},				// 33 delete - cat 3
		{0, ...  , "foo", ""},				// 34 update - cat 0
		{0, ...  , "foo", ""},				// 35 update - cat 1
		{0, ...  , "foo", ""},				// 36 none - cat 2
		{0, ...  , "foo", ""},				// 37 update - cat 3
		{0, ...  , "foo", ""},				// 38 update - cat 0
		{0, ...  , "foo", ""},				// 39 archive/none - cat 1
		{0, ...  , "foo", ""},				// 40 archive/none - cat 2
		{0, ...  , "foo", ""},				// 41 archive/none - cat 3
		{0, ...  , "foo", ""},				// 42 archive/update - cat 0
		{0, ...  , "foo", ""},				// 43 archive/update - cat 1
		{0, ...  , "foo", ""},				// 44 none - cat 2
		{0, ...  , "foo", ""},				// 45 delete - cat 3
		{0, ...  , "foo", ""},				// 46 update - cat 0
		{0, ...  , "foo", ""},				// 47 update - cat 1
		{0, ...  , "foo", ""}				// 48 update - cat 2
	};
*/

#ifdef __MWERKS__
#pragma const_strings off
#endif

	AddrDBRecordType	testRecords [] = {
		{0, 0, 0, 0, 0, 0, 0, "foo", NULL, NULL, NULL, NULL, NULL, 
			NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL}, 
		{0, 0, 0, 0, 0, 0, 0, "foo", NULL, NULL, NULL, NULL, NULL, 
			NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL}, 
		{0, 0, 0, 0, 0, 0, 0, "foo", NULL, NULL, NULL, NULL, NULL, 
			NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL}, 
		{0, 0, 0, 0, 0, 0, 0, "foo", NULL, NULL, NULL, NULL, NULL, 
			NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL}, 
		{0, 0, 0, 0, 0, 0, 0, "foo", NULL, NULL, NULL, NULL, NULL, 
			NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL}, 
		{0, 0, 0, 0, 0, 0, 0, "foo", NULL, NULL, NULL, NULL, NULL, 
			NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL}, 
		{0, 0, 0, 0, 0, 0, 0, "foo", NULL, NULL, NULL, NULL, NULL, 
			NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL}, 
		{0, 0, 0, 0, 0, 0, 0, "foo", NULL, NULL, NULL, NULL, NULL, 
			NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL}, 
		{0, 0, 0, 0, 0, 0, 0, "foo", NULL, NULL, NULL, NULL, NULL, 
			NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL}, 
		{0, 0, 0, 0, 0, 0, 0, "foo", NULL, NULL, NULL, NULL, NULL, 
			NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL}, 
		{0, 0, 0, 0, 0, 0, 0, "foo", NULL, NULL, NULL, NULL, NULL, 
			NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL}, 
		{0, 0, 0, 0, 0, 0, 0, "foo", NULL, NULL, NULL, NULL, NULL, 
			NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL}, 
		{0, 0, 0, 0, 0, 0, 0, "foo", NULL, NULL, NULL, NULL, NULL, 
			NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL}, 
		{0, 0, 0, 0, 0, 0, 0, "foo", NULL, NULL, NULL, NULL, NULL, 
			NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL}, 
		{0, 0, 0, 0, 0, 0, 0, "foo", NULL, NULL, NULL, NULL, NULL, 
			NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL}, 
		{0, 0, 0, 0, 0, 0, 0, "foo", NULL, NULL, NULL, NULL, NULL, 
			NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL}, 
		{0, 0, 0, 0, 0, 0, 0, "foo", NULL, NULL, NULL, NULL, NULL, 
			NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL}, 
		{0, 0, 0, 0, 0, 0, 0, "foo", NULL, NULL, NULL, NULL, NULL, 
			NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL}, 
		{0, 0, 0, 0, 0, 0, 0, "foo", NULL, NULL, NULL, NULL, NULL, 
			NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL}, 
	}; 

#ifdef __MWERKS__
#pragma const_strings reset
#endif

	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			usageErr = true;
		}

	if (!dbP)
		usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}


	sprintf (text, "record  unique\nindex   id\n");
	ShlInsertText (text);

	for (i = 0; i < sizeof (testRecords) / sizeof (AddrDBRecordType); i++)
		{
		AddrDBNewRecord (dbP, &testRecords[i], &index);

		// Get the category and the sercrt attribute of the current record.
		DmRecordInfo (dbP, index, &attr, NULL, NULL);	

		// clear the current category & the dirty flag
		attr &= ~dmRecAttrCategoryMask;
		attr &= ~dmRecAttrDirty;
		doArchive = doDelete = false;
	
		if (i == 0) {				//  30 add - cat 0
			attr |= dmRecAttrDirty;
			}
			
		else if (i == 1) {		// 31 delete - cat 1
			attr |= 1;
			doDelete = true;
			}

		else if (i == 2) {		// 32 none - cat 2			
			attr |= 2;
			}	
			
		else if (i == 3) {		//  33 delete - cat 3
			doDelete = true;
			attr |= 3;
			}
			
		else if (i == 4) {		//  34 update - cat 0
			attr |= dmRecAttrDirty;
			}
			
		else if (i == 5) {		// 35 update - cat 1
			attr |= dmRecAttrDirty;
			attr |= 1;
			}
			
		else if (i == 6) {		// 36 none - cat 2
			attr |= 2;
			}
			
		else if (i == 7) {		//37 update - cat 3
			attr |= dmRecAttrDirty;
			attr |= 3;
			}
			
		else if (i == 8) {		// 38 update - cat 0
			attr |= dmRecAttrDirty;
			}
			
		else if (i == 9) {		// 39 archive/none - cat 1
			attr |= 1;
			doArchive = true;
			}
			
		else if (i == 10) {		// 40 archive/none - cat 2
			attr |= 2;
			doArchive = true;
			}
			
		else if (i == 11) {		// 41 archive/none - cat 3
			attr |= 3;
			doArchive = true;
			}
			
		else if (i == 12) {		// 42 archive/update - cat 0
			attr |= dmRecAttrDirty;
			doArchive = true;
			}
			
		else if (i == 13) {		// 43 archive/update - cat 1
			attr |= dmRecAttrDirty;
			attr |= 1;
			doArchive = true;
			}
			
		else if (i == 14) {		// 44 none - cat 2
			attr |= 2;
			}
			
		else if (i == 15) {		// 45 delete - cat 3
			attr |= 3;
			doDelete = true;
			}
			
		else if (i == 16) {		//  46 update - cat 0
			attr |= dmRecAttrDirty;
			}
			
		else if (i == 17) {		//  47 update - cat 1
			attr |= dmRecAttrDirty;
			attr |= 1;
			}
			
		else if (i == 18) {		//  48 update - cat 2
			attr |= dmRecAttrDirty;
			attr |= 2;
			}
			
			
		// Save the new category and flags
		DmSetRecordInfo (dbP, index, &attr, NULL);
		
		DmRecordInfo(dbP, index, &attr, &uID, &chunkID);
		
		if (doArchive)
			DmArchiveRecord(dbP, index);

		if (doDelete)
			DmDeleteRecord(dbP, index);

		sprintf (text, "%d     %lu\n", index, uID);
		ShlInsertText (text);
		}
}


/**********************************************************************
 * Test the newRecord function.
 *
 * DoAddrTestNewRecord <access ptr>
 ***********************************************************************/
static void DoAddrTestNewRecord(int argc, Char * argv[])
{
	int			i;
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	UInt16 index1;
	char			text[256];
	
#ifdef __MWERKS__
#pragma const_strings off
#endif
	
	AddrDBRecordType	testRecord1 = {0, 0, 4, 3, 2, 1, 0, 
		"Flores", "Roger", "Roger Land", 
		"917-3313", "364-8579", "952-4679", "365-2100", "roger@palm.com", 
		"822 Antionette Lane Apt B", "South San Francisco", "CA", "94080", "", 
		"President", "C1", NULL, "C3", NULL, "When in disgrace with fortune and mens eyes "
		"I all alone beweep my outcast state.  And trouble deaf heaven with my bootless cries"
		"and look upon myself and curse my fate."};

	AddrDBRecordType	testRecord2 = {0, 2, 4, 3, 2, 1, 0, 
		NULL, NULL, "Palm Computing, Inc.", 
		"949-9560", "949-0147", "1-800-881-PALM", "palm.com",
		"4410 El Camino Real Suite 108", "South San Francisco", "CA", "94080", "", 
		NULL, NULL, "1/6/92", NULL, NULL, NULL, NULL};

	AddrDBRecordType	testRecord3 = {0, 0, 4, 3, 2, 1, 0, 
		"Carter", "Gene", NULL, 
		"415 996-9622", NULL, NULL, NULL,
		"CA", NULL, NULL,
		NULL, NULL, NULL, NULL, NULL, NULL};

	AddrDBRecordType	testRecord4 = {0, 0, 4, 3, 2, 1, 0,
		"GOMORY", "Paul", NULL, 
		"415 282-3380", "415 641-7847", "999-8217", NULL, NULL,
		"1237 Douglass", "San Francisco", "CA", "94131", NULL,
		NULL, NULL, NULL, NULL, NULL, NULL};

	AddrDBRecordType	testRecord5 = {0, 0, 4, 3, 2, 1, 0, 
		"Thurm", "Scott", "Mercury News", 
		"408 395-9032", NULL, NULL, NULL, NULL,
		"10B Bayview Court", "", "CA", "", "", 
		NULL, NULL, NULL, NULL, NULL, NULL};

#ifdef __MWERKS__
#pragma const_strings reset
#endif

	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			usageErr = true;
		
		}

	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}


	UInt16 Err = AddrDBNewRecord(dbP, &testRecord1, &index1);
	sprintf(text, "%d\n", index1);
	ShlInsertText(text);

	Err = AddrDBNewRecord(dbP, &testRecord2, &index1);
	sprintf(text, "%d\n", index1);
	ShlInsertText(text);

	Err = AddrDBNewRecord(dbP, &testRecord3, &index1);
	sprintf(text, "%d\n", index1);
	ShlInsertText(text);

	Err = AddrDBNewRecord(dbP, &testRecord4, &index1);
	sprintf(text, "%d\n", index1);
	ShlInsertText(text);

	Err = AddrDBNewRecord(dbP, &testRecord5, &index1);
	sprintf(text, "%d\n", index1);
	ShlInsertText(text);
}



/**********************************************************************
 * Get an record and print in Address format.
 *
 * DoAddrGetRecord <access ptr> <index>
 ***********************************************************************/

// Strip out non Ascii characters except carriage returns and tabs
//// Replace carriage returns with linefeeds for the field object.
static void CleanString(Char * s)
{
	while (*s != '\0')
		{
		if (*s == crChr)
			// Squish DOS two char end of line sequence
			if (*(s+1) == linefeedChr)
				strcpy(s, s+1);
			// convert Mac cr to Pilot linefeed
			else
				*s++ = linefeedChr;
		else
		if ((*s < ' ') && *s != linefeedChr && *s != tabChr)
			strcpy(s, s+1);
		else 
			s++;
		}
} 
 
 
static void DoAddrGetRecord(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	char			text[256];
	AddrDBRecordType	testRecord;
	MemHandle testRecordH;
	UInt16 index = 0;
	int			i;
	
	
	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
		if (!index)
			sscanf(argv[i], "%d", &index);
		else
			usageErr = true;
		
		}

	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr> <index>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}


	if (AddrDBGetRecord(dbP, index, &testRecord, &testRecordH) != 0)
		{
		ShlInsertText("Error!");
		return;
		}
	
	for (index = 0; index < 16; index++)
		{
		if (testRecord.fields[index] == NULL)
			{
			ShlInsertText("NULL, \n");
			}
		else
			{
			sprintf(text, "\"%s\", \n", testRecord.fields[index]);
			ShlInsertText(text);
			}
		}

	MemHandleUnlock(testRecordH);
}


static char *AddrParseNextField(char **c, FILE*	fileIn)
{
	char *result = NULL;
	int eofFlag;
	
	while (**c != ',' && **c != '\n' && **c != '\0') {
		if (**c == '"') {
			result = ++*c;
			do 
				{
				*c = strchr(*c, '"');
				if (*c == NULL)
					{
					// Stick in a new line and read the next line
					*c = result + strlen(result);
					**c = linefeedChr;
					++*c;
					**c = '\0';
					// Handle lines with no text
					do {
						eofFlag = myfgets(*c, 4096, fileIn) == NULL;
						CleanString(*c);
						} while (!eofFlag && **c == '\0');
					}
				else
					**c = '\0';
				}
			while (**c != '\0');
		} else
		if (**c == '\0') {
			return NULL;\
		}
		*c += 1;
	}
	if (**c != '\n' && **c != '\0')
		*c += 1;
	return result;
}


static Int16 AddrParseNextNumField(char **c)
{
	char *asciiNum = NULL;
	Int16 result;
	
	while (**c != ',' && **c != '\n') {
		if (**c == '-' ||
			(**c >= '0' && **c <= '9'))
		{
			asciiNum = *c;
			*c += 1;
			*c = strchr(*c, ',');
			**c = '\0';
			break;
		} else
		if (**c == '\0') {
			return NULL;\
		}
		*c += 1;
	}
	*c += 1;

	if (asciiNum != NULL)
		if (sscanf(asciiNum, "%d", &result) != 1)
			{
			ShlInsertText("Error importing ");
			ShlInsertText(*c);
			}
	
	return result;
}


/**********************************************************************
 * Test the newRecord function.
 *
 * DoAddrImport <access ptr> <file in>
 ***********************************************************************/
static void DoAddrImport(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	AddrDBRecordType	testRecord;
	AddrAppInfoPtr appInfoPtr;
	UInt16			attr;
	char	fileInName[64] = "\0";
	char	text[5000];					// greater than the largest field we allow
	UInt16	index1;
	char*	cmdP;
	long t1, t2, tt = 0;
	int	i;


	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
		if (!*fileInName)
			sscanf(argv[i], "%s", fileInName);
		else
			usageErr = true;
	
		}

	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr> <file in>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}

	FILE*	fileIn=0;
	fileIn = fopen(fileInName, "r");
	if (!fileIn) {
		sprintf(text, "\nUnknown input file: %s\n", fileInName);
		ShlInsertText(text);
		return;
		}


	// Import each category
	appInfoPtr = (AddrAppInfoPtr) AddrDBAppInfoGetPtr(dbP);
	cmdP = myfgets(text, 4096, fileIn);	// crash if no line!
	if (cmdP != NULL) {
		CleanString(cmdP);
		for (i = 1; i < dmRecNumCategories; i++) {
			if (*cmdP == '\0') break;	// leave if no more
			strcpy(appInfoPtr->categoryLabels[i], AddrParseNextField(&cmdP, fileIn));
		}
	}
	MemPtrUnlock(appInfoPtr);


	// Import each record
	while (	(cmdP = myfgets(text, 4096, fileIn)) != NULL) {
		CleanString(cmdP);
		
		for (i=0; i < addrNumFields; i++)
			testRecord.fields[i] = NULL;	// clear the record
			
		// Skip blank lines
		if (cmdP[0] == '\0' || cmdP[0] == linefeedChr)
			continue;
			
		testRecord.options.phones.displayPhoneForList = AddrParseNextNumField(&cmdP);
		testRecord.options.phones.phone1 = AddrParseNextNumField(&cmdP);
		testRecord.options.phones.phone2 = AddrParseNextNumField(&cmdP);
		testRecord.options.phones.phone3 = AddrParseNextNumField(&cmdP);
		testRecord.options.phones.phone4 = AddrParseNextNumField(&cmdP);
		testRecord.options.phones.phone5 = AddrParseNextNumField(&cmdP);
		
		testRecord.fields[name] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[firstName] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[company] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[phone1] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[phone2] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[phone3] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[phone4] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[phone5] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[address] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[city] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[state] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[zipCode] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[country] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[title] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[custom1] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[custom2] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[custom3] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[custom4] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[note] = AddrParseNextField(&cmdP, fileIn);

		// Show the work phone if it exists, otherwise show the home
		if (testRecord.fields[phone1] == NULL)
			testRecord.options.phones.displayPhoneForList = 1;
		else
			testRecord.options.phones.displayPhoneForList = 0;


		t1 = TimGetTicks();
		UInt16 Err = AddrDBNewRecord(dbP, &testRecord, &index1);
		if (Err) {
			ShlInsertText("\nCan not add any more records");
			break;
			}
		t2 = TimGetTicks();

		attr = AddrParseNextNumField(&cmdP);
		DmSetRecordInfo (dbP, index1, &attr, NULL);	



		tt += (t2 - t1);
		sprintf(text, "%d, ", index1);
		ShlInsertText(text);
	};

	fclose(fileIn);
	sprintf(text, "\n%ld Pilot ticks", tt*40);
	ShlInsertText(text);

}


/**********************************************************************
 * Import an Address Book CSV file using some other format.
 * Useful for getting entries from a different app.
 * Currently set to import zoomer address books.
 *
 * DoAddrImportZoomer <access ptr> <file in>
 ***********************************************************************/
static void DoAddrImportZoomer(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	AddrDBRecordType	testRecord;
	char	fileInName[64] = "\0";
	char	text[5000];
	UInt16	index1;
	char*	cmdP;
	long t1, t2, tt = 0;
	int	i;


	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
		if (!*fileInName)
			sscanf(argv[i], "%s", fileInName);
		else
			usageErr = true;
	
		}

	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr> <file in>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}

	FILE*	fileIn=0;
	fileIn = fopen(fileInName, "r");
	if (!fileIn) {
		sprintf(text, "\nUnknown input file: %s\n", fileInName);
		ShlInsertText(text);
		return;
		}

	while (	(cmdP = myfgets(text, 4096, fileIn)) != NULL) {
		for (i=0; i < addrNumFields; i++)
			testRecord.fields[i] = NULL;	// clear the record
		
		CleanString(cmdP);

		// Skip blank lines
		if (cmdP[0] == '\0')
			continue;
		
		testRecord.options.phones.phone1 = 0;	// Work
		testRecord.options.phones.phone2 = 1;	// Home
		testRecord.options.phones.phone3 = 2;	// Fax
		testRecord.options.phones.phone4 = 7;	// Other
		testRecord.options.phones.phone5 = 3;	// Email
		
		testRecord.fields[name] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[firstName] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[address] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[city] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[state] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[zipCode] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[country] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[title] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[company] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[phone1] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[phone2] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[phone4] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[phone3] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[phone5] = AddrParseNextField(&cmdP, fileIn);
	
		// If there isn't an email entry use the AOL email else junk it
		if (testRecord.fields[phone5] == NULL)
			testRecord.fields[phone5] = AddrParseNextField(&cmdP, fileIn);
		else
			AddrParseNextField(&cmdP, fileIn);

		testRecord.fields[note] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[custom1] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[custom2] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[custom3] = AddrParseNextField(&cmdP, fileIn);
		testRecord.fields[custom4] = AddrParseNextField(&cmdP, fileIn);
		

		// If there isn't a custom4 entry use other else junk it
		if (testRecord.fields[custom4] == NULL)
			testRecord.fields[custom4] = AddrParseNextField(&cmdP, fileIn);
		else
			AddrParseNextField(&cmdP, fileIn);


		// Show the work phone if it exists, otherwise show the home
		if (testRecord.fields[phone1] == NULL)
			testRecord.options.phones.displayPhoneForList = 1;
		else
			testRecord.options.phones.displayPhoneForList = 0;


		t1 = TimGetTicks();
		UInt16 Err = AddrDBNewRecord(dbP, &testRecord, &index1);
		t2 = TimGetTicks();
		tt += (t2 - t1);
		sprintf(text, "%d, ", index1);
		ShlInsertText(text);
	};

	fclose(fileIn);
	sprintf(text, "\n%ld Pilot ticks", tt*40);
	ShlInsertText(text);

}


/**********************************************************************
 * Function to read a char from a disk file for vcard importing.
 ***********************************************************************/

static UInt16 GetChar(const void * stream)
{
	return fgetc((FILE *) stream);
}


/**********************************************************************
 * Import from vCard format.
 *
 * DoAddrImportVCard <access ptr> <file in>
 ***********************************************************************/
static void DoAddrImportVCard(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	char	fileInName[64] = "\0";
	char	text[128];
	int	i;
	UInt32 firstRecordImported = 0;


	for (i=1; i<argc; i++) {
		if (i == 1)
			sscanf(argv[i], "%lx", &dbP);
		else
		if (!*fileInName)
			sscanf(argv[i], "%s", fileInName);
		else
			usageErr = true;
	
		}

	if (!dbP) dbP = FindOpenedAddressDatabase();
	
	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr> <file in>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}

	FILE*	fileIn=0;
	fileIn = fopen(fileInName, "rb");
	if (!fileIn) {
		sprintf(text, "\nUnknown input file: %s\n", fileInName);
		ShlInsertText(text);
		return;
		}
	
	
	// Keep importing records until it can't
//	while (AddrImportVCard(dbP, fileIn, GetChar, false, false, &firstRecordImported))


/*	while (AddrImportVCard(dbP, fileIn, GetChar, false, false))
		{};
*/	
	ShlInsertText("Disabled feature (ABa).");

	fclose(fileIn);
}


/**********************************************************************
 * Export all Address Book records.  Exports all record info.
 *
 * DoAddrExport <access ptr> <file out>
 ***********************************************************************/
 
static void AppendField(char *string, char *field)
{
	if (field != NULL)
		{
		strcat(string, "\"");
		strcat(string, field);
		strcat(string, "\"");
		}
	strcat(string, ",");
}

static void AppendNumField(char *string, Int16 field)
{
	char asciiNum[32];
	
	sprintf(asciiNum, "%d", field);
	strcat(string, asciiNum);
	strcat(string, ",");
}

static void DoAddrExport(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	char			fileOutName[64] = "\0";
	AddrDBRecordType	testRecord;
	MemHandle testRecordH;
	UInt16			attr;
	char			text[256];
	int 			index;
	int 			numOfRecords;
	int			i;
	AddrAppInfoPtr appInfoPtr;


	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
		if (!*fileOutName)
			sscanf(argv[i], "%s", fileOutName);
		else
			usageErr = true;
	
		}

	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr> <file out>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}

	FILE*	fileOut=0;
	fileOut = fopen(fileOutName, "w");
	if (!fileOut) {
		sprintf(text, "\nCan\'t use file: %s\n", fileOutName);
		ShlInsertText(text);
		return;
		}


	// Append each category
	appInfoPtr = (AddrAppInfoPtr) AddrDBAppInfoGetPtr(dbP);
	*text = '\0';
	for (index = 1; index < dmRecNumCategories; index++) {
		AppendField(text, appInfoPtr->categoryLabels[index]);
	}
	fprintf(fileOut, "%s\n", text);
	MemPtrUnlock(appInfoPtr);


	// Append each record
	numOfRecords = DmNumRecordsInCategory(dbP, dmAllCategories);
	for (index = 0; index < numOfRecords; index++) {
		if (AddrDBGetRecord(dbP, index, &testRecord, &testRecordH) != 0)
		{
			ShlInsertText("Error!");
			break;
		}
	
		*text = '\0';
		AppendNumField(text, testRecord.options.phones.displayPhoneForList);
		AppendNumField(text, testRecord.options.phones.phone1);
		AppendNumField(text, testRecord.options.phones.phone2);
		AppendNumField(text, testRecord.options.phones.phone3);
		AppendNumField(text, testRecord.options.phones.phone4);
		AppendNumField(text, testRecord.options.phones.phone5);
		
		AppendField(text, testRecord.fields[name]);
		AppendField(text, testRecord.fields[firstName]);
		AppendField(text, testRecord.fields[company]);
		AppendField(text, testRecord.fields[phone1]);
		AppendField(text, testRecord.fields[phone2]);
		AppendField(text, testRecord.fields[phone3]);
		AppendField(text, testRecord.fields[phone4]);
		AppendField(text, testRecord.fields[phone5]);
		AppendField(text, testRecord.fields[address]);
		AppendField(text, testRecord.fields[city]);
		AppendField(text, testRecord.fields[state]);
		AppendField(text, testRecord.fields[zipCode]);
		AppendField(text, testRecord.fields[country]);
		AppendField(text, testRecord.fields[title]);
		AppendField(text, testRecord.fields[custom1]);
		AppendField(text, testRecord.fields[custom2]);
		AppendField(text, testRecord.fields[custom3]);
		AppendField(text, testRecord.fields[custom4]);
		AppendField(text, testRecord.fields[note]);

		// Export attributes to export category and deletion info		
		DmRecordInfo (dbP, index, &attr, NULL, NULL);	
		AppendNumField(text, attr);
		fprintf(fileOut, "%s\n", text);

		MemHandleUnlock(testRecordH);
	}
	fclose(fileOut);

}



/**********************************************************************
 * Export to another CSV format.  Useful for other formats.
 *
 * DoAddrExportOther <access ptr> <file out>
 ***********************************************************************/
 
static void DoAddrExportOther(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	char			fileOutName[64] = "\0";
	AddrDBRecordType	testRecord;
	MemHandle testRecordH;
	char			text[256];
	int 			index;
	int 			numOfRecords;
	int			i;


	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
		if (!*fileOutName)
			sscanf(argv[i], "%s", fileOutName);
		else
			usageErr = true;
	
		}

	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr> <file out>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}

	FILE*	fileOut=0;
	fileOut = fopen(fileOutName, "w");
	if (!fileOut) {
		sprintf(text, "\nCan\'t use file: %s\n", fileOutName);
		ShlInsertText(text);
		return;
		}

	numOfRecords = DmNumRecordsInCategory(dbP, dmAllCategories);
	for (index = 0; index < numOfRecords; index++) {
		if (AddrDBGetRecord(dbP, index, &testRecord, &testRecordH) != 0)
		{
			ShlInsertText("Error!");
			break;
		}
	
		*text = '\0';
		AppendField(text, testRecord.fields[custom1]);
		AppendField(text, testRecord.fields[custom2]);
		AppendField(text, testRecord.fields[note]);
		AppendField(text, testRecord.fields[title]);
		AppendField(text, testRecord.fields[firstName]);
		AppendField(text, testRecord.fields[name]);
		AppendField(text, testRecord.fields[company]);
		AppendField(text, testRecord.fields[address]);
		AppendField(text, testRecord.fields[city]);
		AppendField(text, testRecord.fields[state]);
		AppendField(text, testRecord.fields[zipCode]);
		AppendField(text, testRecord.fields[custom4]);
		AppendField(text, testRecord.fields[phone2]);
		AppendField(text, testRecord.fields[phone1]);
		fprintf(fileOut, "%s\n", text);

		MemHandleUnlock(testRecordH);
	}
	fclose(fileOut);

}


/**********************************************************************
 * Function to write a string to the disk file for vcard exporting.
 ***********************************************************************/

static void PutString(void * stream, const Char * const stringP)
{
	fwrite(stringP, sizeof(UInt8), strlen(stringP), (FILE *) stream);
}


/**********************************************************************
 * Export to vCard format and store in a disk file.
 *
 * DoAddrExportVCard <access ptr> <file out>
 *
 * REVISION: 06/20/00 ABa: Pdi library integration
 */
 
 
 /* the call to AddrExportVCARD and inserting a comment in the simulator
 *
 ***********************************************************************/
 
static void DoAddrExportVCard(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	char			fileOutName[64] = "\0";
	AddrDBRecordType	outRecord;
	MemHandle 		outRecordH;
	char			text[256];
	int 			index;
	int 			numOfRecords;
	int			i;


	for (i=1; i<argc; i++) {
		if (i == 1)
			sscanf(argv[i], "%lx", &dbP);
		else
		if (!*fileOutName)
			sscanf(argv[i], "%s", fileOutName);
		else
			usageErr = true;
	
		}

	if (!dbP) dbP = FindOpenedAddressDatabase();
	
	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr> <file out>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}

	FILE*	fileOut=0;
	fileOut = fopen(fileOutName, "wb");
	if (!fileOut) {
		sprintf(text, "\nCan\'t use file: %s\n", fileOutName);
		ShlInsertText(text);
		return;
		}
	
	
	numOfRecords = DmNumRecordsInCategory(dbP, dmAllCategories);
	for (index = 0; index < numOfRecords; index++) {
		if (AddrDBGetRecord(dbP, index, &outRecord, &outRecordH) != 0)
		{
			ShlInsertText("Error!");
			break;
		}
		
		ShlInsertText("Disabled feature (ABa).");

		MemHandleUnlock(outRecordH);
	}
	
	fclose(fileOut);
}


/**********************************************************************
 * Set the Address application chunk to the defaults.
 *
 * AddrChangeSortOrder <access ptr> <1 = sort by company>
 ***********************************************************************/
static void DoAddrChangeSortOrder(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	Boolean 	sortByCompany = false;
	char			text[256];
	long t1, t2;
	int			i;

	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		if (!sortByCompany)
			sortByCompany = *argv[i] == '1';
		else
			usageErr = true;
		
		}

	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr> <1 = sort by company>\n", argv[0]);
		ShlInsertText(text);
		return;
		}

	t1 = TimGetTicks();
	Err err = AddrDBChangeSortOrder(dbP, sortByCompany);
	t2 = TimGetTicks();
	if (err) {
		ShlInsertText("\n##ERROR Setting defaults\n");
		}
	else {
		sprintf(text, "%d Pilot ticks\n", (t2-t1)*40);
		ShlInsertText(text);
		}
}



/**********************************************************************
 * Get an record and print in Address format.
 *
 * DoAddrChangeRecord <access ptr> <index>
 ***********************************************************************/
static void DoAddrChangeRecord(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	char			text[256];
	AddrDBRecordType	testRecord;
	MemHandle testRecordH;
	UInt16 index = 0;
	char newName[] = "Stewart";
	char newNote[] = "Some handy notes.";
	AddrDBRecordFlags changedFields;
	UInt16 result;
	int			i;
	
	
	* (int *) &changedFields = 0;
	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
		if (!index)
			sscanf(argv[i], "%d", &index);
		else
			usageErr = true;
		
		}

	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr> <index>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}


	if (AddrDBGetRecord(dbP, index, &testRecord, &testRecordH) != 0)
		{
		ShlInsertText("Error!");
		return;
		}
	
	changedFields.bits.note = 1;
	testRecord.fields[note] = newNote;
	changedFields.bits.name = 1;
	testRecord.fields[name] = newName;
	
	result = AddrDBChangeRecord(dbP, &index, &testRecord, changedFields);
	MemHandleUnlock(testRecordH);


	sprintf(text, "%d\n", result);
	ShlInsertText(text);
}





/**********************************************************************
 * Support for Roger's commands
 *
 * returns 0 if successfully found command
 ***********************************************************************/
int ShlDoAppCmd(int argc, Char * argv[])
{
	if (!ShlStrCmpi(argv[0], "AddrAppInfoInit")) 
		 DoAddrSetInfoDefaults(argc, argv);
	else
	if (!ShlStrCmpi(argv[0], "AddrTestNewRecord")) 
		DoAddrTestNewRecord(argc, argv);
	else
	if (!ShlStrCmpi(argv[0], "AddrImport")) 
		 DoAddrImport(argc, argv);
	else
	if (!ShlStrCmpi(argv[0], "AddrImportZoomer")) 
		 DoAddrImportZoomer(argc, argv);
	else
	if (!ShlStrCmpi(argv[0], "AddrImportVCard")) 
		 DoAddrImportVCard(argc, argv);
	else
	if (!ShlStrCmpi(argv[0], "AddrExport")) 
		DoAddrExport(argc, argv);
	else
	if (!ShlStrCmpi(argv[0], "AddrExportOther")) 
		DoAddrExportOther(argc, argv);
	else
	if (!ShlStrCmpi(argv[0], "AddrExportVCard")) 
		DoAddrExportVCard(argc, argv);
	else
	if (!ShlStrCmpi(argv[0], "AddrChangeSortOrder")) 
		DoAddrChangeSortOrder(argc, argv);
	else
	if (!ShlStrCmpi(argv[0], "AddrGetRecord")) 
		DoAddrGetRecord(argc, argv);
	else
	if (!ShlStrCmpi(argv[0], "AddrChangeRecord")) 
		DoAddrChangeRecord(argc, argv);
		
	else
	if (!ShlStrCmpi(argv[0], "AddrBuildSyncDB")) 
		DoAddrBuildSyncDB(argc, argv);


	// Command not found
	else
		return 1;
		
		
	return 0;
}
