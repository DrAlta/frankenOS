/******************************************************************************
 *
 * Copyright (c) 1996-2002 PalmSource, Inc. All rights reserved.
 *
 * File: ShellCmdMail.cpp
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 * Description:
 *	  This file contains the console commands for Mail application.
 *
 *****************************************************************************/

// Pilot Includes 
#include "SysAll.h"

// C library Includes
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// DB includes
#include "DateTime.h"
#include "MailDB.h"

#include "ShellCmd.h"



#define mailDBType				'DATA'
#define sysFileCMail				'mail'


typedef void ShellCmdFuncType (int argc, Char * argv[]);
typedef ShellCmdFuncType * ShellCmdFuncPtr;
typedef struct {
	Char *				longName;
	Char *				shortName;
	ShellCmdFuncPtr	func;
} ShellCmdInfoType;

#pragma pcrelstrings off


/**********************************************************************
 * find an open appointment database
 *
 * Parameters: none
 ***********************************************************************/
static DmOpenRef FindOpenedMailDatabases (void)
{
	DmOpenRef	dbP=0;
	LocalID		dbID;
	UInt16			mode;
	UInt16			cardNo;
	UInt32			dbType;
	UInt32			dbCreator;
	
	do {
		dbP = DmNextOpenDatabase(dbP);
		if (!dbP) break;

		Err err = DmOpenDatabaseInfo(dbP, &dbID, NULL, &mode, &cardNo, NULL);
		if (err) 
			{
			ShlInsertText("\n#ERROR getting info");
			}
		else
			{
			DmDatabaseInfo(cardNo, dbID, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				&dbType, &dbCreator);

			if ( (dbType == mailDBType) && (dbCreator == sysFileCMail) )
				return (dbP);
			}
		} while (1);


	return(0);
}


/**********************************************************************
 * Set the appointment application chunk to the defaults.
 *
 * MailSetInfoDefaults <access ptr>
 ***********************************************************************/
static void DoMailSetInfoDefaults(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	char		text[256];
	int		i;

	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			usageErr = true;
		
		}

	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr>\n", argv[0]);
		ShlInsertText(text);
		return;
		}

	Err err = MailAppInfoInit (dbP);
	if (err) {
		ShlInsertText("\n##ERROR Setting defaults\n");
		}
	else {
		ShlInsertText("Success!\n");
		}
}



/**********************************************************************
 * Test the newRecord function.
 *
 * DoMailTestNewRecord <access ptr>
 ***********************************************************************/ 
static void DoMailNewRecords(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	UInt16 			index;
	char			text[256];
	int			i;

	MailDBRecordType	testRecord1 = {
		92, 5, 30,
		{0, 0},
		{1, 0, 0, 0, priorityNormal, sentCC, 0 },
		"Test Mail Message",
		"joe@palm.com (Joe Sipher)",
		"monty@palm.com (Monty Boyer)\nart@palm.com (Art Lamb)",
		"roger@palm.com (Roger Flores)",
		"mcauwet@palm (Marian Cauwet)",
		"replyTo@alo.com",
		"art@palm.com (Art Lamb)",
		"This is a test mail message\n2\n3\n4\n5\n6\n7\n8\n9\n10\n11\n12"
	};
	
	MailDBRecordType	testRecord2 = {
		92, 6, 3,
		{0, 0},
		{0, 1, 0, 0, 1, 0, 0 },
		"Message Two",
		"alamb@aol.com",
		"Engineering@palm.com",
		"monty@palm.com (Monty Boyer)\njoe@palm.com (Joe Sipher)",
		"",
		"",
		"",
		"This is test message two."
	};
	
	MailDBRecordType	testRecord3 = {
		92, 6, 3,
		{0, 0},
		{0, 0, 1, 0, 1, 0, 0 },
		"Message Three",
		"Supervisor",
		"Engineering@palm.com",
		"",
		"",
		"",
		"",
		"This is test message three."
	};
	
	MailDBRecordType	testRecord4 = {
		92, 6, 3,
		{0, 0},
		{0, 0, 0, 1, 1, 0, 0 },
		"Message Four",
		"joe (Joe Sipher)",
		"Engineering@palm.com",
		"",
		"",
		"",
		"",
		"This is test message four."
	};
	
	MailDBRecordType	testRecord5 = {
		92, 6, 4,
		{0, 0},
		{0, 0, 0, 0, 1, 0, 0 },
		"Message Five",
		"Art",
		"Engineering@palm.com",
		"",
		"",
		"",
		"",
		"This is test message five."
	};
	
	MailDBRecordType	testRecord6 = {
		92, 6, 4,
		{0, 0},
		{0, 0, 0, 0, 1, 0, 0 },
		"Message Six",
		"Art",
		"Engineering@palm.com",
		"Company",
		"",
		"",
		"",
		"This is test message six."
	};
	
	MailDBRecordType	testRecord7 = {
		92, 6, 5,
		{0, 0},
		{0, 0, 0, 0, 1, 0, 0 },
		"Message Seven",
		"Art",
		"Engineering@palm.com",
		"",
		"",
		"",
		"",
		"This is test message seven."
	};
	
	MailDBRecordType	testRecord8 = {
		92, 6, 5,
		{0, 0},
		{0, 0, 0, 0, 1, 0, 0 },
		"Message Eight",
		"Art",
		"Engineering@palm.com",
		"",
		"",
		"",
		"",
		"This is test message eight."
	};
	
	MailDBRecordType	testRecord9 = {
		92, 6, 10,
		{0, 0},
		{0, 0, 0, 0, 1, 0, 0 },
		"Message Nine",
		"Art",
		"Engineering@palm.com",
		"",
		"",
		"",
		"",
		"This is test message nine."
	};
	
	MailDBRecordType	testRecord10 = {
		92, 6, 10,
		{0, 0},
		{0, 0, 0, 0, 1, 0, 0 },
		"Message Ten",
		"Art",
		"Engineering@palm.com",
		"",
		"",
		"",
		"",
		"This is test message ten."
	};
	
	MailDBRecordType	testRecord11 = {
		92, 6, 10,
		{0, 0},
		{0, 0, 0, 0, 1, 0, 0 },
		"Message Eleven",
		"Art",
		"Engineering@palm.com",
		"",
		"",
		"",
		"",
		"This is test message eleven."
	};
	
	MailDBRecordType	testRecord12 = {
		92, 6, 20,
		{0, 0},
		{0, 0, 0, 0, 1, 0, 0 },
		"Message Twelve",
		"Art",
		"Engineering@palm.com",
		"",
		"",
		"",
		"",
		"This is test message Twelve."
	};
	

	
	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			usageErr = true;
		
		}

	if (!dbP)
		dbP = FindOpenedMailDatabases ();
		
	if (!dbP)
		{
		ShlInsertText("Could not find an open mail database\n");
		return;
		}


	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}

	MailNewRecord(dbP, &testRecord1, &index);
	MailNewRecord(dbP, &testRecord2, &index);
	MailNewRecord(dbP, &testRecord3, &index);
	MailNewRecord(dbP, &testRecord4, &index);
	MailNewRecord(dbP, &testRecord5, &index);
	MailNewRecord(dbP, &testRecord6, &index);
	MailNewRecord(dbP, &testRecord7, &index);
	MailNewRecord(dbP, &testRecord8, &index);
	MailNewRecord(dbP, &testRecord9, &index);
	MailNewRecord(dbP, &testRecord10, &index);
	MailNewRecord(dbP, &testRecord11, &index);
	MailNewRecord(dbP, &testRecord12, &index);


	ShlInsertText("New records added\n");
}


/**********************************************************************
 *	Function:		PrintMailRecord
 *
 *	Description:	Print the details of an appt record.  Includes
 *						deleted records, and the
 *						deleted, dirty, secret, & busy flags.
 *
 * Usage:			PrintMailRecord (dbP, index)
 *
 *	Revision History:
 *
 *		Name		Date		Description
 *		----		----		-----------
 *		kcr		10/23/95	display deleted records, sync-status flags
 *
 ***********************************************************************/
static void PrintMailRecord (DmOpenRef dbP, UInt16 index)
{
	char 					text[256];
	LocalID				chunk;
	UInt16					attr;
	UInt32					uniqueID;
	VoidHand				recordH;
	MailDBRecordType	record;



	DmRecordInfo (dbP, index, &attr, &uniqueID, &chunk);

	// Print record index.
	sprintf (text, "\nIndex:   %d", index);
	ShlInsertText (text);

	// Print the unique id
	sprintf (text, ",  unique id: %ld", uniqueID);
	ShlInsertText (text);
	
	if ((attr & dmRecAttrDelete) &&
		 chunk)
		ShlInsertText ("\tArchived");
	else if (attr & dmRecAttrDelete)
		ShlInsertText ("\tDeleted");
	if (attr & dmRecAttrDirty)
		ShlInsertText ("\tDirty");
	if (attr & dmRecAttrBusy)
		ShlInsertText ("\tBusy");
	if (attr & dmRecAttrSecret)
		ShlInsertText ("\tSecret");

	if (attr & dmRecAttrDelete)
		return;

	// Print the category
	sprintf (text, "\tCategory: %d", attr & dmRecAttrCategoryMask);
	ShlInsertText (text);


	if (MailGetRecord(dbP, index, &record, &recordH) != 0)
		{
		ShlInsertText("Error!");
		return;
		}

	// Print date
	sprintf(text, "\nDate:    %d/%d/%d", record.date.month,
		record.date.day, record.date.year+4);
	ShlInsertText(text);
	

	// Print the flags
	ShlInsertText ("\nFlags:   ");
	sprintf (text, "Priority: %d   ", record.flags.priority);
	ShlInsertText (text);

	if (record.flags.read)
		ShlInsertText ("Read  ");

	if (record.flags.signature)
		ShlInsertText ("Signature  ");

	if (record.flags.confirmRead)
		ShlInsertText ("Confirm Read  ");

	if (record.flags.confirmDelivery)
		ShlInsertText ("Confirm Delivery  ");
		

	if (*record.subject)
		{
		ShlInsertText ("\nSubject: ");
		ShlInsertText (record.subject);
		}
	
	if (*record.from)
		{
		ShlInsertText ("\nFrom:    ");
		ShlInsertText (record.from);
		}
	
	if (*record.to)
		{
		ShlInsertText ("\nTo:      ");
		ShlInsertText (record.to);
		}
	
	if (*record.cc)
		{
		ShlInsertText ("\nCC:      ");
		ShlInsertText (record.cc);
		}
	
	if (*record.bcc)
		{
		ShlInsertText ("\nBCC:      ");
		ShlInsertText (record.bcc);
		}
	
	if (*record.body)
		{
		ShlInsertText ("\nBody:    ");
		ShlInsertText (record.body);
		}

	ShlInsertText ("\n");


	MemHandleUnlock (recordH);
}


/**********************************************************************
 * Get an record and print in Address format.
 *
 * DoMailGetRecord <access ptr> <index>
 ***********************************************************************/
static void DoMailGetRecord(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	char			text[256];
	UInt16 index = 0;
	int			i;
	
	
	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
		if (!index)
			sscanf(argv[i], "%d", &index);
		else
			usageErr = true;
		
		}

	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr> <index>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}

	PrintMailRecord (dbP, index);
}


/**********************************************************************
 * Get an record and print in Address format.
 *
 * DoMailGetRecord <access ptr> <index>
 *
 ***********************************************************************/
static void DoMailGetAll(int argc, Char * argv[])
{
	int					i;
	UInt16 					index = 0;
	char					text[256];
	Boolean				usageErr = false;
	DmOpenRef			dbP=0;
		
	if ( argc > 1 && !strcmp(argv[1], "?") )
		goto Help;

	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			usageErr = true;
		}

	if (usageErr) {
		goto SyntaxOnly;
		}

	if (!dbP)
		dbP = FindOpenedMailDatabases ();
		
	if (!dbP)
		{
		ShlInsertText("Could not find an open appointment database\n");
		return;
		}


	for (index = 0; index < DmNumRecords(dbP); index++)
		PrintMailRecord (dbP, index);
	ShlInsertText("\n");

	return;


Help:
	ShlInsertText("\nPrint all records in the appointment database\n");
	ShlInsertText("and their sync flags.\n");

SyntaxOnly:
	sprintf(text, "Syntax: %s [access ptr]\n", argv[0]);  
	ShlInsertText(text);
}





/**********************************************************************
 * Test changing an appointment record.
 *
 * DoMailChangeRecord <access ptr> <index>
 ***********************************************************************/
static void DoMailChangeRecord(int argc, Char * argv[])
{
	Int16							i;
	Char							text[256];
	UInt16 							result;
	UInt16 							index = 0;
	Boolean						usageErr = false;
	VoidHand						recordH;
	DmOpenRef					dbP = 0;
	MailDBRecordType			testRecord;
	MailChangedFieldsType	changedFields = { 0,0,0,0,0,0,0,};
	
	
	* (int *) &changedFields = 0;
	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
		if (!index)
			sscanf(argv[i], "%d", &index);
		else
			usageErr = true;
		
		}

	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr> <index>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}


	if (MailGetRecord(dbP, index, &testRecord, &recordH) != 0)
		{
		ShlInsertText("Error!");
		return;
		}
	
	testRecord.date.month = 12;
	changedFields.date = true;
	
	MemHandleUnlock (recordH);
	
	result = MailChangeRecord (dbP, &index, &testRecord, changedFields);

	sprintf(text, "%d\n", result);
	ShlInsertText(text);
}


/**********************************************************************
 * Sort the Mail Database
 *
 * DoMailSync
 ***********************************************************************/
static void DoMailSync (int argc, Char * argv[])
{
	int					i;
	UInt16 					index = 0;
	char					text[256];
	Boolean				usageErr = false;
	DmOpenRef			dbP=0;
		
	if ( argc > 1 && !strcmp(argv[1], "?") )
		goto Help;


	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			usageErr = true;
		}

	if (usageErr) {
		goto SyntaxOnly;
		}

	if (!dbP)
		dbP = FindOpenedMailDatabases ();
		
	if (!dbP)
		{
		ShlInsertText("Could not find an open appointment database\n");
		return;
		}


	// Send a sync notification to the app.  This only works when the
	// app is running in Emulation mode.
	MailSort (dbP);
	ShlInsertText ("\n");

	return;


Help:
	ShlInsertText("\nSend a sync notification to the app (really just sorts it).\n");

SyntaxOnly:
	sprintf(text, "Syntax: %s [access ptr]\n", argv[0]);  
	ShlInsertText(text);
}


/**********************************************************************
 * Add default date record to the database.
 *
 * DoMailDefaultData <access ptr>
 ***********************************************************************/ 
static void DoMailDefaultData(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	UInt16 			index;
	char			text[256];
	int			i;

	MailDBRecordType	testRecord1 = {
		93, 3, 14,
		{9, 0},
		{0, 0, 0, 0, priorityNormal, sentTo, 0 },
		"Welcome",
		"support@palm.usr.com (U.S. Robotics)",
		"PalmPilot Mail User",
		"",
		"",
		"",
		"PalmPilot Mail User",
	"Welcome to PalmPilot Mail!\n" 
	"\n"
	"In order for your desktop e-mail messages to appear here, you must "
	"configure HotSync on your desktop as follows.\n"
	"\n"
	"1. Install PalmPilot Desktop on the \n"
	"     provided CD or diskettes.\n"
	"2. On your Windows 95/NT 4.0 PC, \n"
	"     click the HotSync system tray \n"
	"     icon and select Custom.  In\n"
	"     Windows 3.1x, double-click on the \n"
	"     Customize icon in the PalmPilot \n"
	"     2.0 program group.\n"
	"3. Select the Mail conduit and\n"
	"     click the Change button. \n"
	"4. Click on the Activate \n"
	"     PalmPilot Mail checkbox.\n"
	"5. Select the desktop e-mail \n"
	"     system you use in the\n"
	"     Synchronize with drop-down\n"
	"     menu.\n"
	"6. Enter the User Name and\n"
	"     Password you use to log into\n"
	"     your desktop e-mail system.\n"
	"7. Click the Help button to\n"
	"     learn about other settings\n"
	"     specific to your desktop\n"
	"     e-mail system you may need to\n"
	"     configure.\n"
	"8. Click OK.\n"
	"9. Click Done.\n"
	"\n"
	"The next time you synchronize, the messages from your desktop inbox will "
	"appear right here.  Read, reply, forward, delete, or create new messages.  "
	"The next time you synchronize, all those actions will be reflected both "
	"here and on your desktop e-mail system.\n"
	"\n"
	"Enjoy PalmPilot Mail!"
	};


	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			usageErr = true;
		
		}

	if (!dbP)
		dbP = FindOpenedMailDatabases ();
		
	if (!dbP)
		{
		ShlInsertText("Could not find an open mail database\n");
		return;
		}


	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}

	MailNewRecord(dbP, &testRecord1, &index);


	ShlInsertText("New records added\n");
}


/**********************************************************************
 * Support for Mail commands
 *
 * returns 0 if successfully found command
 ***********************************************************************/
int ShlDoDBCmd(int argc, Char * argv[])
{
	int i;
	ShellCmdInfoType cmd [] ={ 	
		"MailAppInfoInit", 			"msi",  	DoMailSetInfoDefaults,
		"MailNew",						"mnr",	DoMailNewRecords,
		"MailGetRecord",				"mgr",	DoMailGetRecord,
		"MailGetAll",					"md",		DoMailGetAll,
		"MailChangeRecord",			"mcr",	DoMailChangeRecord,
		"MailSync",						"ms",		DoMailSync,
		"MailDefaultData",			"mdd",	DoMailDefaultData,
		};
			
	for (i = 0; i < sizeof (cmd) / sizeof (ShellCmdInfoType); i++)
		{
		if ( (!ShlStrCmpi(argv[0], cmd[i].longName)) ||
			  (!ShlStrCmpi(argv[0], cmd[i].shortName)))
			{
			cmd[i].func (argc, argv);
			return 0;
			}
		}
	return 1;
}
