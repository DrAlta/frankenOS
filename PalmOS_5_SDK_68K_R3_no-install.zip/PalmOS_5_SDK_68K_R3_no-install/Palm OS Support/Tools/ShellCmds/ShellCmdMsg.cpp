/******************************************************************************
 *
 * Copyright (c) 1996-2002 PalmSource, Inc. All rights reserved.
 *
 * File: ShellCmdMsg.cpp
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 * Description:
 *	  This file is where customized console shell comands are kept.
 * Currently this is a stub which the emulator calls when it doesn't
 * recognize a command.  The code here shows how to add a custom command.
 * The custom command is useless, but it does provide a template to add commands.
 * An application programmer can copy this file to their application 
 * folder and then customize it to handle as many commands as they wish.
 *
 *****************************************************************************/

#if 0
#include <PalmOS.h>

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "ShellCmd.h"

typedef void ShellCmdFuncType (int argc, Char * argv[]);
typedef ShellCmdFuncType * ShellCmdFuncPtr;
typedef struct {
	Char *				longName;
	Char *				shortName;
	ShellCmdFuncPtr	func;
} ShellCmdInfoType;
#endif

/***********************************************************************
 *
 *	Copyright (c) Palm Computing 1996 -- All Rights Reserved
 *
 * PROJECT:  Pilot 2.0
 *
 * FILE:     ShellCmdMsg.cpp
 *
 * AUTHOR:	 Art Lamb: May 30, 1996
 *
 * DECLARER: Mail
 *
 * DESCRIPTION:
 *	  This file contains the console commands for Mail application.
 *
 ***********************************************************************/

// Pilot Includes 
#include <PalmOS.h>

// C library Includes
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// DB includes
#include "DateTime.h"
#include "MsgDB.h"

#include "ShellCmd.h"


typedef void ShellCmdFuncType (int argc, Char * argv[]);
typedef ShellCmdFuncType * ShellCmdFuncPtr;
typedef struct {
	Char *				longName;
	Char *				shortName;
	ShellCmdFuncPtr	func;
} ShellCmdInfoType;

#pragma pcrelstrings off


#define msgDBType				'DATA'
#define sysFileCMessaging		'msgs'


/**********************************************************************
 * find an open appointment database
 *
 * Parameters: none
 ***********************************************************************/
static DmOpenRef FindOpenedMailDatabases (void)
{
	DmOpenRef	dbP=0;
	LocalID		dbID;
	UInt16			mode;
	UInt16			cardNo;
	UInt32			dbType;
	UInt32			dbCreator;
	
	do {
		dbP = DmNextOpenDatabase(dbP);
		if (!dbP) break;

		Err err = DmOpenDatabaseInfo(dbP, &dbID, NULL, &mode, &cardNo, NULL);
		if (err) 
			{
			ShlInsertText("\n#ERROR getting info");
			}
		else
			{
			DmDatabaseInfo(cardNo, dbID, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				&dbType, &dbCreator);

			if ( (dbType == msgDBType) && (dbCreator == sysFileCMessaging) )
				return (dbP);
			}
		} while (1);


	return(0);
}


/**********************************************************************
 * Set the appointment application chunk to the defaults.
 *
 * MailSetInfoDefaults <access ptr>
 ***********************************************************************/
static void DoMailSetInfoDefaults(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	char		text[256];
	int		i;

	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			usageErr = true;
		
		}

	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr>\n", argv[0]);
		ShlInsertText(text);
		return;
		}

	Err err = MsgAppInfoInit (dbP);
	if (err) {
		ShlInsertText("\n##ERROR Setting defaults\n");
		}
	else {
		ShlInsertText("Success!\n");
		}
}


//#define HAS_ENOUGH_MEMORY
/**********************************************************************
 * Test the newRecord function.
 *
 * DoMailTestNewRecord <access ptr>
 ***********************************************************************/ 
static void DoMailNewRecords(int argc, Char * argv[])
{
#ifdef HAS_ENOUGH_MEMORY
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	UInt16 			index;
	char			text[256];
	int			i;
	
	MailDBRecordType	testRecord1 = {
		{TimGetTicks(),0},
		TimGetSeconds(),
		{1, 0, 0, 0, priorityNormal, sentTo, msgComplete, markNone, attachmentNone, 0, 0,0, 0, 0 },
		0,
		0,
		505,
		50,
		"Test Mail Message",
		"joe@palm.com (Joe Sipher)",
		"monty@palm.com (Monty Boyer)\nart@palm.com (Art Lamb)",
		"Roger@palm.com (Roger Flores)",
		"mcauwet@palm (Marian Cauwet)",
		"replyTo@aol.com",
		"art@palm.com (Art Lamb)",
		"This is a test mail message\n"
		"1, 0, 0, 0, priorityNormal, sentCC, msgComplete, markNone, attachmentNone, 0, 0,0, 0, 0\n"
		"3\n4\n5\n6\n7\n8\n9\n10\n11\n12(end)",
		"",
		""
	};
	
	MsgDBRecordType	testRecord2 = {
		{TimGetTicks(),0},
		TimGetSeconds(),
		{0, 1, 0, 0, priorityNormal, sentTo, msgPartial, markNone, attachmentNone, 0, 0, 0, 0, 0 },
		0,
		0,
		22,
		0,
		"Message Two (partial)",
		"alamb@aol.com",
		"Engineering@palm.com",
		"monty@palm.com (Monty Boyer)\njoe@palm.com (Joe Sipher)",
		"",
		"",
		"",
		"This is test message two.\n"
		"0, 1, 0, 0, priorityNormal, sentTo, msgPartial, markNone, attachmentNone, 0, 0,0, 50, 0, 0(end)",
		"",
		""
	};
	
	MsgDBRecordType	testRecord3 = {
		{TimGetTicks(),0},
		TimGetSeconds(),
		{0, 0, 1, 0, priorityNormal, sentTo, msgPreview, markNone, attachmentNone, 0, 0, 0, 0, 0 },
		0,
		0,
		33,
		10,
		"3 preview",
		"Supervisor",
		"Engineering@palm.com",
		"",
		"",
		"",
		"",
		"This is test message three.\n"
		"0, 0, 1, 0, priorityNormal, sentTo, msgPreview, markNone, attachmentNone, 0, 0,0, 10, 0, 0(end)",
		"",
		""
	};
	
	MsgDBRecordType	testRecord4 = {
		{TimGetTicks(),0},
		TimGetSeconds(),
		{0, 0, 0, 1, priorityNormal, sentTo, msgComplete, markNone, attachmentOnDesktop, 0, 0, 0, 0, 0 },
		0,
		0,
		44,
		0,
		"Message Four",
		"joe (Joe Sipher)",
		"Engineering@palm.com",
		"",
		"",
		"",
		"",
		"This is test message four."
		"0, 0, 0, 1, priorityNormal, sentTo, msgComplete, markNone, attachmentOnDesktop(3), 0, 0,0, 0, 0, 0\n"
		"1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n11\n12(end)",
		"Attachment1, attachemnt2, attachment3",
		""
	};
	
	MsgDBRecordType	testRecord5 = {
		{TimGetTicks(),0},
		TimGetSeconds(),
		{0, 0, 0, 0, priorityNormal, sentTo, msgComplete, markNone, attachmentStripped, 0, 0, 0, 0, 0 },
		0,
		0,
		55,
		0,
		"Message Five",
		"Art",
		"Engineering@palm.com",
		"",
		"",
		"",
		"",
		"This is test message five.\n"
		"0, 0, 0, 0, priorityNormal, sentTo, msgComplete, markNone, attachmentStripped(3), 0, 0,0, 0, 0, 0(end)",
		"Attachment1, attachemnt2, attachment3",""
	};
	
	MsgDBRecordType	testRecord6 = {
		{TimGetTicks(),0},
		TimGetSeconds(),
		{0, 0, 0, 0, priorityNormal, sentTo, msgComplete, markNone, attachmentNone, 0, 0, 0, 0, 0 },
		0,
		0,
		66,
		0,
		"Message Six",
		"Art",
		"Engineering@palm.com",
		"Company",
		"",
		"",
		"",
		"This is test message six.\n"
		"0, 0, 0, 0, priorityNormal, sentTo, msgComplete, markNone, attachmentNone, 0, 0, 0, 0, 0, 0(end)",
		"",
		""
	};
	
	MsgDBRecordType	testRecord7 = {
		{TimGetTicks(),0},
		TimGetSeconds(),
		{0, 0, 0, 0, priorityNormal, sentTo, msgComplete, markNone, attachmentNone, 0, 0, 0, 0, 0 },
		0,
		0,
		77,
		0,
		"Message Seven",
		"Art",
		"Engineering@palm.com",
		"",
		"",
		"",
		"",
		"This is test message seven.\n"
		"0, 0, 0, 0, priorityNormal, sentTo, msgComplete, markNone, attachmentNone, 0, 0, 0, 0, 0(end)",
		"",
		""
	};
	
	MsgDBRecordType	testRecord8 = {
		{TimGetTicks(),0},
		TimGetSeconds(),
		{0, 0, 0, 0, priorityHigh, sentTo, msgComplete, markNone, attachmentNone, 0, 0, 0, 0, 0 },
		0,
		0,
		88,
		0,
		"Message Eight",
		"Art",
		"Engineering@palm.com",
		"",
		"",
		"",
		"",
		"This is test message eight.\n"
		"0, 0, 0, 0, priorityHigh, sentTo, msgComplete, markNone, attachmentNone, 0, 0,0, 0, 0, 0(end)",
		"",
		""
	};
	
	MsgDBRecordType	testRecord9 = {
		{TimGetTicks(),0},
		TimGetSeconds(),
		{0, 0, 0, 0, priorityHigh, sentTo, msgComplete, markNone, attachmentNone, 0, 0, 0, 0, 0 },
		0,
		0,
		99,
		0,
		"Message Nine",
		"Art",
		"Engineering@palm.com",
		"",
		"",
		"",
		"",
		"This is test message nine.\n"
		"0, 0, 0, 0, priorityHigh, sentTo, msgComplete, markNone, attachmentNone, 0, 0,0, 0, 0, 0(end)",
		"",
		""
	};
	
	MsgDBRecordType	testRecord10 = {
		{TimGetTicks(),0},
		TimGetSeconds(),
		{0, 0, 0, 0, priorityLow, sentTo, msgComplete, markNone, attachmentNone, 0, 0, 0, 0, 0 },
		0,
		0,
		100,
		0,
		"Message Ten",
		"Art",
		"Engineering@palm.com",
		"",
		"",
		"",
		"",
		"This is test message ten.\n"
		"0, 0, 0, 0, priorityLow, sentTo, msgComplete, markNone, attachmentNone, 0, 0,0, 0, 0, 0(end)",
		"",
		""
	};
	
	MsgDBRecordType	testRecord11 = {
		{TimGetTicks(),0},
		TimGetSeconds(),
		{0, 0, 0, 0, priorityLow, sentTo, msgComplete, markNone, attachmentNone, 0, 0, 0, 0, 0 },
		0,
		0,
		111,
		0,
		"Message Eleven",
		"Art",
		"Engineering@palm.com",
		"",
		"",
		"",
		"",
		"This is test message eleven.\n"
		"0, 0, 0, 0, priorityLow, sentTo, msgComplete, markNone, attachmentNone, 0, 0,0, 0, 0, 0(end)",
		"",
		""
	};
	
	MsgDBRecordType	testRecord12 = {
		{TimGetTicks(),0},
		TimGetSeconds(),
		{0, 0, 0, 0, priorityNormal, sentTo, msgComplete, markNone, attachmentNone, 0, 0, 0, 0, 0 },
		0,
		0,
		122,
		0,
		"Message Twelve",
		"Art",
		"Engineering@palm.com",
		"",
		"",
		"",
		"",
		"This is test message Twelve.\n"
		"0, 0, 0, 0, priorityNormal, sentTo, msgComplete, markNone, attachmentNone, 0, 0,0, 0, 0, 0(end)",
		"",
		""
	};
	

	
	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			usageErr = true;
		
		}

	if (!dbP)
		dbP = FindOpenedMailDatabases ();
		
	if (!dbP)
		{
		ShlInsertText("Could not find an open mail database\n");
		return;
		}


	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}

	MsgNewRecord(dbP, &testRecord1, &index);
	MsgNewRecord(dbP, &testRecord2, &index);
	MsgNewRecord(dbP, &testRecord3, &index);
	MsgNewRecord(dbP, &testRecord4, &index);
	MsgNewRecord(dbP, &testRecord5, &index);
	MsgNewRecord(dbP, &testRecord6, &index);
	MsgNewRecord(dbP, &testRecord7, &index);
	MsgNewRecord(dbP, &testRecord8, &index);
	MsgNewRecord(dbP, &testRecord9, &index);
	MsgNewRecord(dbP, &testRecord10, &index);
	MsgNewRecord(dbP, &testRecord11, &index);
	
	//set the date to 12/30 of some year to test the width of the date column
	{
	DateTimeType dateTime;

	dateTime.second = 0;
	dateTime.minute = 0;
	dateTime.hour = 0;
	dateTime.day = 30;
	dateTime.month =12;
	dateTime.year = 1997;

	testRecord12.timeStamp = TimDateTimeToSeconds(&dateTime);
	MsgNewRecord(dbP, &testRecord12, &index);
	}

	MsgSort (dbP);
	
	ShlInsertText("New records added\n");
#endif
}


/**********************************************************************
 *	Function:		PrintMailRecord
 *
 *	Description:	Print the details of an appt record.  Includes
 *						deleted records, and the
 *						deleted, dirty, secret, & busy flags.
 *
 * Usage:			PrintMailRecord (dbP, index)
 *
 *	Revision History:
 *
 *		Name		Date		Description
 *		----		----		-----------
 *		kcr		10/23/95	display deleted records, sync-status flags
 *
 ***********************************************************************/
static void PrintMailRecord (DmOpenRef dbP, UInt16 index)
{
	char 					text[256];
	LocalID				chunk;
	UInt16				attr;
	UInt32				uniqueID;
	MemHandle			recordH;
	MsgDBRecordType	record;
	DateTimeType 		dateTime;



	DmRecordInfo (dbP, index, &attr, &uniqueID, &chunk);

	// Print record index.
	sprintf (text, "\nIndex:   %d", index);
	ShlInsertText (text);

	// Print the database unique id
	sprintf (text, ",  db unique id: %ld", uniqueID);
	ShlInsertText (text);
	
	if ((attr & dmRecAttrDelete) &&
		 chunk)
		ShlInsertText ("\tArchived");
	else if (attr & dmRecAttrDelete)
		ShlInsertText ("\tDeleted");
	if (attr & dmRecAttrDirty)
		ShlInsertText ("\tDirty");
	if (attr & dmRecAttrBusy)
		ShlInsertText ("\tBusy");
	if (attr & dmRecAttrSecret)
		ShlInsertText ("\tSecret");

	if (attr & dmRecAttrDelete)
		return;

	// Print the category
	sprintf (text, "\tCategory: %d", attr & dmRecAttrCategoryMask);
	ShlInsertText (text);


	if (MsgGetRecord(dbP, index, &record, &recordH) != 0)
		{
		ShlInsertText("Error!");
		return;
		}

	// Print the mail unique id
	sprintf (text, ",\nmail unique id: %d, %ld", record.id.hi, record.id.lo);
	ShlInsertText (text);

	// Print timestamp
	sprintf (text, ",\ntimestamp (raw):\n %u", record.timeStamp);
	ShlInsertText (text);
	
	TimSecondsToDateTime(record.timeStamp, &dateTime);
	sprintf(text, "\ntimestamp (formatted):    %d/%d/%d\n%d:%d:%d", dateTime.month,
		dateTime.day, dateTime.year,dateTime.hour, dateTime.minute, dateTime.second);
	ShlInsertText(text);

	// Print the flags
	ShlInsertText ("\nFlags:   ");

	if (record.flags.read)
		ShlInsertText ("\n\t\tRead  ");

//	if (record.flags.signature)
//		ShlInsertText ("\n\t\tSignature  ");

//	if (record.flags.confirmDelivery)
//		ShlInsertText ("\n\t\tConfirm Delivery  ");
		
	//new flags
	sprintf (text, "\n\t\tStatus: %d   ", record.flags.status);
	ShlInsertText (text);

	//moreTO
	if (record.flags.moreTO)
		ShlInsertText ("\n\t\tHas More TO field on Server");
	
	//moreCC
	if (record.flags.moreCC)
		ShlInsertText ("\n\t\tHas More CC field on Server");

	//moreBCC
	if (record.flags.moreBCC)
		ShlInsertText ("\n\t\tHas More BCC field on Server");
		
//	if (record.flags.sendSecure)
//		ShlInsertText ("\n\t\tSend Secure  ");

	if (record.flags.hasServerData)
		ShlInsertText ("\n\t\tHas Server Data  ");

	//totalMessageSize
	//DIA: Changed to %lu from %u, since totalMessageSize is now a UInt32.
	sprintf (text, "\nTotalMessageSize: %lu.%luk   ", record.totalMessageSize/10, record.totalMessageSize - ((record.totalMessageSize/10) * 10));
	ShlInsertText (text);

	//serverStartFrom
	sprintf (text, "\nServerStartFrom: %d", record.serverStartPos);
	ShlInsertText (text);

	ShlInsertText ("\nSubject: ");
	if (*record.subject)
		{
		ShlInsertText (record.subject);
		}
	
	ShlInsertText ("\nFrom:    ");
	if (*record.from)
		{
		ShlInsertText (record.from);
		}
	
	ShlInsertText ("\nTo:      ");
	if (*record.to)
		{
		ShlInsertText (record.to);
		}
	
	ShlInsertText ("\nCC:      ");
	if (*record.cc)
		{
		ShlInsertText (record.cc);
		}
	
	ShlInsertText ("\nBCC:      ");
	if (*record.bcc)
		{
		ShlInsertText (record.bcc);
		}
	
	ShlInsertText ("\nBody:    ");
	if (*record.body)
		{
		ShlInsertText (record.body);
		}

	ShlInsertText ("\nAttachment Names:    ");
	if (*record.attachmentNames)
		{
		ShlInsertText (record.attachmentNames);
		}

	ShlInsertText ("\nServerData:    ");
	if (*record.serverData)
		{
		ShlInsertText (record.serverData);
		}

	ShlInsertText ("\n");


	MemHandleUnlock (recordH);
}


/**********************************************************************
 * Get an record and print in Address format.
 *
 * DoMailGetRecord <access ptr> <index>
 ***********************************************************************/
static void DoMailGetRecord(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	char			text[256];
	UInt16 index = 0;
	int			i;
	
	
	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
		if (!index)
			sscanf(argv[i], "%d", &index);
		else
			usageErr = true;
		
		}

	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr> <index>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}

	PrintMailRecord (dbP, index);
}


/**********************************************************************
 * Get an record and print in Address format.
 *
 * DoMailGetRecord <access ptr> <index>
 *
 ***********************************************************************/
static void DoMailGetAll(int argc, Char * argv[])
{
	int					i;
	UInt16 					index = 0;
	char					text[256];
	Boolean				usageErr = false;
	DmOpenRef			dbP=0;
		
	if ( argc > 1 && !strcmp(argv[1], "?") )
		goto Help;

	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			usageErr = true;
		}

	if (usageErr) {
		goto SyntaxOnly;
		}

	if (!dbP)
		dbP = FindOpenedMailDatabases ();
		
	if (!dbP)
		{
		ShlInsertText("Could not find an open appointment database\n");
		return;
		}


	for (index = 0; index < DmNumRecords(dbP); index++)
		PrintMailRecord (dbP, index);
	ShlInsertText("\n");

	return;


Help:
	ShlInsertText("\nPrint all records in the appointment database\n");
	ShlInsertText("and their sync flags.\n");

SyntaxOnly:
	sprintf(text, "Syntax: %s [access ptr]\n", argv[0]);  
	ShlInsertText(text);
}





/**********************************************************************
 * Test changing an appointment record.
 *
 * DoMailChangeRecord <access ptr> <index>
 ***********************************************************************/
static void DoMailChangeRecord(int argc, Char * argv[])
{
	Int16							i;
	Char							text[256];
	UInt16 						result;
	UInt16 						index = 0;
	Boolean						usageErr = false;
	MemHandle					recordH;
	DmOpenRef					dbP = 0;
	MsgDBRecordType			testRecord;
	MsgChangedFieldsType		changedFields = { 0 };
	
	
	* (int *) &changedFields = 0;
	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
		if (!index)
			sscanf(argv[i], "%d", &index);
		else
			usageErr = true;
		
		}

	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr> <index>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}


	if (MsgGetRecord(dbP, index, &testRecord, &recordH) != 0)
		{
		ShlInsertText("Error!");
		return;
		}
	
#ifdef MG_READY
	testRecord.date.month = 12;
	changedFields.date = true;
#endif
	
	MemHandleUnlock (recordH);
	
	result = MsgChangeRecord (dbP, &index, &testRecord, changedFields, NULL);

	sprintf(text, "%d\n", result);
	ShlInsertText(text);
}


/**********************************************************************
 * Sort the Mail Database
 *
 * DoMailSync
 ***********************************************************************/
static void DoMailSync (int argc, Char * argv[])
{
	int					i;
	UInt16 					index = 0;
	char					text[256];
	Boolean				usageErr = false;
	DmOpenRef			dbP=0;
		
	if ( argc > 1 && !strcmp(argv[1], "?") )
		goto Help;


	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			usageErr = true;
		}

	if (usageErr) {
		goto SyntaxOnly;
		}

	if (!dbP)
		dbP = FindOpenedMailDatabases ();
		
	if (!dbP)
		{
		ShlInsertText("Could not find an open appointment database\n");
		return;
		}


	// Send a sync notification to the app.  This only works when the
	// app is running in Emulation mode.
	MsgSort (dbP);
	ShlInsertText ("\n");

	return;


Help:
	ShlInsertText("\nSend a sync notification to the app (really just sorts it).\n");

SyntaxOnly:
	sprintf(text, "Syntax: %s [access ptr]\n", argv[0]);  
	ShlInsertText(text);
}


/**********************************************************************
 * Add default date record to the database.
 *
 * DoMailDefaultData <access ptr>
 ***********************************************************************/ 
static void DoMailDefaultData(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	UInt16 		index;
	char			text[256];
	int			i;

#if LANGUAGE == LANGUAGE_FRENCH
	MsgDBRecordType	testRecord1 = {
		{TimGetTicks(),0},
		TimGetSeconds(),
		{0, 0, 0, 0, priorityNormal, sentTo, msgComplete, markNone, attachmentNone, 0, 0,0, 0, 0, 0 },
		11,
		"Bienvenue",
		"eurosupport@usr.com (U.S. Robotics)",
		"Utilisateur de Courrier de PalmPilot",
		"",
		"",
		"",
		"Utilisateur de Courrier de PalmPilot",
	"Bienvenue dans Courrier de PalmPilot!\n" 
			"\n"
	"Pour que vos messages de syst�me de messagerie de "
	"bureau apparaissent ici, vous devez configurer "
	"HotSync sur votre bureau comme suit.\n"
			"\n"
	"1. Installez PalmPilot Desktop � partir "
	"du CD ou des disquettes de "
	"distribution.\n"
			"\n"
	"2. Sous Windows 95/NT 4.0 PC, "
	"cliquez sur l'ic�ne de HotSync "
	"dans la barre des t�ches "
	"et s�lectionnez Personnaliser. Sous "
	"Windows 3.1x, cliquez deux fois "
	"sur l'ic�ne Personnaliser du groupe "
	"de programmes de PalmPilot 2.0.\n"
			"\n"
	"3. S�lectionnez la conduite Courrier "
	"et cliquez sur le bouton Changer.\n"
			"\n"
	"4. Cochez la case Activer Courrier "
	"de PalmPilot.\n"
			"\n"
	"5. S�lectionnez le syst�me de "
	"messagerie de bureau dans le "
	"menu d�roulant Synchroniser avec.\n"
			"\n"
	"6. Entrez le nom de l'utilisateur et le "
	"Mot de passe utilis� pour vous "
	"connecter au syst�me de messagerie "
	"de bureau.\n"
			"\n"
	"7. Cliquez sur le bouton d'aide pour "
	"conna�tre le param�trage "
	"sp�cifique � votre syst�me de "
	"messagerie exig� pour la "
	"configuration.\n"
			"\n"
	"8. Cliquez sur OK.\n"
			"\n"
	"9. Cliquez sur Termin�.\n"
			"\n"
	"A la prochaine synchronisation, les messages de votre bo�te de r�ception de bureau "
	"appa�tront ici. Lisez-les, r�pondez, transf�rez-les, supprimez-les ou cr�ez-en de nouveaux "
	"A la prochaine synchronisation, tous les r�sultats de ces actions appara�tront "
	"ici et sur le syst�me de messagerie de bureau.\n"
			"\n"
	"Profitez et appr�ciez Courrier de PalmPilot!\n",
		"",
		""
	};
#elif LANGUAGE == LANGUAGE_GERMAN
	MsgDBRecordType	testRecord1 = {
		{TimGetTicks(),0},
		TimGetSeconds(),
		{0, 0, 0, 0, priorityNormal, sentTo, msgComplete, markNone, attachmentNone, 0, 0,0, 0, 0, 0 },
		"Begr��ung",
		"germantechsup@usr.com (U.S. Robotics)",
		"PalmPilot Mail-Benutzer",
		"",
		"",
		"",
		"PalmPilot Mail-Benutzer",
	"Willkommen bei PalmPilot Mail!\n"
			"\n"
	"Damit Ihre Desktop E-Mails hier erscheinen k�nnen, m�ssen Sie die HotSync-Anwendung "
	"auf Ihrem Desktop wie folgt konfigurieren:\n"
			"\n"
	"Installieren Sie PalmPilot Desktop von der mitgelieferten CD bzw. von Disketten.\n"
			"\n"
	"Unter Windows 95/NT 4.0 PC klicken Sie im Systemfach (rechts unten) auf das "
	"HotSync-Symbol, und w�hlen Sie  \"Benutzerdefiniert\".\n"
			"\n"
	"Unter Windows 3.1x doppelklicken Sie auf das Symbol \"Benutzerdefiniert\" in der "
	"Programmgruppe \"PalmPilot 2.0.\"\n"
			"\n"
	"W�hlen Sie das Conduit \"Mail\", und klicken Sie auf \"�ndern\".\n"
			"\n"
	"Klicken Sie auf \"PalmPilot aktivieren\".\n"
			"\n"
	"W�hlen Sie unter \"Synchronisieren mit\" Ihr Desktop E-Mail-System aus.\n"
			"\n"
	"Geben Sie den Benutzernamen und das Kennwort ein, mit denen Sie sich gew�hnlich "
	"bei Ihrem Desktop E-Mail-System anmelden.\n"
			"\n"
	"Klicken Sie auf \"Hilfe\", um weitere Einstellungen anzuzeigen, die Sie eventuell "
	"auf Ihrem Desktop E-Mail-System konfigurieren m�ssen.\n"
			"\n"
	"Klicken Sie auf \"OK\".\n"
			"\n"
	"Klicken Sie auf \"Fertig\".\n"
			"\n"
	"Nach dem n�chsten HotSync-Vorgang werden Sie Ihre Nachrichten aus dem Desktop-Ordner "
	"\"Posteingang\" hier sehen.  Sie k�nnen nach Belieben E-Mails verfassen, lesen, "
	"beantworten und senden bzw. l�schen.  Wenn Sie das n�chste Mal einen HotSync "
	"ausf�hren, werden all diese Aktionen sowohl hier als auch auf Ihrem Desktop "
	"E-Mail-System angezeigt.\n"
			"\n"
	"Viel Spa� mit PalmPilot Mail!\n",
		"",
		""
	};
#elif LANGUAGE == LANGUAGE_WORKPAD
	MsgDBRecordType	testRecord1 = {
		{TimGetTicks(),0},
		TimGetSeconds(),
		{0, 0, 0, 0, priorityNormal, sentTo, msgComplete, markNone, attachmentNone, 0, 0,0, 0, 0, 0 },
		11,
		"Welcome",
		"WorkPad@us.ibm.com (IBM Corp.)",
		"WorkPad Mail User",
		"",
		"",
		"",
		"WorkPad Mail User",
	"Welcome to WorkPad Mail!\n" 
	"\n"
	"In order for your desktop e-mail messages to appear here, you must "
	"configure HotSync on your desktop as follows.\n"
	"\n"
	"1. Install WorkPad Desktop from \n"
	"     the CD provided.\n"
	"2. On your Windows 95/NT 4.0 PC, \n"
	"     click the HotSync system tray \n"
	"     icon and select Custom.\n"
	"3. Select the Mail conduit and\n"
	"     click the Change button. \n"
	"4. Click on the Activate \n"
	"     WorkPad Mail checkbox.\n"
	"5. Select the desktop e-mail \n"
	"     system you use in the\n"
	"     Synchronize with drop-down\n"
	"     menu.\n"
	"6. Enter the User Name and\n"
	"     Password you use to log into\n"
	"     your desktop e-mail system.\n"
	"7. Click the Help button to\n"
	"     learn about other settings\n"
	"     specific to your desktop\n"
	"     e-mail system that you may\n"
	"     need to configure.\n"
	"8. Click OK.\n"
	"9. Click Done.\n"
	"\n"
	"When you synchronize, the messages from your desktop inbox will "
	"appear right here.  Read, reply, forward, delete, or create new messages.  "
	"The next time you synchronize, all those actions will be reflected both "
	"here on your IBM WorkPad and on your desktop e-mail system.\n"
	"\n"
	"Enjoy WorkPad Mail!",
		"",
		""
	};
#else
	MsgDBRecordType	testRecord1 = {
		{TimGetTicks(),0},
		TimGetSeconds(),
		//read, addressing, status,, moreTo, moreCC, moreBCC, hasServerData,
		// deletedFromCat, addedToBody, reserved
		{0, sentTo, msgComplete, 0, 0, 0, 0, 0, 0, 0},
		0,
		0,
		11,
		0,
		"Welcome to iMessenger",
		"support@palm.net",
		"iMessenger User",
		"",
		"",
		"",
		"iMessenger User",
		"Welcome to the iMessenger(TM) application - wireless "
		"Internet Messaging for your Palm VII(TM) "
		"organizer.  Send and receive short text "
		"messages to anyone who has an Internet "
		"e-mail address.   You must first "
		"successfully complete activation before "
		"using iMessenger. \n"
		"\n"
		"To check for new messages, raise the "
		"antenna and tap the button Check & "
		"Send from within the iMessenger "
		"application. \n"
		"\n"
		"To create a new message, tap New, enter "
		"an Internet address, subject and body, "
		"and send now or later.  It's that easy! \n"
		"\n"
		"Enjoy iMessenger!",
		""
	};
#endif

	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			usageErr = true;
		
		}

	if (!dbP)
		dbP = FindOpenedMailDatabases ();
		
	if (!dbP)
		{
		ShlInsertText("Could not find an open mail database\n");
		return;
		}


	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}

	MsgNewRecord(dbP, &testRecord1, &index);


	ShlInsertText("New records added\n");
}


/**********************************************************************
 * Support for Mail commands
 *
 * returns 0 if successfully found command
 ***********************************************************************/
int ShlDoAppCmd(int argc, Char * argv[])
{
	int i;
	ShellCmdInfoType cmd [] ={ 	
		"MsgAppInfoInit", 			"msi",  	DoMailSetInfoDefaults,
		"MailNew",						"mnr",	DoMailNewRecords,
		"MsgGetRecord",				"mgr",	DoMailGetRecord,
		"MailGetAll",					"md",		DoMailGetAll,
		"MsgChangeRecord",			"mcr",	DoMailChangeRecord,
		"MailSync",						"ms",		DoMailSync,
		"MailDefaultData",			"mdd",	DoMailDefaultData,
		};
			
	for (i = 0; i < sizeof (cmd) / sizeof (ShellCmdInfoType); i++)
		{
		if ( (!ShlStrCmpi(argv[0], cmd[i].longName)) ||
			  (!ShlStrCmpi(argv[0], cmd[i].shortName)))
			{
			cmd[i].func (argc, argv);
			return 0;
			}
		}
	return 1;
}



#ifdef OLDWAY
/***********************************************************************
 *
 *	Copyright (c) Palm Computing 1996 -- All Rights Reserved
 *
 * PROJECT:  Pilot
 * FILE:     ShellCmdUser.c
 * AUTHOR:	 Roger Flores: Feb 26, 1996
 *
 * DESCRIPTION:
 *	  This file is where customized console shell comands are kept.
 * Currently this is a stub which the emulator calls when it doesn't
 * recognize a command.  The code here shows how to add a custom command.
 * The custom command is useless, but it does provide a template to add commands.
 * An application programmer can copy this file to their application 
 * folder and then customize it to handle as many commands as they wish.
 *
 **********************************************************************/

#include <Pilot.h>

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "ShellCmd.h"

typedef void ShellCmdFuncType (int argc, Char * argv[]);
typedef ShellCmdFuncType * ShellCmdFuncPtr;
typedef struct {
	Char *				longName;
	Char *				shortName;
	ShellCmdFuncPtr	func;
} ShellCmdInfoType;



/***********************************************************************
 *
 * FUNCTION:    DoAppCommand
 *
 * DESCRIPTION: Execute a user defined command for the appliation. 
 *					 (It currently adds one to a number as an example)
 *
 *					 Syntax: UserCommand num
 *
 * PARAMETERS:  argc - number of arguments
 *              argv - argument list
 *
 * RETURNED:    false if the command was a ui command.
 *
 ***********************************************************************/
static void DoAppCommand (int argc, Char * argv[])
{
	int i;
	char text[256];
	Int16 num = 0;
	Boolean usageErr = false;

	// Parse the arguments passed.
	if ( argc > 1 && !strcmp(argv[1], "?") )
		goto Help;

	if (argc < 2) usageErr = true;
	for (i=1; i<argc; i++)
		{
		if (isxdigit(argv[i][0]))
			sscanf(argv[i], "%d", &num);
		else
			usageErr = true;
		}

	if (usageErr) {
		goto SyntaxOnly;
		}

	// Perform the command here
	sprintf(text, "\n%d + 1 = %d\n", num, num + 1);
	ShlInsertText(text);

	return;


	// Dislay help and or syntax.
Help:
	ShlInsertText("\nExecute a user defined command. (adds one to a number)\n"
		"You can customize this in the ShellCmdApp.cpp file\n");
SyntaxOnly:
	sprintf(text, "\nSyntax: %s [number]\n", argv[0]);
	ShlInsertText(text);
	return;
}


/***********************************************************************
 *
 * FUNCTION:    ShlDoAppCmd
 *
 * DESCRIPTION: This routine check if a command is a user defined shell 
 *					 command for the application.  If so is the command is executed.
 *
 * PARAMETERS:  argc - number of arguments
 *              argv - argument list
 *
 * RETURNED:    false if the command was handled.
 *
 ***********************************************************************/
int ShlDoAppCmd (int argc, Char * argv[])
{
	int i;
	ShellCmdInfoType cmd [] ={ 
		// Each command should have a customized line below	
		"UserComand", 		"uc",  	DoAppCommand,
		};
			
	for (i = 0; i < sizeof (cmd) / sizeof (ShellCmdInfoType); i++)
		{
		if ( (!ShlStrCmpi(argv[0], cmd[i].longName)) ||
			  (!ShlStrCmpi(argv[0], cmd[i].shortName)))
			{
			cmd[i].func (argc, argv);
			return 0;
			}
		}
	return 1;

}

#endif
