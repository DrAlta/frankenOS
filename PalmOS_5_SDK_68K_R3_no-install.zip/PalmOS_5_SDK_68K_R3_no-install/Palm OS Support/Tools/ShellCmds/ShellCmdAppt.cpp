/******************************************************************************
 *
 * Copyright (c) 1999-2002 PalmSource, Inc. All rights reserved.
 *
 * File: ShellCmdAppt.cpp
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 * Description:
 * This file contains test code for Pilot that is used in both
 *  DOS and Windows apps
 *
 *****************************************************************************/

// Pilot Includes 
#include <Pilot.h>

// C library Includes
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <IMCUtils.h>

// DB includes
#include "Datebook.h"
#include "DateTime.h"

#include "ShellCmd.h"

// Testing
#ifdef __cplusplus
extern "C" {
#endif

extern void PrintApptRecord (DmOpenRef dbP, UInt16 index);

#ifdef __cplusplus
}
#endif



#define apptDBType				'DATA'
#define alarmPrefRscID			1

typedef void ShellCmdFuncType (int argc, Char * argv[]);
typedef ShellCmdFuncType * ShellCmdFuncPtr;
typedef struct {
	Char *				longName;
	Char *				shortName;
	ShellCmdFuncPtr	func;
} ShellCmdInfoType;

#pragma pcrelstrings off

/**********************************************************************
 * find an open appointment database
 *
 * Parameters: none
 ***********************************************************************/
static DmOpenRef FindOpenedApptDatabase (void)
{
	DmOpenRef	dbP=0;
	LocalID		dbID;
	UInt16			mode;
	UInt16			cardNo;
	UInt32			dbType;
	UInt32			dbCreator;
	
	do {
		dbP = DmNextOpenDatabase(dbP);
		if (!dbP) break;

		Err err = DmOpenDatabaseInfo(dbP, &dbID, NULL, &mode, &cardNo, NULL);
		if (err) 
			{
			ShlInsertText("\n#ERROR getting info");
			}
		else
			{
			DmDatabaseInfo(cardNo, dbID, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				&dbType, &dbCreator);

			if ((dbType == apptDBType) && (dbCreator == sysFileCDatebook) )
				return (dbP);
			}
		} while (1);


	return(0);
}


/**********************************************************************
 * Set the appointment application chunk to the defaults.
 *
 * ApptSetInfoDefaults <access ptr>
 ***********************************************************************/
static void DoApptSetInfoDefaults(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	char		text[256];
	int		i;

	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			usageErr = true;
		
		}

	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr>\n", argv[0]);
		ShlInsertText(text);
		return;
		}

	Err err = ApptAppInfoInit(dbP);
	if (err) {
		ShlInsertText("\n##ERROR Setting defaults\n");
		}
	else {
		ShlInsertText("Success!\n");
		}
}



/**********************************************************************
 * Test the newRecord function.
 *
 * DoApptTestNewRecord <access ptr>
 ***********************************************************************/ 
static void DoApptTestNewRecord(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	UInt16 			index;
	char			text[256];
	int			i;

	// 12:00pm - 1:00pm on 7/31/95
	// repeating every other monthly until 12/31/96
	ApptDateTimeType	dt1 = {12, 00, 13, 00, 91, 7, 31};
	RepeatInfoType		ri1 = {repeatMonthlyByDate, 92, 12, 31, 2, 0};
	ApptDBRecordType	testRecord1 = {
		&dt1,
		NULL,
		&ri1,
		NULL,
		"Last day of every other month",
		NULL
	};
	
	// 10:00am - 12:00pm on 7/21/95
	// repeating on the third fridy of every other monthly until 12/31/96
	ApptDateTimeType	dt2 = {10, 00, 12, 00, 91, 7, 21};
	RepeatInfoType		ri2 = {repeatMonthlyByDay, 92, 12, 31, 2, dom3rdFri};
	AlarmInfoType 		ai2 = {5, aauMinutes};
	ApptDBRecordType	testRecord2 = {
		&dt2,
		&ai2,
		&ri2,
		NULL,
		"Third fridy of every other month",
		NULL
	};
	
	// 10:00am - 12:00pm on 6/30/95
	// repeating on the last fridy of every monthly until 12/31/98
	ApptDateTimeType	dt3 = {10, 00, 12, 00, 91, 6, 30};
	RepeatInfoType		ri3 = {repeatMonthlyByDay, 94, 12, 31, 1, domLastFri};
	DateType 			ex3[4] = {0, 0, 0, 91, 9, 29, 91, 11, 24, 92, 12, 27};
	ApptDBRecordType	testRecord3 = {
		&dt3,
		NULL,
		&ri3,
		(ExceptionsListType *) ((UInt16 *) &ex3),
		"Last fridy of every month",
		NULL
	};


	// no-timed stating on 3/14/56
	// repeating every other monthly until 12/31/2031
	ApptDateTimeType	dt4 = {-1, -1, -1, -1, 52, 3, 14};
	RepeatInfoType		ri4 = {repeatYearly, 127, 12, 31, 1, 0};
	ApptDBRecordType	testRecord4 = {
		&dt4,
		NULL,
		&ri4,
		NULL,
		"Happy Birthday Art !!!",
		NULL
	};


	// no-timed stating on 6/19/95
	// repeating weekly until 8/4/95, every other Sunday an Thursday.
	ApptDateTimeType	dt5 = {-1, -1, -1, -1, 91, 6, 19};
	RepeatInfoType		ri5 = {repeatWeekly, 91, 8, 4, 2, 0x11};
	ApptDBRecordType	testRecord5 = {
		&dt5,
		NULL,
		&ri5,
		NULL,
		"Every other Sunday an Thursday",
		NULL
	};

	// no-timed stating on 2/29/92
	// repeating yearly until 12/31/2031
	ApptDateTimeType	dt6 = {-1, -1, -1, -1, 88, 2, 29};
	RepeatInfoType		ri6 = {repeatYearly, 127, 12, 31, 1, 0};
	ApptDBRecordType	testRecord6 = {
		&dt6,
		NULL,
		&ri6,
		NULL,
		"Leap day",
		NULL
	};


	// no-timed stating on 6/19/95
	// repeating every third day until 12/31/95.
	ApptDateTimeType	dt7 = {-1, -1, -1, -1, 91, 6, 19};
	RepeatInfoType		ri7 = {repeatDaily, 91, 12, 31, 3, 0};
	ApptDBRecordType	testRecord7 = {
		&dt7,
		NULL,
		&ri7,
		NULL,
		"Every third day",
		NULL
	};


	// 2:00pm - 3:00pm on 7/31/95
	ApptDateTimeType	dt8 = {14, 00, 15, 00, 91, 7, 31};
	ApptDBRecordType	testRecord8 = {
		&dt8,
		NULL,
		NULL,
		NULL,
		"Engineering meeting",
		NULL
	};

	// 7:30am - 8:45 on 7/31/95
	ApptDateTimeType	dt9 = {7, 30, 8, 45, 91, 7, 31};
	ApptDBRecordType	testRecord9 = {
		&dt9,
		NULL,
		NULL,
		NULL,
		"Bike ride",
		NULL
	};

	// 12:30am - 1:30 on 7/31/95
	ApptDateTimeType	dt10 = {12, 30, 13, 30, 91, 7, 31};
	ApptDBRecordType	testRecord10 = {
		&dt10,
		NULL,
		NULL,
		NULL,
		"Lunch",
		NULL
	};


	// 10:00am - 12:00pm on 8/19/95
	// repeating on the third saturday of every monthly until 8/7/97
	ApptDateTimeType	dt11 = {10, 00, 12, 00, 91, 9, 30};
	RepeatInfoType		ri11 = {repeatMonthlyByDay, 93, 8, 7, 3, domLastSat};
	ApptDBRecordType	testRecord11 = {
		&dt11,
		NULL,
		&ri11,
		NULL,
		"Third saturday of every month",
		NULL
	};
	

	// 7:00am - 8:00am on 7/30/95
	ApptDateTimeType	dt12 = {7, 00, 8, 00, 91, 7, 30};
	ApptDBRecordType	testRecord12 = {
		&dt12,
		NULL,
		NULL,
		NULL,
		"Brunch of champions",
		NULL
	};
	

	// 4:00pm - 8:00pm on 7/31/95
	ApptDateTimeType	dt13 = {16, 00, 20, 00, 91, 7, 31};
	ApptDBRecordType	testRecord13 = {
		&dt13,
		NULL,
		NULL,
		NULL,
		"drinks, dinner, & more drinks with Kennedy",
		NULL
	};
	

	// 10:00am - 11:30am on 8/1/95
	ApptDateTimeType	dt14 = {10, 00, 11, 30, 91, 8, 1};
	ApptDBRecordType	testRecord14 = {
		&dt14,
		NULL,
		NULL,
		NULL,
		"Falcon review meeting",
		NULL
	};
	

	// 2:00pm - 3:45pm on 8/1/95
	ApptDateTimeType	dt15 = {14, 00, 15, 45, 91, 8, 1};
	ApptDBRecordType	testRecord15 = {
		&dt15,
		NULL,
		NULL,
		NULL,
		"Week View Review Meeting",
		NULL
	};
	

	// 1:15pm - 3:45pm on 8/2/95
	ApptDateTimeType	dt16 = {13, 45, 15, 45, 91, 8, 2};
	ApptDBRecordType	testRecord16 = {
		&dt16,
		NULL,
		NULL,
		NULL,
		"Engineering goes to lunch",
		NULL
	};
	

	// 10:30am - 12:30pm on 8/3/95
	ApptDateTimeType	dt17 = {10, 30, 12, 30, 91, 8, 3};
	ApptDBRecordType	testRecord17 = {
		&dt17,
		NULL,
		NULL,
		NULL,
		"The meeting that wouldn't end",
		NULL
	};
	

	// 11:30am - 2:00pm on 8/3/95
	ApptDateTimeType	dt18 = {11, 30, 14, 00, 91, 8, 3};
	ApptDBRecordType	testRecord18 = {
		&dt18,
		NULL,
		NULL,
		NULL,
		"Play golf",
		NULL
	};
	
	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			usageErr = true;
		
		}

	if (!dbP)
		dbP = FindOpenedApptDatabase ();
		
	if (!dbP)
		{
		ShlInsertText("Could not find an open appointment database\n");
		return;
		}


	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}

	// Fixup expection list for the third record.
	*((UInt16 *) &ex3) = 3;

	ApptNewRecord(dbP, &testRecord1, &index);
	ApptNewRecord(dbP, &testRecord2, &index);
	ApptNewRecord(dbP, &testRecord3, &index);
	ApptNewRecord(dbP, &testRecord4, &index);
	ApptNewRecord(dbP, &testRecord5, &index);
	ApptNewRecord(dbP, &testRecord6, &index);
	ApptNewRecord(dbP, &testRecord7, &index);
	ApptNewRecord(dbP, &testRecord8, &index);
	ApptNewRecord(dbP, &testRecord9, &index);
	ApptNewRecord(dbP, &testRecord10, &index);
	ApptNewRecord(dbP, &testRecord11, &index);
	ApptNewRecord(dbP, &testRecord12, &index);
	ApptNewRecord(dbP, &testRecord13, &index);
	ApptNewRecord(dbP, &testRecord14, &index);
	ApptNewRecord(dbP, &testRecord15, &index);
	ApptNewRecord(dbP, &testRecord16, &index);
	ApptNewRecord(dbP, &testRecord17, &index);
	ApptNewRecord(dbP, &testRecord18, &index);


	ShlInsertText("New records added\n");
}


/**********************************************************************
 *	Function:		PrintApptRecord
 *
 *	Description:	Print the details of an appt record.  Includes
 *						deleted records, and the
 *						deleted, dirty, secret, & busy flags.
 *
 * Usage:			PrintApptRecord (dbP, index)
 *
 *	Revision History:
 *
 *		Name		Date		Description
 *		----		----		-----------
 *		kcr		10/23/95	display deleted records, sync-status flags
 *
 ***********************************************************************/
void PrintApptRecord (DmOpenRef dbP, UInt16 index)
{
	char 					text[256];
	LocalID				chunk;
	UInt16					attr;
	UInt32					uniqueID;
	VoidHand				recordH;
	ApptDBRecordType	record;



	DmRecordInfo (dbP, index, &attr, &uniqueID, &chunk);

	// Print record index.
	sprintf(text, "\nIndex:  %d", index);
	ShlInsertText(text);

	// Print the unique id
	sprintf(text, ",  unique id: %ld", uniqueID);
	ShlInsertText(text);
	
	if ((attr & dmRecAttrDelete) &&
		 chunk)
		ShlInsertText ("\tArchived");
	else if (attr & dmRecAttrDelete)
		ShlInsertText ("\tDeleted");
	if (attr & dmRecAttrDirty)
		ShlInsertText ("\tDirty");
	if (attr & dmRecAttrBusy)
		ShlInsertText ("\tBusy");
	if (attr & dmRecAttrSecret)
		ShlInsertText ("\tSecret");

	if (attr & dmRecAttrDelete)
		return;

	if (ApptGetRecord(dbP, index, &record, &recordH) != 0)
		{
		ShlInsertText("Error!");
		return;
		}

	// Print date
	sprintf(text, "\nDate:   %d/%d/%d", record.when->date.month,
		record.when->date.day, record.when->date.year+4);
	ShlInsertText(text);
	
	// Print time.
	if ((*(int *) &record.when->startTime) == -1)
		ShlInsertText("  Time: none\n");
	else
		{
		sprintf(text, "  Time: %02d:%02d to %02d:%02d\n", 
			record.when->startTime.hours, record.when->startTime.minutes, 
			record.when->endTime.hours, record.when->endTime.minutes);
		ShlInsertText(text);
		}
	
	// Print alarm info.
	if (record.alarm != NULL) {
		sprintf(text, "Alarm:  %d ", record.alarm->advance);
		switch (record.alarm->advanceUnit) {
			case aauMinutes:
				strcat(text, "minutes\n");
				break;
			case aauHours:
				strcat(text, "hours\n");
				break;
			case aauDays:
				strcat(text, "days\n");
				break;
		}
		ShlInsertText(text);
	}
		
	// Print repeat info.
	if (record.repeat != NULL) {
		sprintf(text, "Repeat: ", record.alarm->advance);
		switch (record.repeat->repeatType) {
			case repeatDaily:
				strcat(text, "daily");
				break;
			case repeatWeekly:
				strcat(text, "weekly");
				break;
			case repeatMonthlyByDay:
				strcat(text, "monthly by day");
				break;
			case repeatMonthlyByDate:
				strcat(text, "monthly by date");
				break;
			case repeatYearly:
				strcat(text, "yearly");
				break;
		}
		ShlInsertText(text);
		
		sprintf(text, ", Freq: %d", record.repeat->repeatFrequency);
		ShlInsertText(text);

		switch (record.repeat->repeatType) {
			case repeatWeekly:
				sprintf(text, ", On:");
				if (record.repeat->repeatOn & (1 << sunday))
					strcat(text, " sun");
				if (record.repeat->repeatOn & (1 << monday))
					strcat(text, " mon");
				if (record.repeat->repeatOn & (1 << tuesday))
					strcat(text, " tue");
				if (record.repeat->repeatOn & (1 << wednesday))
					strcat(text, " wen");
				if (record.repeat->repeatOn & (1 << thursday))
					strcat(text, " thu");
				if (record.repeat->repeatOn & (1 << friday))
					strcat(text, " fri");
				if (record.repeat->repeatOn & (1 << saturday))
					strcat(text, " sat");
				ShlInsertText(text);
				break;
			case repeatMonthlyByDay:
				sprintf(text, ", On: ");
				switch (record.repeat->repeatOn / daysInWeek)
					{
					case 0: strcat(text, "first ");		break;
					case 1: strcat(text, "second ");		break;
					case 2: strcat(text, "third ");		break;
					case 3: strcat(text, "forth ");		break;
					case 4: strcat(text, "last ");		break;
					}
				switch (record.repeat->repeatOn % daysInWeek)
					{
					case 0: strcat(text, "sunday");		break;
					case 1: strcat(text, "monday");		break;
					case 2: strcat(text, "tuesday");		break;
					case 3: strcat(text, "wednesday");	break;
					case 4: strcat(text, "thursdy");		break;
					case 5: strcat(text, "friday ");		break;
					case 6: strcat(text, "saturday");	break;
					}
				ShlInsertText(text);
				break;
		}

	ShlInsertText(", End date: ");
	if ((*(int *) &record.repeat->repeatEndDate) == -1)
		ShlInsertText("none\n");
	else
		{
		sprintf(text, "%0d/%0d/%0d\n", 
			record.repeat->repeatEndDate.month, 
			record.repeat->repeatEndDate.day,
			record.repeat->repeatEndDate.year+firstYear);
		ShlInsertText(text);
		}
	}
		

	// Print exceptions.
	if (record.exceptions != NULL) {
		sprintf(text, "Except: %d\n", record.exceptions->numExceptions);
		ShlInsertText(text);

		int i;
		for (i = 0; i < record.exceptions->numExceptions; i++) {
			sprintf(text, "        %d. %0d/%0d/%0d\n", i,
				(&record.exceptions->exception + i)->month,
				(&record.exceptions->exception + i)->day,
				(&record.exceptions->exception + i)->year+4);
			ShlInsertText(text);
		};
	}
		
	ShlInsertText("Desc:   ");
	ShlInsertText(record.description);
	ShlInsertText("\n");
	
	if (record.note != NULL) {
		ShlInsertText("Note:  ");
		ShlInsertText(record.note);
		ShlInsertText("\n");
	}

	MemHandleUnlock (recordH);
}


/**********************************************************************
 * Get an record and print in Address format.
 *
 * DoApptGetRecord <access ptr> <index>
 ***********************************************************************/
static void DoApptGetRecord(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	char			text[256];
	UInt16 index = 0;
	int			i;
	
	
	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
		if (!index)
			sscanf(argv[i], "%d", &index);
		else
			usageErr = true;
		
		}

	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr> <index>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}

	PrintApptRecord (dbP, index);
}


/**********************************************************************
 * Get an record and print in Address format.
 *
 * DoApptGetRecord <access ptr> <index>
 *
 *		kcr		10/23/95		added sync-status flags to display
 ***********************************************************************/
static void DoApptGetAll(int argc, Char * argv[])
{
	int					i;
	UInt16 					index = 0;
	char					text[256];
	Boolean				usageErr = false;
	DmOpenRef			dbP=0;
		
	if (argc > 1 && !strcmp(argv[1], "?") )
		goto Help;

	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			usageErr = true;
		}

	if (usageErr) {
		goto SyntaxOnly;
		}

	if (!dbP)
		dbP = FindOpenedApptDatabase ();
		
	if (!dbP)
		{
		ShlInsertText("Could not find an open appointment database\n");
		return;
		}


	for (index = 0; index < DmNumRecords(dbP); index++)
		PrintApptRecord (dbP, index);
	ShlInsertText("\n");

	return;


Help:
	ShlInsertText("\nPrint all records in the appointment database\n");
	ShlInsertText("and their sync flags.\n");

SyntaxOnly:
	sprintf(text, "Syntax: %s [access ptr]\n", argv[0]);  
	ShlInsertText(text);
}





/**********************************************************************
 * Test changing an appointment record.
 *
 * DoApptChangeRecord <access ptr> <index>
 ***********************************************************************/
static void DoApptChangeRecord(int argc, Char * argv[])
{
	Int16			i;
	Char			text[256];
	UInt16 			result;
	UInt16 			index = 0;
	Boolean		usageErr = false;
	VoidHand		recordH;
	DmOpenRef	dbP=0;
	ApptDBRecordType testRecord;
	ApptDBRecordFlags changedFields;
	AlarmInfoType ai2 = {1, aauDays};
	
	
	* (int *) &changedFields = 0;
	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
		if (!index)
			sscanf(argv[i], "%d", &index);
		else
			usageErr = true;
		
		}

	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr> <index>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}


	if (ApptGetRecord(dbP, index, &testRecord, &recordH) != 0)
		{
		ShlInsertText("Error!");
		return;
		}
	
	testRecord.when->startTime.hours += 1;
	testRecord.when->endTime.hours += 1;
	changedFields.when = 1;
	testRecord.alarm = &ai2;
	changedFields.alarm = 1;
	
	MemHandleUnlock (recordH);
	
	result = ApptChangeRecord(dbP, &index, &testRecord, changedFields);

	sprintf(text, "%d\n", result);
	ShlInsertText(text);
}


/**********************************************************************
 * Send a sync notification to the app
 *
 * DoApptSync
 ***********************************************************************/
static void DoApptSync(int argc, Char * argv[])
{
	int					i;
	UInt16 					index = 0;
	char					text[256];
	Boolean				usageErr = false;
	DmOpenRef			dbP=0;
		
	if (argc > 1 && !strcmp(argv[1], "?") )
		goto Help;


	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			usageErr = true;
		}

	if (usageErr) {
		goto SyntaxOnly;
		}

	if (!dbP)
		dbP = FindOpenedApptDatabase ();
		
	if (!dbP)
		{
		ShlInsertText("Could not find an open appointment database\n");
		return;
		}


	// Send a sync notification to the app.  This only works when the
	// app is running in Emulation mode.
	ApptSort(dbP);
	ShlInsertText("\n");

	return;


Help:
	ShlInsertText("\nSend a sync notification to the app (really just sorts it).\n");

SyntaxOnly:
	sprintf(text, "Syntax: %s [access ptr]\n", argv[0]);  
	ShlInsertText(text);
}



/**********************************************************************
 * Print occurrences of a repeating appointment
 *
 * DoApptRepeat <index> <days to check>
 ***********************************************************************/
static void DoApptRepeat(int argc, Char * argv[])
{
	int					i;
	UInt16 					index = -1;
	UInt16					daysToTest=0;
	char					text[256];
	Boolean				usageErr = false;
	DateType				date;
	VoidHand 			recordH;
	DmOpenRef			dbP=0;
	ApptDBRecordType 	apptRec;
	DateTimeType		dateTime;
	DateTimeType		endDateTime;
		
	if (argc > 1 && !strcmp(argv[1], "?") )
		goto Help;

	for (i=1; i<argc; i++) {
		if (index == -1)
			sscanf(argv[i], "%d", &index);
		else if (!daysToTest)
			sscanf(argv[i], "%d", &daysToTest);
		else
			usageErr = true;
		}

	if (usageErr || (index == -1) || (daysToTest == 0)) {
		goto SyntaxOnly;
		}

	dbP = FindOpenedApptDatabase ();
	if (!dbP)
		{
		ShlInsertText("Could not find an open appointment database\n");
		return;
		}


	// Get the record
	recordH = DmQueryRecord(dbP, index);
	if (! recordH)
		{
		ShlInsertText("Record not found\n");
		return;		
		}
	
	// Check if is a repeating appointment
	ApptGetRecord (dbP, index, &apptRec, &recordH);
	if (! apptRec.repeat)
		{
		ShlInsertText("Record is not a repeating appointment\n");
		goto Exit;		
		}
			
	PrintApptRecord (dbP, index);
	
	// Start checking from today.
	TimSecondsToDateTime (TimGetSeconds (), &dateTime);
	endDateTime = dateTime;
	TimAdjust (&endDateTime, daysInSeconds*(daysToTest-1));	
	
	sprintf(text, "Appointments between %d/%d/%d - %d/%d/%d\n", 
		dateTime.month, dateTime.day, dateTime.year, 
		endDateTime.month, endDateTime.day, endDateTime.year);
	ShlInsertText(text);
		
	for (i = 0; i < daysToTest; i++)
		{
		date.year = dateTime.year - firstYear;
		date.month = dateTime.month;
		date.day = dateTime.day;
		if (ApptRepeatsOnDate (&apptRec, date))
			{
			sprintf(text, "%2d/%2d/%2d\n", date.month, date.day, date.year+firstYear);
			ShlInsertText(text);
			}
		TimAdjust (&dateTime, daysInSeconds);
		}

Exit:
	MemHandleUnlock (recordH);
	return;


Help:
	ShlInsertText("\nPrint occurrences of a repeating appointment\n");

SyntaxOnly:
	sprintf(text, "Syntax: %s <index> <days>\n", argv[0]);  
	ShlInsertText(text);
}


/**********************************************************************
 * For a range of date print the next occurrences of a repeating appointment
 * for each date in the range.
 *
 * DoApptNextRepeat <index> <days to check>
 ***********************************************************************/
static void DoApptNextRepeat(int argc, Char * argv[])
{
	int					i;
	UInt16 					index = -1;
	UInt16					daysToTest=0;
	char					text[256];
	Boolean				usageErr = false;
	DateType				date;
	DateType				next;
	VoidHand 			recordH;
	DmOpenRef			dbP=0;
	ApptDBRecordType 	apptRec;
	DateTimeType		dateTime;
	DateTimeType		endDateTime;
		
	if (argc > 1 && !strcmp(argv[1], "?") )
		goto Help;

	for (i=1; i<argc; i++) {
		if (index == -1)
			sscanf(argv[i], "%d", &index);
		else if (!daysToTest)
			sscanf(argv[i], "%d", &daysToTest);
		else
			usageErr = true;
		}

	if (usageErr || (index == -1) || (daysToTest == 0)) {
		goto SyntaxOnly;
		}

	dbP = FindOpenedApptDatabase ();
	if (!dbP)
		{
		ShlInsertText("Could not find an open appointment database\n");
		return;
		}


	// Get the record
	recordH = DmQueryRecord(dbP, index);
	if (! recordH)
		{
		ShlInsertText("Record not found\n");
		return;		
		}
	
	// Check if is a repeating appointment
	ApptGetRecord (dbP, index, &apptRec, &recordH);
	if (! apptRec.repeat)
		{
		ShlInsertText("Record is not a repeating appointment\n");
		goto Exit;		
		}
			
	PrintApptRecord (dbP, index);
	
	// Start checking from today.
	TimSecondsToDateTime (TimGetSeconds (), &dateTime);
	endDateTime = dateTime;
	TimAdjust (&endDateTime, daysInSeconds*(daysToTest-1));	
	
	sprintf(text, "Appointments between %d/%d/%d - %d/%d/%d\n", 
		dateTime.month, dateTime.day, dateTime.year, 
		endDateTime.month, endDateTime.day, endDateTime.year);
	ShlInsertText(text);
		
	for (i = 0; i < daysToTest; i++)
		{
		date.year = dateTime.year - firstYear;
		date.month = dateTime.month;
		date.day = dateTime.day;
		next = date;
		
		if (! ApptNextRepeat (&apptRec, &next)) break;
		
		sprintf(text, "%2d/%2d/%2d  -  ", date.month, date.day, date.year+firstYear);
		ShlInsertText(text);
		sprintf(text, "%2d/%2d/%2d\n", next.month, next.day, next.year+firstYear);
		ShlInsertText(text);
	
		TimAdjust (&dateTime, daysInSeconds);
		}

Exit:
	MemHandleUnlock (recordH);
	return;


Help:
	ShlInsertText("\nFor a range of dates, print the next occurrences of a\n"
		"repeating appointment\n");

SyntaxOnly:
	sprintf(text, "Syntax: %s <index> <days>\n", argv[0]);  
	ShlInsertText(text);
}


/**********************************************************************
 * Get an record and print in Address format.
 *
 * DoApptOnDate <access ptr> <year> <month> <day> <daysToTest>
 ***********************************************************************/
static void DoApptOnDate(int argc, Char * argv[])
{
	int					i, j;
	UInt16					day=0;
	UInt16					month=0;
	UInt16					year=0;
	char					text[256];
	Boolean				usageErr = false;
	VoidHand 			recordH;
	VoidHand				apptsH;
	UInt16					numAppts;
	DmOpenRef			dbP=0;
	UInt16					daysToTest=0;
	DateType				date;
	ApptInfoPtr 		appts;
		
	if (argc > 1 && !strcmp(argv[1], "?") )
		goto Help;

	for (i=1; i<argc; i++) {
		if (!year)
			sscanf(argv[i], "%d", &year);
		else if (!month)
			sscanf(argv[i], "%d", &month);
		else if (!day)
			sscanf(argv[i], "%d", &day);
		else if (!daysToTest)
			sscanf(argv[i], "%d", &daysToTest);
		else
			usageErr = true;
		}

	if (usageErr || (!year) || (!month) || (!day))
		goto SyntaxOnly;
		

	dbP = FindOpenedApptDatabase ();
	if (!dbP)
		{
		ShlInsertText("Could not find an open appointment database\n");
		return;
		}

	if (daysToTest == 0) daysToTest = 1;

	// Get the appointment list.
	if (year < 100) year += 1900;
	date.year = year - firstYear;
	date.month = month;
	date.day = day;
	for (j = 0; j < daysToTest; j++)
		{
		ApptGetAppointments (dbP, date, 1, &apptsH, &numAppts);
	
		if (! apptsH)
			{
			if (daysToTest == 1)
				{
				sprintf(text, "No appointments for %d/%d/%d\n", 
					date.month, date.day, date.year+firstYear);
				ShlInsertText(text);
				}
			}
		else
			{
			appts = (ApptInfoPtr) MemHandleLock (apptsH);
			sprintf(text, "\nAppointments for %d/%d/%d\n", 
				date.month, date.day, date.year+firstYear);
			ShlInsertText(text);
			for (i = 0; i < numAppts; i++)
				{
				// Get the record
				recordH = DmQueryRecord(dbP, appts[i].recordNum);
				if (! recordH)
					{
					ShlInsertText("Record not found\n");
					break;		
					}
		
				PrintApptRecord (dbP, appts[i].recordNum);
				}
			MemHandleUnlock (apptsH);
			}
		DateAdjust (&date, 1);
		}
	
	return;


Help:
	ShlInsertText("\nPrint appointment on a given day\n");

SyntaxOnly:
	sprintf(text, "Syntax: %s <year> <month> <day> <daysToTest>\n", argv[0]);  
	ShlInsertText(text);
}


/**********************************************************************
 * Display a list of record with alarm.
 *
 * DoApptAlarmTimes 
 ***********************************************************************/
static void DoApptAlarmTimes(int argc, Char * argv[])
{
	int					i;
	UInt16 					index;
	char					text[256];
	Boolean				usageErr = false;
	VoidHand				recordH;
	DmOpenRef			dbP=0;
	UInt32					alarmTime;
	UInt32					currentTime;
	DateTimeType		dateTime;
	ApptDBRecordType 	apptRec;
		
	if (argc > 1 && !strcmp(argv[1], "?") )
		goto Help;

	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			usageErr = true;
		}

	if (usageErr) {
		goto SyntaxOnly;
		}

	if (!dbP)
		dbP = FindOpenedApptDatabase ();
		
	if (!dbP)
		{
		ShlInsertText("Could not find an open appointment database\n");
		return;
		}

	currentTime = TimGetSeconds ();

	for (index = 0; index < DmNumRecords(dbP); index++)
		{
		// Get the record
		if (DmQueryRecord(dbP, index))
			{
			// Check if the record has an alarm.
			ApptGetRecord (dbP, index, &apptRec, &recordH);
			if (apptRec.alarm)
				{
				PrintApptRecord (dbP, index);
				alarmTime = ApptGetAlarmTime (&apptRec, currentTime);
				TimSecondsToDateTime (alarmTime, &dateTime);
				ShlInsertText("Notify: ");
				if (alarmTime)
					{
					sprintf(text, "%d/%d/%d", dateTime.month, dateTime.day,
						dateTime.year);
					ShlInsertText(text);
					sprintf(text, "  %02d:%02d\n", dateTime.hour, dateTime.minute);
					ShlInsertText(text);
					}
				else
					{
					ShlInsertText("none\n");
					}
				}
			MemHandleUnlock (recordH);
			}
		}
			
	ShlInsertText("\n");
	return;
			
	
	Help:
	ShlInsertText("\nPrint records with alarms\n");
	
	SyntaxOnly:
	sprintf(text, "Syntax: %s [access ptr]\n", argv[0]);  
	ShlInsertText(text);
	}


/**********************************************************************
 * Display a list of record with alarms scheduled at the specified time.
 *
 * DoApptAlarmTimes year month day hour minute
 ***********************************************************************/
static void DoApptAlarmList(int argc, Char * argv[])
{
	int					i;
	UInt16 					index;
	UInt16					alarmCount;
	char					text[256];
	DmOpenRef			dbP;
	UInt32					alarmTime;
	DateTimeType		dateTime;
	VoidHand 			alarmListH;
	UInt16 *				alarmList;
	Boolean				quite;
		
	if (argc > 1 && !strcmp(argv[1], "?") )
		goto Help;
	else if (argc != 6)
		goto SyntaxOnly;
		

	sscanf(argv[1], "%d", &dateTime.year);
	sscanf(argv[2], "%d", &dateTime.month);
	sscanf(argv[3], "%d", &dateTime.day);
	sscanf(argv[4], "%d", &dateTime.hour);
	sscanf(argv[5], "%d", &dateTime.minute);

	dateTime.year += 1900;

	if ( (dateTime.month < 1) || (dateTime.month > 12) ||
		  (dateTime.day < 1) || (dateTime.day > 31) ||
		  (dateTime.hour > 23) || (dateTime.minute > 59))
		{
		goto SyntaxOnly;
		}

	dbP = FindOpenedApptDatabase ();
		
	if (!dbP)
		{
		ShlInsertText("Could not find an open appointment database\n");
		return;
		}

	alarmTime = TimDateTimeToSeconds (&dateTime);

	sprintf(text, "Alarm time: %d/%d/%d", dateTime.month, dateTime.day, dateTime.year);
	ShlInsertText(text);
	sprintf(text, "  %02d:%02d", dateTime.hour, dateTime.minute);
	ShlInsertText(text);
	sprintf(text, "  (%lu)\n", alarmTime);
	ShlInsertText(text);


	alarmListH = ApptGetAlarmsList (dbP, alarmTime, &alarmCount, &quite);

	if (! alarmListH)
		{
		ShlInsertText("No alarm scheduled\n");
		return;
		}


	if (quite)
		ShlInsertText("Silent alarm\n");
	else
		ShlInsertText("Audible alarm\n");
		
	
	alarmList = (UInt16 *) MemHandleLock (alarmListH);
	for (i = 0; i < alarmCount; i++)
		{
		index = alarmList[i];
		PrintApptRecord (dbP, index);
		}
	MemHandleFree (alarmListH);
			

	ShlInsertText("\n");
	return;
			
	
	Help:
	ShlInsertText("\nPrint records with an alarm at the specified time\n");
	
	SyntaxOnly:
	sprintf(text, "Syntax: %s year month day hour minute\n", argv[0]);  
	ShlInsertText(text);
	}


/**********************************************************************
 * Display the time of the next scheduled alarm.
 *
 * GetTimeOfNextAlarm
 ***********************************************************************/
static void DoGetTimeOfNextAlarm(int argc, Char * argv[])
{
	Char					text[256];
	UInt32					alarmTime;
	DmOpenRef			dbP;
	DateTimeType		dateTime;
	VoidHand				resourceH;
	UInt32 *				resourceP;

		
	if (argc > 1 && !strcmp(argv[1], "?") )
		goto Help;
	else if (argc > 1)
		goto SyntaxOnly;


	// Open the preference database,  that's were the time of the next alarm
	// is stored.
	dbP = PrefOpenPreferenceDB (false);
	if (!dbP)
		{
		ShlInsertText("Could not find preferences database\n");
		return;
		}

	// Get the resouce the contains the time of the next alarm.
	resourceH = (MemHandle) DmGetResource (sysFileCDatebook, alarmPrefRscID);
	if (resourceH)
		{
		resourceP = (UInt32 *) MemHandleLock (resourceH);
		alarmTime = *resourceP;
		MemPtrUnlock (resourceP);
		DmReleaseResource (resourceH);

		TimSecondsToDateTime (alarmTime, &dateTime);

		sprintf(text, "Next alarm at: %d/%d/%d", dateTime.month, dateTime.day,
			dateTime.year);
		ShlInsertText(text);

		sprintf(text, "  %02d:%02d", dateTime.hour, dateTime.minute);
		ShlInsertText(text);

		sprintf(text, "  (%lu)\n", alarmTime);
		ShlInsertText(text);
		}
	else
		{
		ShlInsertText("Could not find alarm time resource\n");
		}
	
	
	DmCloseDatabase (dbP);
			
	ShlInsertText("\n");
	return;
			
	
	Help:
	ShlInsertText("\nPrint the time of the next alarms\n");
	
	SyntaxOnly:
	sprintf(text, "Syntax: %s\n", argv[0]);  
	ShlInsertText(text);
	}


/**********************************************************************
 * Set the time of the next scheduled alarm in the preference 
 * resource file.  The preference resource file is also used as a 
 * state file. 
 *
 * SetTimeOfNextAlarm year month day hour minute
 ***********************************************************************/
static void DoSetTimeOfNextAlarm(int argc, Char * argv[])
{
	char					text[256];
	Boolean				usageErr = false;
	DmOpenRef			dbP;
	UInt32					alarmTime;
	DateTimeType		dateTime;
	VoidHand				resourceH;
	UInt32 *				resourceP;

		
	if (argc > 1 && !strcmp(argv[1], "?") )
		goto Help;
	else if (argc != 6)
		goto SyntaxOnly;

	sscanf(argv[1], "%d", &dateTime.year);
	sscanf(argv[2], "%d", &dateTime.month);
	sscanf(argv[3], "%d", &dateTime.day);
	sscanf(argv[4], "%d", &dateTime.hour);
	sscanf(argv[5], "%d", &dateTime.minute);

	dateTime.year += 1900;

	if ( (dateTime.month < 1) || (dateTime.month > 12) ||
		  (dateTime.day < 1) || (dateTime.day > 31) ||
		  (dateTime.hour > 23) || (dateTime.minute > 59))
		{
		ShlInsertText("\Invalid date\n");
		return;
		}

	alarmTime = TimDateTimeToSeconds (&dateTime);
	
	// Open the preference database,  that's were the time of the next alarm
	// is stored.
	dbP = PrefOpenPreferenceDB (false);
	if (!dbP)
		{
		ShlInsertText("Could not find preferences database\n");
		return;
		}

	// Get the resouce the contains the time of the next alarm,  if the
	// resource does not exist, create it.
	resourceH = DmGetResource (sysFileCDatebook, alarmPrefRscID);
	if (! resourceH)
		{
		resourceH = DmNewResource(dbP, sysFileCDatebook, alarmPrefRscID, sizeof (UInt32));
		if (! resourceH)
			{
			DmCloseDatabase(dbP);
			ShlInsertText("Could not create alarm time resource\n");
			return;
			}
		}

	// Store the time of the next alarm in the resource.
	resourceP = (UInt32 *) MemHandleLock (resourceH);
	*resourceP = alarmTime;
	MemPtrUnlock (resourceP);
	DmReleaseResource (resourceH);
	DmCloseDatabase (dbP);


	sprintf(text, "Next alarm set to: %d/%d/%d", dateTime.month, dateTime.day,
		dateTime.year);
	ShlInsertText(text);

	sprintf(text, "  %02d:%02d", dateTime.hour, dateTime.minute);
	ShlInsertText(text);
	
	sprintf(text, "  (%lu)\n", alarmTime);
	ShlInsertText(text);
			
	ShlInsertText("\n");
	return;
			
	
	Help:
	ShlInsertText("\Set the time of the next alarms\n");
	
	SyntaxOnly:
	sprintf(text, "Syntax: %s\n", argv[0]);  
	ShlInsertText(text);
	}


/**********************************************************************
 * Trigger the next scheduled alarm.
 *
 * DoApptTriggerAlarm
 ***********************************************************************/
static void DoApptTriggerAlarm(int argc, Char * argv[])
{
	Char					text[256];
	UInt32					alarmTime;
	DateTimeType		dateTime;
	UInt32					result;
	UInt16 					cardNo;
	LocalID 				dbID;
	UInt32					ref;
	DmSearchStateType searchInfo;
	SysAlarmTriggeredParamType params;
		
	if (argc > 1 && !strcmp(argv[1], "?") )
		goto Help;
	else if (argc > 1)
		goto SyntaxOnly;


	// Get the time of the next alarm.
	DmGetNextDatabaseByTypeCreator (true, &searchInfo, 
		sysFileTApplication, sysFileCDatebook, true, &cardNo, &dbID);

	alarmTime = AlmGetAlarm (cardNo, dbID, &ref);

	if (! alarmTime)
		{
		ShlInsertText("No alarms pending\n\n");
		return;
		}
		
	// Display the time of the next alsrm.
	TimSecondsToDateTime (alarmTime, &dateTime);

	sprintf(text, "Next alarm at: %d/%d/%d", dateTime.month, dateTime.day,
		dateTime.year);
	ShlInsertText(text);

	sprintf(text, "  %02d:%02d", dateTime.hour, dateTime.minute);
	ShlInsertText(text);

	sprintf(text, "  (%lu)\n\n", alarmTime);
	ShlInsertText(text);
	
	// Send the alarm triggered an alarm display launch codes.
	params.alarmSeconds = alarmTime;
	
	// <RM> 1-19-98, Fixed to pass 0 for flags, instead of sysAppLaunchFlagSubCall
	//  The sysAppLaunchFlagSubCall flag is for internal use by SysAppLaunch only
	//  and should NOT be set  on entry.
	SysAppLaunch (0, 0, 0,
		sysAppLaunchCmdAlarmTriggered, (void *)&params, &result);

	SysAppLaunch (0, 0, 0,
		sysAppLaunchCmdDisplayAlarm, 0, &result);

	return;
			
	
	Help:
	ShlInsertText("\nPrint the time of the next alarms\n");
	
	SyntaxOnly:
	sprintf(text, "Syntax: %s\n", argv[0]);  
	ShlInsertText(text);
	}


/**********************************************************************
 * Create a Appt database for sync testing.
 *
 * DoMemoBuildSyncDB <access ptr>
 ***********************************************************************/
static void DoApptBuildSyncDB(int argc, Char * argv[])
{
	Boolean		usageErr = false, doArchive, doDelete;
	DmOpenRef	dbP=0;
	UInt16 			index, attr;
	char			text[256];
	int			i;
	UInt32			uID;
	LocalID		chunkID;

	// 9:00am - 10:00am on 8/3/95
	ApptDateTimeType	dt1 = {9, 00, 10, 00, 91, 8, 3};
	ApptDBRecordType	testRecords []= {
		{ &dt1, NULL, NULL, NULL, "foo", NULL },				// 30 add - cat 0
		{ &dt1, NULL, NULL, NULL, "foo", NULL },				// 31 delete - cat 0
		{ &dt1, NULL, NULL, NULL, "foo", NULL },				// 32 none - cat 0
		{ &dt1, NULL, NULL, NULL, "foo", NULL },				// 33 delete - cat 0
		{ &dt1, NULL, NULL, NULL, "foo", NULL },				// 34 update - cat 0
		{ &dt1, NULL, NULL, NULL, "foo", NULL },				// 35 update - cat 0
		{ &dt1, NULL, NULL, NULL, "foo", NULL },				// 36 none - cat 0
		{ &dt1, NULL, NULL, NULL, "foo", NULL },				// 37 update - cat 0
		{ &dt1, NULL, NULL, NULL, "foo", NULL },				// 38 update - cat 0
		{ &dt1, NULL, NULL, NULL, "foo", NULL },				// 39 archive/none - cat 0
		{ &dt1, NULL, NULL, NULL, "foo", NULL },				// 40 archive/none - cat 0
		{ &dt1, NULL, NULL, NULL, "foo", NULL },				// 41 archive/none - cat 0
		{ &dt1, NULL, NULL, NULL, "foo", NULL },				// 42 archive/update - cat 0
		{ &dt1, NULL, NULL, NULL, "foo", NULL },				// 43 archive/update - cat 0
		{ &dt1, NULL, NULL, NULL, "foo", NULL },				// 44 none - cat 0
		{ &dt1, NULL, NULL, NULL, "foo", NULL },				// 45 delete - cat 0
		{ &dt1, NULL, NULL, NULL, "foo", NULL },				// 46 update - cat 0
		{ &dt1, NULL, NULL, NULL, "foo", NULL },				// 47 update - cat 0
		{ &dt1, NULL, NULL, NULL, "foo", NULL }				// 48 update - cat 0
	};


	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			usageErr = true;
		}

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}

	if (!dbP)
		dbP = FindOpenedApptDatabase ();

	if (!dbP)
		{
		ShlInsertText("Could not find an open appointment database\n");
		return;
		}


	sprintf (text, "record  unique\nindex   id\n");
	ShlInsertText (text);

	for (i = 0; i < sizeof (testRecords) / sizeof (ApptDBRecordType); i++) {
		ApptNewRecord(dbP, &testRecords[i], &index);

		// Get the category and the sercrt attribute of the current record.
		DmRecordInfo (dbP, index, &attr, NULL, NULL);	

		// clear the current category & the dirty flag
		attr &= ~dmRecAttrCategoryMask;
		attr &= ~dmRecAttrDirty;
		doArchive = doDelete = false;
	
		if (i == 0) {				//  30 add - cat 0
			attr |= dmRecAttrDirty;
			}
			
		else if (i == 1) {		// 31 delete - cat 0
			doDelete = true;
			}

		else if (i == 2) {		// 32 none - cat 0			
			;
			}	
			
		else if (i == 3) {		//  33 delete - cat 0
			doDelete = true;
			}
			
		else if (i == 4) {		//  34 update - cat 0
			attr |= dmRecAttrDirty;
			}
			
		else if (i == 5) {		// 35 update - cat 0
			attr |= dmRecAttrDirty;
			}
			
		else if (i == 6) {		// 36 none - cat 0
			;
			}
			
		else if (i == 7) {		//37 update - cat 0
			attr |= dmRecAttrDirty;
			}
			
		else if (i == 8) {		// 38 update - cat 0
			attr |= dmRecAttrDirty;
			}
			
		else if (i == 9) {		// 39 archive/none - cat 0
			doArchive = true;
			}
			
		else if (i == 10) {		// 40 archive/none - cat 0
			doArchive = true;
			}
			
		else if (i == 11) {		// 41 archive/none - cat 0
			doArchive = true;
			}
			
		else if (i == 12) {		// 42 archive/update - cat 0
			attr |= dmRecAttrDirty;
			doArchive = true;
			}
			
		else if (i == 13) {		// 43 archive/update - cat 0
			attr |= dmRecAttrDirty;
			doArchive = true;
			}
			
		else if (i == 14) {		// 44 none - cat 0
			;
			}
			
		else if (i == 15) {		// 45 delete - cat 0
			doDelete = true;
			}
			
		else if (i == 16) {		//  46 update - cat 0
			attr |= dmRecAttrDirty;
			}
			
		else if (i == 17) {		//  47 update - cat 0
			attr |= dmRecAttrDirty;
			}
			
		else if (i == 18) {		//  48 update - cat 0
			attr |= dmRecAttrDirty;
			}
			
			
		// Save the new category and flags
		DmSetRecordInfo (dbP, index, &attr, NULL);
		
		DmRecordInfo(dbP, index, &attr, &uID, &chunkID);
		
		if (doArchive)
			DmArchiveRecord(dbP, index);

		if (doDelete)
			DmDeleteRecord(dbP, index);

		sprintf (text, "%d     %lu\n", index, uID);
		ShlInsertText (text);
		}
}



/**********************************************************************
 * Create a second, more complex Appt database for sync testing.
 *
 * DoMemoBuildSyncDB2 [access ptr]
 ***********************************************************************/
static void DoApptBuildSyncDB2(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	UInt16 			index, attr;
	char			text[256];
	int			i;
	Err			error = 0;


	// repeating every other month until 12/31/96
	RepeatInfoType		ri1 = {repeatMonthlyByDate, 92, 12, 31, 2, 0, 0};
	// repeating on the third friday of every other month until 12/31/96								
	RepeatInfoType		ri2 = {repeatMonthlyByDay, 92, 12, 31, 2, dom1stWen};
	// repeating every other month until 12/31/96
	RepeatInfoType		ri4 = {repeatYearly, 92, 12, 31, 1, 0};
	// repeating weekly until 12/31/96, every other Sunday and Thursday.
	RepeatInfoType		ri5 = {repeatWeekly, 92, 12, 31, 2, 0x11};
	// repeating every third day until 12/31/96.
	RepeatInfoType		ri7 = {repeatDaily, 92, 12, 31, 3, 0};

	ApptDateTimeType	dt1 = {9, 00, 10, 00, 90, 8, 3};	// 9:00am - 10:00am on 8/3/94
	AlarmInfoType 		ai1 = {5, aauMinutes};	// alarm 5 minutes prior
	DateType 			ex1[4] = {0, 0, 0, 91, 9, 29, 91, 11, 24, 92, 12, 27};	// four repeat exceptions
	ApptDBRecordType	testRecord1 = {
								&dt1, &ai1, &ri1, 
								(ExceptionsListType *) ((UInt16 *) &ex1), 
								"Description", "Note" };
	ApptDBRecordType	testRecord2 = {
								&dt1, &ai1, NULL, 
								NULL, 
								"Description", "Note" };


	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			usageErr = true;
		}

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}

	if (!dbP)
		dbP = FindOpenedApptDatabase ();

	if (!dbP)
		{
		ShlInsertText("Could not find an open appointment database\n");
		return;
		}

	// Fixup expection list with number of exceptions
	*((UInt16 *) &ex1) = 3;

	for (i = 1; i <= 9 && error == 0; i++)
		error = ApptNewRecord(dbP, &testRecord1, &index);

	if (error == 0)
		{		
		// Get the category and the sercrt attribute of the last record.
		DmRecordInfo (dbP, index, &attr, NULL, NULL);	

		// clear the dirty flag
		attr &= ~dmRecAttrDirty;
	
		// Save the new flags
		DmSetRecordInfo (dbP, index, &attr, NULL);
		}
	
	if (error == 0)
		{		
		testRecord1.repeat = &ri2;
		error = ApptNewRecord(dbP, &testRecord1, &index);
		}

	if (error == 0)
		{		
		testRecord1.repeat = &ri4;
		error = ApptNewRecord(dbP, &testRecord1, &index);
		}

	if (error == 0)
		{		
		testRecord1.repeat = &ri5;
		error = ApptNewRecord(dbP, &testRecord1, &index);
		}

	if (error == 0)
		{		
		testRecord1.repeat = &ri7;
		error = ApptNewRecord(dbP, &testRecord1, &index);
		}

	if (error == 0)
		error = ApptNewRecord(dbP, &testRecord2, &index);

	if (error)
		ShlInsertText("Error from adding new record\n");
	else
		ShlInsertText("New records added\n");
}


/**********************************************************************
 * Function to read a char from a disk file for vcal importing.
 ***********************************************************************/

static UInt16 GetChar(const void * stream)
{
	return fgetc((FILE *) stream);
}


/**********************************************************************
 * Function to write a string to the disk file for vcard exporting.
 ***********************************************************************/

static void PutString(void * stream, const Char * const stringP)
{
	fwrite(stringP, sizeof(UInt8), strlen(stringP), (FILE *) stream);
}


/*****************************************************
*  Note: this is a dummy version of this routine,
*  it simply reads to the end of the vToDo Block
*****************************************************/

static Boolean VCalToDoDUMMMYRead(DmOpenRef dbP, void * inputStream, GetCharF inputFunc, 
	Boolean obeyUniqueIDs, Boolean beginAlreadyRead)
{
	char identifier[40];
	int identifierEnd;
	UInt16 * charAttrP;
	Boolean lastCharWasQuotedPrintableContinueToNextLineChr;
	char c;
	
	charAttrP = GetCharAttr();
	c = inputFunc(inputStream);

	
	do
		{		
		// Advance to the next line.  If the property wasn't handled we need to make sure that
		// if the property value contains quoted printable text that newlines within that 
		// section are skipped.
		lastCharWasQuotedPrintableContinueToNextLineChr = (c == '=');
		while (c != '\n' && !lastCharWasQuotedPrintableContinueToNextLineChr)
			{
			lastCharWasQuotedPrintableContinueToNextLineChr = (c == '=');
			c = inputFunc(inputStream);
			} 
		c = inputFunc(inputStream);
		
		
		identifierEnd = 0;
		while (IsAlpha(charAttrP, c))
			{
			identifier[identifierEnd++] = (char) c;
			c = inputFunc(inputStream);
			}
		identifier[identifierEnd++] = nullChr;
		
		// stop if at the end
		if (StrCaselessCompare(identifier, "END") == 0)
			{
			// Advance to the next line.
			while (c != '\n')
				{
				c = inputFunc(inputStream);
				} 
			
			break;
			}
		
		} while (true);
		

	return true;
}

			
/**********************************************************************
 * Export the database to vCal format.
 *
 * DoApptExportVCal <access ptr> <file out>
 ***********************************************************************/
static void DoApptExportVCal(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	char			fileOutName[64] = "\0";
	ApptDBRecordType	record;
	MemHandle 		recordH;
	char			text[256];
	int 			index;
	int 			numOfRecords;
	int			i;


	for (i=1; i<argc; i++) {
		if (i == 1)
			sscanf(argv[i], "%lx", &dbP);
		else
		if (!*fileOutName)
			sscanf(argv[i], "%s", fileOutName);
		else
			usageErr = true;
	
		}

	if (!dbP) dbP = FindOpenedApptDatabase();
	
	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr> <file out>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}

	FILE*	fileOut=0;
	fileOut = fopen(fileOutName, "wb");
	if (!fileOut) {
		sprintf(text, "\nCan\'t use file: %s\n", fileOutName);
		ShlInsertText(text);
		return;
		}
	
	PutString(fileOut, "BEGIN:VCALENDER\015\012");
	PutString(fileOut, "VERSION:1.0\015\012");

	
	numOfRecords = DmNumRecordsInCategory(dbP, dmAllCategories);
	for (index = 0; index < numOfRecords; index++) 
		{
		
		ApptGetRecord(dbP, index, &record, &recordH);
		}
	
	PutString(fileOut, "END:VCALENDER\015\012");
	
	fclose(fileOut);
}
			

/**********************************************************************
 * Import todo's from vCal format.
 *
 * DoApptImportVCal <access ptr> <file in>
 ***********************************************************************/
static void DoApptImportVCal(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	char	fileInName[64] = "\0";
	char	text[5000];
	int	i;


	for (i=1; i<argc; i++) {
		if (i == 1)
			sscanf(argv[i], "%lx", &dbP);
		else
		if (!*fileInName)
			sscanf(argv[i], "%s", fileInName);
		else
			usageErr = true;
	
		}

	if (!dbP) dbP = FindOpenedApptDatabase();
	
	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr> <file in>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}

	FILE*	fileIn=0;
	fileIn = fopen(fileInName, "rb");
	if (!fileIn) {
		sprintf(text, "\nUnknown input file: %s\n", fileInName);
		ShlInsertText(text);
		return;
		}
	
	

	fclose(fileIn);
}


/**********************************************************************
 * Support for Roger's commands
 *
 * returns 0 if successfully found command
 ***********************************************************************/
int ShlDoAppCmd(int argc, Char * argv[])
{
	int i;
	ShellCmdInfoType cmd [] ={ 	
		"ApptAppInfoInit", 			"",  		DoApptSetInfoDefaults,
		"ApptNew",						"an",		DoApptTestNewRecord,
		"ApptGetRecord",				"agr",	DoApptGetRecord,
		"ApptGetAll",					"ad",		DoApptGetAll,
		"ApptChangeRecord",			"",		DoApptChangeRecord,
		"ApptSync",						"",		DoApptSync,
		"ApptRepeat",					"ar",		DoApptRepeat,
		"ApptNextRepeat",				"anr",	DoApptNextRepeat,
		"ApptOnDate",					"aod",	DoApptOnDate,
		"ApptAlarmTimes",				"aat",	DoApptAlarmTimes,
		"ApptAlarmList",				"aal",	DoApptAlarmList,
		"ApptGetTimeOfNextAlarm",	"aga",	DoGetTimeOfNextAlarm,
		"ApptSetTimeOfNextAlarm",	"asa",	DoSetTimeOfNextAlarm,
		"ApptTriggerAlarm",			"ata",	DoApptTriggerAlarm,
		"ApptBuildSyncDB",			"abs",	DoApptBuildSyncDB,
		"ApptBuildSyncDB2",			"abs2",	DoApptBuildSyncDB2,
		"ApptExportVCal",				"exvc",  DoApptExportVCal,
		"ApptImportVCal",				"imvc",  DoApptImportVCal,
		};
			
	for (i = 0; i < sizeof (cmd) / sizeof (ShellCmdInfoType); i++)
		{
		if ( (!ShlStrCmpi(argv[0], cmd[i].longName)) ||
			  (!ShlStrCmpi(argv[0], cmd[i].shortName)))
			{
			cmd[i].func (argc, argv);
			return 0;
			}
		}
	return 1;
}
