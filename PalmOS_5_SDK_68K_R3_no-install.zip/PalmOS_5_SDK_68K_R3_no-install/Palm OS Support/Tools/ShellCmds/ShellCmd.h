/******************************************************************************
 *
 * Copyright (c) 1994-2002 PalmSource, Inc. All rights reserved.
 *
 * File: ShellCmd.h
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 * Description:
 *		Test functions for Pilot
 *
 *****************************************************************************/

#ifndef 	__SHELLCMD_H__
#define	__SHELLCMD_H__

// Build rules for linking in additional shell commands.
#define SHELL_COMMAND_NOT_AVAILABLE		0
#define SHELL_COMMAND_AVAILABLE			1

#ifndef	SHELL_COMMAND_DB
	#define SHELL_COMMAND_DB 	SHELL_COMMAND_AVAILABLE
#endif

#ifndef	SHELL_COMMAND_UI
	#define SHELL_COMMAND_UI	SHELL_COMMAND_NOT_AVAILABLE
#endif

#ifndef	SHELL_COMMAND_APP
	#define SHELL_COMMAND_APP	SHELL_COMMAND_NOT_AVAILABLE
#endif				

#ifndef	SHELL_COMMAND_EMULATOR
	#define SHELL_COMMAND_EMULATOR	SHELL_COMMAND_NOT_AVAILABLE
#endif				




// Dump options for ShlDumpHex
#define shlDumpOptAddress		0x0001			// print address in front of hex data
#define shlDumpOptAscii			0x0002			// print ascii after hex
#define shlDumpOptEndNewLine	0x0004			// end dump with newline
#define shlDumpOptAll	(shlDumpOptAddress | shlDumpOptAscii)


/************************************************************
 * Prototypes for Shell Support
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif



//-------------------------------------------------------------
// Private Shell utilities
//-------------------------------------------------------------
#ifdef 		__SHELL_PRIVATE__

void 			ShlSetCharConstant(UInt32 *var, Char *str);
void 			ShlSPrintCharConstant(Char *str, UInt32 var);


void *		ShlGetMemoryCardImage(Int16 cardNo, UInt32 *actSizeP, 
									UInt32 newSize, Boolean newFile);
Err  			ShlSaveCloseMemoryCardImage(UInt16 cardNo, Boolean saveState, 
									Boolean dispose);


Boolean 		ShlCheckChunkContents(void *dataP, UInt32 oldSize);
Boolean 		ShlHeapDumpNCheck(unsigned int heapID, int dumpLevel,
						UInt32 *freeBytesP, Boolean checkContents, Boolean labelChunks);

void 			ShlFillChunkContents(void *dataP);

UInt32			ShlLargestFreeChunk(UInt16 heapID);

UInt16			ShlRandomNum(UInt16 range);
LocalID		ShlGetRandomChunkP(UInt16 heapID, Boolean movableOnly);

void 			ShlImportResForkAsResourceDB(Int16 cardNo, Char *nameP);

void 			ShlExportAsMacResourceFile(Int16 cardNo, Char *nameP);
void 			ShlExportAsPilotFile(Int16 cardNo, const Char *nameP);

Err				ShlDeleteDatabase (UInt16 cardNo, LocalID dbID);

#endif 		// __SHELL_PRIVATE__



//-------------------------------------------------------------
// This routine provided by the Shell Command Modules
//-------------------------------------------------------------
int 			ShlExecuteCmdLine(Char *cmd);
int 			ShlDoUICmd(int argc, Char *argv[]);
int 			ShlDoDBCmd(int argc, Char *argv[]);
int 			ShlDoAppCmd(int argc, Char *argv[]);
int 			ShlDoEmulatorCmd(int argc, Char *argv[]);
int 			ShlDoGremlinsCmd(int argc, Char *argv[]);

// This is used by the emulator to import/export the application and system resource
void 			ShlImportPilotFile(Int16 cardNo, const Char *nameP, 
							Boolean preserveUniqueIDs, Boolean preserveDates,
							Boolean printToShell);
void			ShlExportAsPilotFileWithName(Int16 cardNo, const Char *nameP, const Char *fileName);

// Identify a pointer. Look up which chunk it is in (*chunkPP)
// the offset within the chunk (*offsetP), the database it
// belongs to if any (dbNameStr), the resource type (*resTypeP) &
// the resource id (*resIDP) OR record number (*recNumP). Used by the
// GDB Debugger to help associated a symbol file with a code pointer
Err				ShlIdentifyChunk (void* p, UInt16* cardNoP, UInt16* heapIDP,
					void** chunkPP, UInt32* offsetP,
					Char dbNameStr[32], UInt32* resTypeP,
					UInt16* resIDP, UInt16* recNumP);

// Send a key event to device through the console serial link socket
Err				ShlSendKey (WChar ascii, UInt16 keyCode, UInt16 modifiers);


// These access routines come from ShellAccess.cpp and either go to local memory
//  or the device on the serial port depending on the setting of the compiler
//  variable MEMORY_TYPE
void 			ShlReadMem(void *bufP, UInt32 addr, UInt32 byteCount);
void 			ShlWriteMem(void *bufP, UInt32 addr, UInt32 byteCount);
void 			ShlCacheFlush(void);
UInt32 		ShlDWord(void *addr);
#define		ShlWord(addr) \
				(UInt16)(ShlDWord(addr) >> 16)
#define		ShlByte(addr) \
				(UInt8)(ShlDWord(addr) >> 24)


// Perform a quick "ping" to the remote device to test if console communications
//  are working or not. This is a faster timeout that a generic RCP call is
Err				ShlPing (void);


//-------------------------------------------------------------
//  These routines must be provided by the host OS.
//-------------------------------------------------------------
void 			ShlInsertText(const Char *msg);
void			ShlInsertMixed(void *dataP, UInt32 dataSize);
void			ShlPrintf(const Char *format, ...);
void			ShlDumpHex(void *dataP, UInt32 byteCount, UInt16 dumpOptions);
int 			ShlStartLogging(Char *logNameP);
Char *		ShlStopLogging(void);
void 			ShlSetEcho(Boolean echo);
void 			ShlGetSelection(UInt32 *startP, UInt32 *endP);
void			ShlDeleteSubText(UInt32 start, UInt32 end);
void 			ShlSetSelection(UInt32 start, UInt32 end);
void *		ShlNewBuffer(UInt32 size);
void			ShlFreeBuffer(void *bufP);
Boolean 		ShlButtonPressed(void);
int	 		ShlStrCmpi(const Char *s1, const Char *s2);
void			ShlBlockMove(void *srcP, void *destP, UInt32 byteCount);
unsigned int	ShlSocketID(void);
const Char*			ShlDeviceDir(void);



#ifdef __cplusplus 
}
#endif

#endif	// __SHELLCMD_H__
