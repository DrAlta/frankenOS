/******************************************************************************
 *
 * Copyright (c) 1999-2002 PalmSource, Inc. All rights reserved.
 *
 * File: ShellCmdToDo.cpp
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 * Description:
 * This file contains test code for Pilot that is used in both
 *  DOS and Windows apps
 *
 *****************************************************************************/

// Pilot Includes 
#include <Pilot.h>

// Borland Includes
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include <IMCUtils.h>

// DB includes
#include "ToDo.h"
//#include "ToDoDB.h"

#include "ShellCmd.h"

#define toDoDBType				'DATA'


typedef void ShellCmdFuncType (int argc, Char * argv[]);
typedef ShellCmdFuncType * ShellCmdFuncPtr;
typedef struct {
	Char *				longName;
	Char *				shortName;
	ShellCmdFuncPtr	func;
} ShellCmdInfoType;


#pragma pcrelstrings off


/**********************************************************************
 * find an open appointment database
 *
 * Parameters: none
 ***********************************************************************/
static DmOpenRef FindOpenedToDoDatabase (void)
{
	DmOpenRef	dbP=0;
	LocalID		dbID;
	UInt16			mode;
	UInt16			cardNo;
	UInt32			dbType;
	UInt32			dbCreator;
	
	do {
		dbP = DmNextOpenDatabase(dbP);
		if (!dbP) break;

		Err err = DmOpenDatabaseInfo(dbP, &dbID, NULL, &mode, &cardNo, NULL);
		if (err) 
			{
			ShlInsertText("\n#ERROR getting info");
			}
		else
			{
			DmDatabaseInfo(cardNo, dbID, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				&dbType, &dbCreator);

			if ( (dbType == toDoDBType) && (dbCreator == sysFileCToDo) )
				return (dbP);
			}
		} while (1);


	return(0);
}


/**********************************************************************
 * Print an to do record.
 *
 * Parameters: database, record index
 *
 *	Revision History:
 *
 *		Name		Date		Description
 *		----		----		-----------
 *		kcr		10/24/95	included deleted records & sync-flags
 *
 ***********************************************************************/
static void PrintToDoRecord (DmOpenRef dbP, UInt16 index)
{
	Char *				c;
	char 					text[256];
	LocalID				chunk;
	UInt16					attr;
	UInt32					uniqueID;
	VoidHand				recordH;
	ToDoDBRecordPtr	testRecord;

	DmRecordInfo (dbP, index, &attr, &uniqueID, &chunk);

	// Print record index.
	sprintf(text, "\nIndex:  %d", index);
	ShlInsertText(text);
	
	// Print the unique id
	sprintf(text, ",  unique id: %ld", uniqueID);
	ShlInsertText(text);
	
	//	Print the category info
	sprintf (text, ",  category: %d", attr & dmRecAttrCategoryMask);
	ShlInsertText (text);

	if ((attr & dmRecAttrDelete) && chunk)
		ShlInsertText ("\tArchived");
	else if (attr & dmRecAttrDelete)
		ShlInsertText ("\tDeleted");
	if (attr & dmRecAttrDirty)
		ShlInsertText ("\tDirty");
	if (attr & dmRecAttrBusy)
		ShlInsertText ("\tBusy");
	if (attr & dmRecAttrSecret)
		ShlInsertText ("\tSecret");

	if (attr & dmRecAttrDelete)
		return;

	recordH = DmQueryRecord(dbP, index);
	if (recordH == 0)
		{
		ShlInsertText("Error!");
		return;
		}

	testRecord = (ToDoDBRecordPtr) MemHandleLock (recordH);
	
	// Print the priority and the completion status.
	sprintf(text, "\nPriority: %d, Complete: %d, ", testRecord->
		priority & priorityOnly, 
		(testRecord->priority & completeFlag) == completeFlag);
	ShlInsertText(text);
	
	// Print the due date.
	if ((*(int *) &testRecord->dueDate) == -1)
		ShlInsertText("Due date: none\n");
	else
		{
		sprintf(text, "due date: %d/%d/%d\n", testRecord->dueDate.month,
			testRecord->dueDate.day, testRecord->dueDate.year+4);
		ShlInsertText(text);
		}	

	// Print the desctiption field.
	ShlInsertText("Desc:   ");
	ShlInsertText(&testRecord->description);
	ShlInsertText("\n");

	// Print the note.
	c = &testRecord->description;
	c += strlen(c) +1;
	if (*c != '\0')
		{
		ShlInsertText("Note:   ");
		ShlInsertText(c);
		ShlInsertText("\n");
		}
		
	MemHandleUnlock (recordH);
	}



/**********************************************************************
 * Set the To Do application chunk to the defaults.
 *
 * ToDoSetInfoDefaults <access ptr>
 ***********************************************************************/
static void DoToDoSetInfoDefaults(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	char			text[256];
	int			i;

	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			usageErr = true;
		
		}

	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr>\n", argv[0]);
		ShlInsertText(text);
		return;
		}

	Err err = ToDoAppInfoInit(dbP);
	if (err) {
		ShlInsertText("\n##ERROR Setting defaults\n");
		}
	else {
		ShlInsertText("Success!\n");
		}
}



/**********************************************************************
 * Test the newRecord function.
 *
 * DoToDoTestNewRecord <access ptr>
 ***********************************************************************/
static void DoToDoTestNewRecord(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	UInt16 			index;
	char			text[256];
	int			i;

	ToDoItemType	testRecords []= {
		{91,  1, 23, 1, "Get CD", ""},
		{91,  1, 25, 3, "Walk dog", "Go to Spruce street"},
		{92,  1, 14, 3, "Go skiing", ""},
		{91,  1, 23, 1, "Get airplane tickets", ""},
		{91,  6,  4, 1, "Send fax to Bob", ""},
		{91,  1, 23, 1, "Wash car", ""},
		{91,  2, 23, 1, "Prepare demo", ""},
		{91,  7,  1, 1, "Tell Bob report is\nlate", ""},
		{91,  5, 23, 1, "Fire Bob", ""},
		{91,  2, 24, 1, "Hire Bob's replacement", ""},
		{91, 10, 25, 1, "Book flight to Boston", ""},
		{91,  3, 15, 1, "Call Mom", ""}
	};


	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			usageErr = true;
		}

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}

	if (!dbP)
		dbP = FindOpenedToDoDatabase ();

	if (!dbP)
		{
		ShlInsertText("Could not find an open to do database\n");
		return;
		}


	for (i = 0; i < sizeof (testRecords) / sizeof (ToDoItemType); i++)
		{
		ToDoNewRecord (dbP, &testRecords[i], dmUnfiledCategory, &index);
		sprintf (text, "%d\n", index);
		ShlInsertText (text);
		}
}



/**********************************************************************
 * Create a Todo database for sync testing.
 *
 * DoToDoBuildSyncDB <access ptr>
 ***********************************************************************/
static void DoToDoBuildSyncDB(int argc, Char * argv[])
{
	Boolean		usageErr = false, doArchive, doDelete;
	DmOpenRef	dbP=0;
	UInt16 			index, attr;
	char			text[256];
	int			i;
	UInt32			uID;
	LocalID		chunkID;

	ToDoItemType	testRecords []= {
		{95,  8, 30, 1, "foo", ""},				// 30 add - cat 0
		{95,  8, 30, 1, "foo", ""},				// 31 delete - cat 1
		{95,  8, 30, 1, "foo", ""},				// 32 none - cat 2
		{95,  8, 30, 1, "foo", ""},				// 33 delete - cat 3
		{95,  8, 30, 1, "foo", ""},				// 34 update - cat 0
		{95,  8, 30, 1, "foo", ""},				// 35 update - cat 1
		{95,  8, 30, 1, "foo", ""},				// 36 none - cat 2
		{95,  8, 30, 1, "foo", ""},				// 37 update - cat 3
		{95,  8, 30, 1, "foo", ""},				// 38 update - cat 0
		{95,  8, 30, 1, "foo", ""},				// 39 archive/none - cat 1
		{95,  8, 30, 1, "foo", ""},				// 40 archive/none - cat 2
		{95,  8, 30, 1, "foo", ""},				// 41 archive/none - cat 3
		{95,  8, 30, 1, "foo", ""},				// 42 archive/update - cat 0
		{95,  8, 30, 1, "foo", ""},				// 43 archive/update - cat 1
		{95,  8, 30, 1, "foo", ""},				// 44 none - cat 2
		{95,  8, 30, 1, "foo", ""},				// 45 delete - cat 3
		{95,  8, 30, 1, "foo", ""},				// 46 update - cat 0
		{95,  8, 30, 1, "foo", ""},				// 47 update - cat 1
		{95,  8, 30, 1, "foo", ""}					// 48 update - cat 2
	};


	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			usageErr = true;
		}

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}

	if (!dbP)
		dbP = FindOpenedToDoDatabase ();

	if (!dbP)
		{
		ShlInsertText("Could not find an open to do database\n");
		return;
		}


	sprintf (text, "record  unique\nindex   id\n");
	ShlInsertText (text);

	for (i = 0; i < sizeof (testRecords) / sizeof (ToDoItemType); i++)
		{
		ToDoNewRecord (dbP, &testRecords[i], dmUnfiledCategory, &index);

		// Get the category and the sercrt attribute of the current record.
		DmRecordInfo (dbP, index, &attr, NULL, NULL);	

		// clear the current category & the dirty flag
		attr &= ~dmRecAttrCategoryMask;
		attr &= ~dmRecAttrDirty;
		doArchive = doDelete = false;
	
		if (i == 0) {				//  30 add - cat 0
			attr |= dmRecAttrDirty;
			}
			
		else if (i == 1) {		// 31 delete - cat 1
			attr |= 1;
			doDelete = true;
			}

		else if (i == 2) {		// 32 none - cat 2			
			attr |= 2;
			}	
			
		else if (i == 3) {		//  33 delete - cat 3
			doDelete = true;
			attr |= 3;
			}
			
		else if (i == 4) {		//  34 update - cat 0
			attr |= dmRecAttrDirty;
			}
			
		else if (i == 5) {		// 35 update - cat 1
			attr |= dmRecAttrDirty;
			attr |= 1;
			}
			
		else if (i == 6) {		// 36 none - cat 2
			attr |= 2;
			}
			
		else if (i == 7) {		//37 update - cat 3
			attr |= dmRecAttrDirty;
			attr |= 3;
			}
			
		else if (i == 8) {		// 38 update - cat 0
			attr |= dmRecAttrDirty;
			}
			
		else if (i == 9) {		// 39 archive/none - cat 1
			attr |= 1;
			doArchive = true;
			}
			
		else if (i == 10) {		// 40 archive/none - cat 2
			attr |= 2;
			doArchive = true;
			}
			
		else if (i == 11) {		// 41 archive/none - cat 3
			attr |= 3;
			doArchive = true;
			}
			
		else if (i == 12) {		// 42 archive/update - cat 0
			attr |= dmRecAttrDirty;
			doArchive = true;
			}
			
		else if (i == 13) {		// 43 archive/update - cat 1
			attr |= dmRecAttrDirty;
			attr |= 1;
			doArchive = true;
			}
			
		else if (i == 14) {		// 44 none - cat 2
			attr |= 2;
			}
			
		else if (i == 15) {		// 45 delete - cat 3
			attr |= 3;
			doDelete = true;
			}
			
		else if (i == 16) {		//  46 update - cat 0
			attr |= dmRecAttrDirty;
			}
			
		else if (i == 17) {		//  47 update - cat 1
			attr |= dmRecAttrDirty;
			attr |= 1;
			}
			
		else if (i == 18) {		//  48 update - cat 2
			attr |= dmRecAttrDirty;
			attr |= 2;
			}
			
			
		// Save the new category and flags
		DmSetRecordInfo (dbP, index, &attr, NULL);
		
		DmRecordInfo(dbP, index, &attr, &uID, &chunkID);
		
		if (doArchive)
			DmArchiveRecord(dbP, index);

		if (doDelete)
			DmDeleteRecord(dbP, index);

		sprintf (text, "%d     %lu\n", index, uID);
		ShlInsertText (text);
		}
}



/**********************************************************************
 * Get an record and print in Address format.
 *
 * DoToDoGetRecord <access ptr> <index>
 ***********************************************************************/
static void DoToDoGetRecord(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	char			text[256];
	char *c;
	ToDoDBRecordPtr	testRecord;
	UInt16 index = 0;
	int			i;
	
	
	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
		if (!index)
			sscanf(argv[i], "%d", &index);
		else
			usageErr = true;
		
		}

	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr> <index>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}


	if ((testRecord = *(ToDoDBRecord **) DmQueryRecord(dbP, index)) == 0)
		{
		ShlInsertText("Error!");
		return;
		}
	
	
	ShlInsertText(&testRecord->description);
	sprintf(text, "\npriority: %d, complete: %d, ", testRecord->
		priority & priorityOnly, 
		(testRecord->priority & completeFlag) == completeFlag);
	ShlInsertText(text);
	
		if ((*(int *) &testRecord->dueDate) == -1)
		ShlInsertText("due date: none\n");
	else
		{
		sprintf(text, "due date: %d/%d/%d\n", testRecord->dueDate.month,
			testRecord->dueDate.day, testRecord->dueDate.year+4);
		ShlInsertText(text);
		}	
	
	c = &testRecord->description;
	c += strlen(c) +1;
	if (*c != '\0') {
		ShlInsertText("NOTES: ");
		ShlInsertText(c);
		ShlInsertText("\n");
	}
}



/**********************************************************************
 * Get all records and print in todo format.
 *
 * DoToDoGetAll <access ptr>
 ***********************************************************************/
static void DoToDoGetAll(int argc, Char * argv[])
{
	char					text[256];
	Boolean				usageErr = false;
	DmOpenRef			dbP = 0;
	UInt16 					index = 0;
	int					i;
	
	
	for (i=1; i<argc; i++) {
		if (*argv[i] == '?')
			goto Help;
		else if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
			goto SyntaxOnly;
		}

	if (!dbP)
		dbP = FindOpenedToDoDatabase ();
		
	if (!dbP)
		{
		ShlInsertText("Could not find an open To Do database\n");
		return;
		}


	for (index = 0; index < DmNumRecords(dbP); index++)
		PrintToDoRecord (dbP, index);
	ShlInsertText("\n");

	return;

	
Help:
	ShlInsertText("\nPrint all records in the To Do database\n");
	ShlInsertText("and their sync flags.\n");

SyntaxOnly:
	sprintf(text, "Syntax: %s [access ptr]\n", argv[0]);  
	ShlInsertText(text);

}


/**********************************************************************
 * Get an record and print in To Do format.
 *
 * DoToDoChangeRecord <access ptr> <index>
 ***********************************************************************/
static void DoToDoChangeRecord(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	char			text[256];
	UInt16 index = 0;
	UInt16 result;
	unsigned int data;
	int			i;
	
	
	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		else
		if (!index)
			sscanf(argv[i], "%d", &index);
		else
			usageErr = true;
		
		}

	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr> <index>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}


	data = 5;
	result = ToDoChangeRecord(dbP, &index, toDoPriority, &data);
	sprintf(text, "%d\n", index);
	ShlInsertText(text);

	data = 1;
	index = 0;
	result = ToDoChangeRecord(dbP, &index, toDoComplete, &data);
	sprintf(text, "%d\n", index);
	ShlInsertText(text);

	data = -1;
	index = 0;
	result = ToDoChangeRecord(dbP, &index, toDoDueDate, &data);
	sprintf(text, "%d\n", index);
	ShlInsertText(text);

	data = 1;
	index = 0;
	result = ToDoChangeRecord(dbP, &index, toDoDescription, "Rent a bus");
	sprintf(text, "%d\n", index);
	ShlInsertText(text);

	data = 1;
	index = 1;
	result = ToDoChangeRecord(dbP, &index, toDoNote, "Easy to do");
	sprintf(text, "%d\n", index);
	ShlInsertText(text);
}


/**********************************************************************
 * Set the ToDo application chunk to the defaults.
 *
 * ToDoChangeSortOrder <access ptr> <1 = sort by company>
 ***********************************************************************/
static void DoToDoChangeSortOrder(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	Boolean 	sortByPriority = false;
	char		text[256];
	long t1, t2;
	int		i;

	for (i=1; i<argc; i++) {
		if (!dbP)
			sscanf(argv[i], "%lx", &dbP);
		if (!sortByPriority)
			sortByPriority = *argv[i] == '1';
		else
			usageErr = true;
		
		}

	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr> <1 = sort by priority>\n", argv[0]);
		ShlInsertText(text);
		return;
		}

	t1 = TimGetTicks();
	Err err = ToDoChangeSortOrder(dbP, sortByPriority);
	t2 = TimGetTicks();
	if (err) {
		ShlInsertText("\n##ERROR Setting defaults\n");
		}
	else {
		sprintf(text, "%d Pilot ticks\n", (t2-t1)*40);
		ShlInsertText(text);
		}
}


/**********************************************************************
 * Function to read a char from a disk file for vcal importing.
 ***********************************************************************/

static UInt16 GetChar(const void * stream)
{
	return fgetc((FILE *) stream);
}


/**********************************************************************
 * Function to write a string to the disk file for vcard exporting.
 ***********************************************************************/

static void PutString(const void * stream, const Char * stringP)
{
	fwrite(stringP, sizeof(UInt8), strlen(stringP), (FILE *) stream);
}


/*****************************************************
*  Note: this is a dummy version of this routine,
*  it simply reads to the end of the VEvent Block
*****************************************************/

static Boolean VCalEventDUMMMYRead(DmOpenRef dbP, void * inputStream, GetCharF inputFunc, 
	Boolean obeyUniqueIDs, Boolean beginAlreadyRead)
{

	char identifier[40];
	int identifierEnd;
	UInt16 * charAttrP;
	Boolean lastCharWasQuotedPrintableContinueToNextLineChr;
	char c;
	
	charAttrP = GetCharAttr();
	c = inputFunc(inputStream);

	
	do
		{		
		// Advance to the next line.  If the property wasn't handled we need to make sure that
		// if the property value contains quoted printable text that newlines within that 
		// section are skipped.
		lastCharWasQuotedPrintableContinueToNextLineChr = (c == '=');
		while (c != '\n' && !lastCharWasQuotedPrintableContinueToNextLineChr)
			{
			lastCharWasQuotedPrintableContinueToNextLineChr = (c == '=');
			c = inputFunc(inputStream);
			} 
		c = inputFunc(inputStream);
		
		
		identifierEnd = 0;
		while (IsAlpha(charAttrP, c))
			{
			identifier[identifierEnd++] = (char) c;
			c = inputFunc(inputStream);
			}
		identifier[identifierEnd++] = nullChr;
		
		// stop if at the end
		if (StrCaselessCompare(identifier, "END") == 0)
			{
			// Advance to the next line.
			while (c != '\n')
				{
				c = inputFunc(inputStream);
				} 
			
			break;
			}
		
		} while (true);
		

	return true;
}


/**********************************************************************
 * Read in a vToDo from the stream.
 ***********************************************************************/

/*static Boolean VCalReadVToDo(DmOpenRef dbP, FILE *fileIn, Boolean obeyUniqueIDs)
{
	UInt16 c = '\n';
	char identifier[40];
	int identifierEnd;
	UInt32 uid;
	UInt16 * charAttrP;

	charAttrP = GetCharAttr();
	
	uid = 0;
	
	c = GetChar(fileIn);
	
	if (c == EOF)
		return false;
		
	identifierEnd = 0;
	while (IsAlpha(charAttrP, c) || c == ':' || (c != linefeedChr && IsSpace(charAttrP, c)))
		{
		if (!IsSpace(charAttrP, c))
	 		identifier[identifierEnd++] = (char) c;
	 	
		c = GetChar(fileIn);
		}
	identifier[identifierEnd++] = nullChr;
	
	// Read in the vcard entry
	if (StrCaselessCompare(identifier, "BEGIN:VCALENDER") == 0)
		{
		do
			{
			identifierEnd = 0;
			c = GetChar(fileIn);
			while (IsAlpha(charAttrP, c) || c == ':' || (c != linefeedChr && IsSpace(charAttrP, c) ||
			      IsAlNum(charAttrP, c) || c == '.' ))
				{
				if (!IsSpace(charAttrP, c))
	 				identifier[identifierEnd++] = (char) c;
	 	
				c = GetChar(fileIn);
				}
			identifier[identifierEnd++] = nullChr;

			// Hand it off to the correct sub-routine
			// Note: here VCalEventRead is a dummt routine that just runs until it finds an end
			if (StrCaselessCompare(identifier, "BEGIN:VTODO") == 0)
				{
				ToDoImportVCal(dbP, fileIn, GetChar, false, true);
				}
			else if (StrCaselessCompare(identifier, "BEGIN:VEVENT") == 0)
				{
				VCalEventDUMMMYRead( dbP, fileIn, c);
				}
			// MemHandle the end of a calender.
			else if (StrCaselessCompare(identifier, "END:VCALENDER") == 0)
				{
				// Advance to the next line.
				while (c != '\n')
					{
					c = GetChar(fileIn);
					} 
				
				break;
				}
			
			} while (true);
		
		}


	return true;
}
*/

/**********************************************************************
 * Export the database to vCal format.
 *
 * DoToDoExportVCal <access ptr> <file out>
 ***********************************************************************/
static void DoToDoExportVCal(int argc, Char * argv[])
{

	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	char			fileOutName[64] = "\0";
	ToDoDBRecordPtr	recordP;
	MemHandle 		recordH;
	char			text[256];
	int 			index;
	int 			numOfRecords;
	int			i;


	for (i=1; i<argc; i++) {
		if (i == 1)
			sscanf(argv[i], "%lx", &dbP);
		else
		if (!*fileOutName)
			sscanf(argv[i], "%s", fileOutName);
		else
			usageErr = true;
	
		}

	if (!dbP) dbP = FindOpenedToDoDatabase();
	
	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr> <file out>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}

	FILE*	fileOut=0;
	fileOut = fopen(fileOutName, "wb");
	if (!fileOut) {
		sprintf(text, "\nCan\'t use file: %s\n", fileOutName);
		ShlInsertText(text);
		return;
		}
	
	PutString( fileOut, "BEGIN:VCALENDER\015\012");
	PutString( fileOut, "VERSION:1.0\015\012");

	numOfRecords = DmNumRecordsInCategory(dbP, dmAllCategories);
	for (index = 0; index < numOfRecords; index++) {
		recordH = (char**) DmQueryRecord( dbP, index);
		
		if ( recordH == 0)
		{
			ShlInsertText("Error!");
			break;
		}
		
		recordP = (ToDoDBRecordPtr) MemHandleLock(recordH);
		
	ToDoExportVCal(dbP, index, recordP, fileOut, PutString, true);
	

		MemHandleUnlock(recordH);
	}
	ShlInsertText("Function disabled (ABa)");
	PutString( fileOut, "END:VCALENDER\015\012");

	fclose(fileOut);
}



/**********************************************************************
 * Import from vCal format.
 *
 * DoToDoImportVCal <access ptr> <file in>
 ***********************************************************************/
static void DoToDoImportVCal(int argc, Char * argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	char	fileInName[64] = "\0";
	char	text[5000];
	int	i;


	for (i=1; i<argc; i++) {
		if (i == 1)
			sscanf(argv[i], "%lx", &dbP);
		else
		if (!*fileInName)
			sscanf(argv[i], "%s", fileInName);
		else
			usageErr = true;
	
		}

	if (!dbP) dbP = FindOpenedToDoDatabase();
	
	if (!dbP) usageErr = true;

	if (usageErr) {
		sprintf(text, "Syntax: %s <access ptr> <file in>\n", argv[0]);  
		ShlInsertText(text);
		return;
		}

	FILE*	fileIn=0;
	fileIn = fopen(fileInName, "rb");
	if (!fileIn) {
		sprintf(text, "\nUnknown input file: %s\n", fileInName);
		ShlInsertText(text);
		return;
		}
	
//	while (ToDoImportVCal(dbP, fileIn, GetChar, false, true, VCalEventDUMMMYRead))
//		{};
	
	ShlInsertText("Function disabled (ABa)");

	fclose(fileIn);
}


/**********************************************************************
 * Support for Roger's commands
 *
 * returns 0 if successfully found command
 ***********************************************************************/
int ShlDoDBCmd(int argc, Char * argv[])
{
	int i;
	ShellCmdInfoType cmd [] ={ 	
		"ToDoAppInfoInit", 		"ti",  	DoToDoSetInfoDefaults,
		"ToDoTestNewRecord",		"tnr",	DoToDoTestNewRecord,
		"ToDoGetRecord",			"tg",		DoToDoGetRecord,
		"DoToDoGetAll",			"td",		DoToDoGetAll,
		"ToDoChangeRecord",		"tc",		DoToDoChangeRecord,
		"ToDoChangeSortOrder",	"ts",		DoToDoChangeSortOrder,
		"ToDoBuildSyncDB",		"tbs",	DoToDoBuildSyncDB,
		"ToDoExportVCal",			"exvc",	DoToDoExportVCal,
		"ToDoImportVCal",			"imvc",  DoToDoImportVCal,
		};
			
	for (i = 0; i < sizeof (cmd) / sizeof (ShellCmdInfoType); i++)
		{
		if ( (!ShlStrCmpi(argv[0], cmd[i].longName)) ||
			  (!ShlStrCmpi(argv[0], cmd[i].shortName)))
			{
			cmd[i].func (argc, argv);
			return 0;
			}
		}
	return 1;
}
