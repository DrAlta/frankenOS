/******************************************************************************
 *
 * Copyright (c) 1999-2003 PalmSource, Inc. All rights reserved.
 *
 * File: PalmOptModel.h
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 *****************************************************************************/

#include <BuildDefines.h>
#ifdef MODEL
#undef MODEL
#endif
#define MODEL MODEL_GENERIC
