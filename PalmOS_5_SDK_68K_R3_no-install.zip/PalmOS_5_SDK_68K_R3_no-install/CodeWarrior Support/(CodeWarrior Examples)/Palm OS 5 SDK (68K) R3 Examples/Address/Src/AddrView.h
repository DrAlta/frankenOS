/******************************************************************************
 *
 * Copyright (c) 1995-2002 PalmSource, Inc. All rights reserved.
 *
 * File: AddrView.h
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 *****************************************************************************/

#ifndef ADDRVIEW_H
#define ADDRVIEW_H

#include <Event.h>


/************************************************************
 * Function Prototypes
 *************************************************************/

Boolean ViewHandleEvent (EventType * event);

#endif // ADDRVIEW_H
