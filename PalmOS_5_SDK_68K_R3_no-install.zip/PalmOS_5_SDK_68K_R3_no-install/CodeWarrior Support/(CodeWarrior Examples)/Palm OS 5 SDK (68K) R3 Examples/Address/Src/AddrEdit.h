/******************************************************************************
 *
 * Copyright (c) 1995-2002 PalmSource, Inc. All rights reserved.
 *
 * File: AddrEdit.h
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 *****************************************************************************/

#ifndef ADDREDIT_H
#define ADDREDIT_H

#include <Event.h>


/************************************************************
 * Function Prototypes
 *************************************************************/

Boolean	EditHandleEvent (EventType * event);
void	EditNewRecord ();

#endif // ADDREDIT_H
