/******************************************************************************
 *
 * Copyright (c) 1995-2002 PalmSource, Inc. All rights reserved.
 *
 * File: AddrCustom.h
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 *****************************************************************************/

#ifndef ADDRCUSTOM_H
#define ADDRCUSTOM_H

#include <Event.h>


/************************************************************
 * Function Prototypes
 *************************************************************/

Boolean CustomEditHandleEvent (EventType * event);

#endif // ADDRCUSTOM_H
