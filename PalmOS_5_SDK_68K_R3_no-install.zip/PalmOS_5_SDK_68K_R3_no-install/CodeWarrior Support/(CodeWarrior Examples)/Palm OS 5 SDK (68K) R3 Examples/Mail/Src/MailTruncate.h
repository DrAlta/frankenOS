/******************************************************************************
 *
 * Copyright (c) 1996-2002 PalmSource, Inc. All rights reserved.
 *
 * File: MailTruncate.h
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 * Description:
 *	  This file defines the structures and functions of the Mail HotSync 
 *   Truncation options.
 *
 *****************************************************************************/

extern Boolean TruncateHandleEvent (EventPtr event);
