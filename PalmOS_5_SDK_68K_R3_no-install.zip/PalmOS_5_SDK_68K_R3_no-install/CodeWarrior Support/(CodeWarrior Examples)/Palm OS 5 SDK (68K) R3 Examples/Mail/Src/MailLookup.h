/******************************************************************************
 *
 * Copyright (c) 1996-2002 PalmSource, Inc. All rights reserved.
 *
 * File: MailLookup.h
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 * Description:
 *	  This file defines the email address lookup structures and functions of 
 *   the mail application.
 *
 *****************************************************************************/

extern void AddressLookup (FieldPtr fld);
