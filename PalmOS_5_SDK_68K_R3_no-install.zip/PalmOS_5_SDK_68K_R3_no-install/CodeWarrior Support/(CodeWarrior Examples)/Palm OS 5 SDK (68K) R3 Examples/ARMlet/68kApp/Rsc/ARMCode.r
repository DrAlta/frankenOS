read 'ARMC' (1000, "Simple ARM code") "armlet-simple.bin";
