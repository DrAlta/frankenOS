/******************************************************************************
 *
 * Copyright (c) 1995-2002 PalmSource, Inc. All rights reserved.
 *
 * File: example_data_type.h
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 *****************************************************************************/

typedef struct {
	unsigned long number1;
	unsigned long number2;
} ExampleStructType;
