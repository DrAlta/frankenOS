/******************************************************************************
 *
 * Copyright (c) 1995-2002 PalmSource, Inc. All rights reserved.
 *
 * File: armlet-simple.c
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 * Description:
 *    This is an example of a most trivial armlet; it simply returns the 
 *    same pointer it receives.  
 *
 *    PACE byte-swaps userData68KP (but not what it points to!) so it's ready 
 *    to be dereferenced.  PACE also byte-swaps the 4-byte return value, so the 
 *    calling function receives back the same pointer it passed in.
 *
 *    The armlet entry point needs to be the first function in the file.
 *
 *****************************************************************************/

#include "PceNativeCall.h"
#ifdef WIN32
	#include "SimNative.h"
#endif


unsigned long NativeFunction(const void *emulStateP, void *userData68KP, Call68KFuncType *call68KFuncP)
{
	return (unsigned long)userData68KP;
}
