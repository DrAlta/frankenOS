/******************************************************************************
 *
 * Copyright (c) 2002 PalmSource, Inc. All rights reserved.
 *
 * File: Waves.c
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 * Description:
 *    Demonstrates the sampled sound APIs available with the Palm OS 5 release.
 *    (Some Palm OS 5 devices might not support sampled sound; check for their
 *    availibility just like this sample does.)
 *
 *    All the interesting code is in the "PlayWaveFile" and "MainFormHandleEvent"
 *    routines; the rest is the normal starter application.
 *
 *    This sample plays WAV sounds, both from a resource and from VFS files.
 *    The resource is built-in to the application (see waves.r) but you'll need
 *    to copy the WAV files to your card to fully enjoy the demo.  HostFS is
 *    supported on the Palm OS 5 Simulator, so just copy the supplied WAV files
 *    into the /PALM directory in the Card1 directory which HostFS creates inside
 *    the simulator's directory.
 *
 *    HostFS can be downloaded from http://www.palmos.com/dev/tools/emulator/
 *    The Palm OS 5 Simulator is available in the Resource Pavilion of palmos.com;
 *    login to that at http://www.palmos.com/dev/programs/pdp/login.html
 *
 *    All the interesting code is in the "PlayWaveFile" and "MainFormHandleEvent"
 *    routines; the rest is the normal starter application.
 *
 *    This sample plays WAV sounds, both from a resource and from VFS files.
 *    The resource is built-in to the application (see waves.r) but you'll need
 *    to copy the WAV files to your card to fully enjoy the demo.  HostFS is
 *    supported on the Palm OS 5 Simulator, so just copy the supplied WAV files
 *    into the /PALM directory in the Card1 directory which HostFS creates inside
 *    the simulator's directory.
 *
 *    HostFS can be downloaded from http://www.palmos.com/dev/tools/emulator/
 *    The Palm OS 5 Simulator is available in the Resource Pavilion of palmos.com;
 *    login to that at http://www.palmos.com/dev/programs/pdp/login.html
 *
 *****************************************************************************/

#include <PalmOS.h>
#include <VFSMgr.h>
#include "WavesRsc.h"
/***********************************************************************
 *
 *	Entry Points
 *
 ***********************************************************************/

/***********************************************************************
 *
 *	Internal Structures
 *
 ***********************************************************************/
typedef struct 
	{
	UInt8 replaceme;
	} WavesPreferenceType;
typedef struct 
	{
	UInt8 replaceme;
	} WavesAppInfoType;
typedef WavesAppInfoType* WavesAppInfoPtr;

/***********************************************************************
 *
 *	Global variables
 *
 ***********************************************************************/
//static Boolean HideSecretRecords;

/***********************************************************************
 *
 *	Internal Constants
 *
 ***********************************************************************/
#define appFileCreator			'WAVs'	// register your own at http://www.palmos.com/dev/creatorid/
#define appVersionNum			0x01
#define appPrefID				0x00
#define appPrefVersionNum		0x01
// Define the minimum OS version we support (5.0 for now).
#define ourMinVersion	sysMakeROMVersion(5,0,0,sysROMStageDevelopment,0)
#define kPalmOS10Version	sysMakeROMVersion(1,0,0,sysROMStageRelease,0)

/***********************************************************************
 *
 *	Internal Functions
 *
 ***********************************************************************/

/***********************************************************************
 *
 * FUNCTION:    RomVersionCompatible
 *
 * DESCRIPTION: This routine checks that a ROM version is meet your
 *              minimum requirement.
 *
 * PARAMETERS:  requiredVersion - minimum rom version required
 *                                (see sysFtrNumROMVersion in SystemMgr.h 
 *                                for format)
 *              launchFlags     - flags that indicate if the application 
 *                                UI is initialized.
 *
 * RETURNED:    error code or zero if rom is compatible
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Err RomVersionCompatible(UInt32 requiredVersion, UInt16 launchFlags)
{
	UInt32 romVersion;
	// See if we're on in minimum required version of the ROM or later.
	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
	if (romVersion < requiredVersion)
		{
		if ((launchFlags & (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
			(sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
			{
			FrmAlert (RomIncompatibleAlert);
		
			// Palm OS 1.0 will continuously relaunch this app unless we switch to 
			// another safe one.
			if (romVersion <= kPalmOS10Version)
				{
				AppLaunchWithCommand(sysFileCDefaultApp, sysAppLaunchCmdNormalLaunch, NULL);
				}
			}
		
		return sysErrRomIncompatible;
		}

	return errNone;
}


/***********************************************************************
 *
 * FUNCTION:    GetObjectPtr
 *
 * DESCRIPTION: This routine returns a pointer to an object in the current
 *              form.
 *
 * PARAMETERS:  formId - id of the form to display
 *
 * RETURNED:    void *
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void * GetObjectPtr(UInt16 objectID)
{
	FormPtr frmP;

	frmP = FrmGetActiveForm();
	return FrmGetObjectPtr(frmP, FrmGetObjectIndex(frmP, objectID));
}


/***********************************************************************
 *
 * FUNCTION:    MainFormInit
 *
 * DESCRIPTION: This routine initializes the MainForm form.
 *
 * PARAMETERS:  frm - pointer to the MainForm form.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void MainFormInit(FormPtr /*frmP*/)
{
}


/***********************************************************************
 *
 * FUNCTION:    MainFormDoCommand
 *
 * DESCRIPTION: This routine performs the menu command specified.
 *
 * PARAMETERS:  command  - menu item id
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean MainFormDoCommand(UInt16 command)
{
	Boolean handled = false;
	FormPtr frmP;

	switch (command)
		{
		case MainOptionsAboutWaves:
			MenuEraseStatus(0);					// Clear the menu status from the display.
			frmP = FrmInitForm (AboutForm);
			FrmDoDialog (frmP);					// Display the About Box.
			FrmDeleteForm (frmP);
			handled = true;
			break;

		}
	
	return handled;
}

/***********************************************************************
 *
 * FUNCTION:    PlayWaveFile
 *
 * DESCRIPTION: Finds a WAV file on any mounted VFS volume, reads it in
 *              to memory (entirely) and plays it.
 *
 * PARAMETERS:  fileName - full path to the WAV file e.g. "/Palm/Test.wav"
 *
 * RETURNED:    0 for success, otherwise an int showing where it failed.
 *
 ***********************************************************************/
static int PlayWaveFile(char *fileName)
{
	MemPtr ptr;
	Err err;
	FileRef fileRef=0;
	UInt32 vfsMgrVersion;
	UInt16 volRefNum;
	UInt32 volIterator;
	UInt32 fileSize;

	// is the VFS manager present?
	err = FtrGet(sysFileCVFSMgr, vfsFtrIDVersion, &vfsMgrVersion);
	if (err != errNone) return 1;

	// are the sampled sound APIs available?
	// (commented out for now because as of dr9 the feature wasn't yet published.)
	//err = FtrGet(sysFileCSoundMgr, vfsFtrIDVersion, &vfsMgrVersion);
	//if (err != errNone) return 1;

	// Until the sampled sound feature exists, check the trap address instead.
	if (SysGetTrapAddress(sysTrapSndPlayResource) == SysGetTrapAddress(sysTrapSysUnimplemented))
		return 1;

	// Look for the named file on all mounted volumes (cards, hostfs, RAMdisk, etc.)
	// Your application might want to pass in the volRefNum because presumably you know
	// it, and don't want to pick a file with that name from any random mounted volume...
	volIterator = vfsIteratorStart;
	do {
		err = VFSVolumeEnumerate(&volRefNum, &volIterator);
		if (err) 
			return 2;  // no more volumes to look at; file not found.
		err = VFSFileOpen(volRefNum, fileName, vfsModeRead, &fileRef);
	} while (err);

	// found the file; how big is it?
	err = VFSFileSize(fileRef, &fileSize);
	if (err != errNone) {
		VFSFileClose(fileRef);
		return 4;
	}

	// It would be better to use the streaming API instead of reading the whole file in as
	// a huge block, because this way we require that potentially a lot of memory be available.
	// Unfortunately, the streaming API only supports uncompressed sound, not WAVs, and some of 
	// my demo WAVs are compressed, so streaming WAVs is left as an exercise for the reader.
	FtrPtrNew(appFileCreator, 0, fileSize, &ptr);
	if (!ptr) {
		VFSFileClose(fileRef);
		return 5;
	}

	// we have memory; read in the contents of the file into memory.	
	err = VFSFileReadData(fileRef, fileSize, ptr, 0, &fileSize);
	VFSFileClose(fileRef);
	if (err != errNone) {
		FtrPtrFree(appFileCreator, 0);
		return 6;
	}

	// play it and clean up!
	err = SndPlayResource(ptr, sndGameVolume, sndFlagSync);  // must use sync because we're going to free the buffer right away
	if (err == sndErrInvalidStream) err=errNone;  // don't know why I sometimes get this in dr8...
	FtrPtrFree(appFileCreator, 0);
	if (err != errNone) return 7;
	
	return 0;
}


/***********************************************************************
 *
 * FUNCTION:    MainFormHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the 
 *              "MainForm" of this application.
 *
 * PARAMETERS:  eventP  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean MainFormHandleEvent(EventPtr eventP)
{
	Boolean handled = false;
	FormPtr frmP;
	int status;

	switch (eventP->eType) 
		{
		case menuEvent:
			return MainFormDoCommand(eventP->data.menu.itemID);

		case frmOpenEvent:
			frmP = FrmGetActiveForm();
			MainFormInit( frmP);
			FrmDrawForm ( frmP);
			handled = true;
			break;
			
		case frmUpdateEvent:
			// To do any custom drawing here, first call FrmDrawForm(), then do your
			// drawing, and then set handled to true.
			break;
		
		case ctlSelectEvent:
			if (eventP->data.ctlSelect.controlID == MainPlayResourceButton) {
				// playing a sound from a resource is really easy.
				MemHandle h;
				h = DmGetResource('wave', 1000);  // find the resource in this PRC (added in the .r file)
				if (h) {
					// play it at the standard volume for game sounds, synchronously.
					SndPlayResource(MemHandleLock(h), sndGameVolume, sndFlagSync);
					MemHandleUnlock(h);
				}
			}
			else if (eventP->data.ctlSelect.controlID == MainPlayVFSButton) {
				status = PlayWaveFile("/Palm/ChopinChordUn.wav");
				if (status) { // did an error occur?  Go for the El Cheapo status display.
					WinDrawChar('1'+status-1, 2, 150);
					SysTaskDelay(150);
					FrmDrawForm(FrmGetActiveForm());
				}
			}
			else if (eventP->data.ctlSelect.controlID == MainPlayVFS2Button) {
				status = PlayWaveFile("/Palm/Walkin_The_Dog.wav");
				if (status) { // did an error occur?  Go for the El Cheapo status display.
					WinDrawChar('1'+status-1, 2, 150);
					SysTaskDelay(150);
					FrmDrawForm(FrmGetActiveForm());
				}
			}
			handled=true;
			break;

		default:
			break;
		
		}
	
	return handled;
}


/***********************************************************************
 *
 * FUNCTION:    AppHandleEvent
 *
 * DESCRIPTION: This routine loads form resources and set the event
 *              handler for the form loaded.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean AppHandleEvent(EventPtr eventP)
{
	UInt16 formId;
	FormPtr frmP;

	if (eventP->eType == frmLoadEvent)
		{
		// Load the form resource.
		formId = eventP->data.frmLoad.formID;
		frmP = FrmInitForm(formId);
		FrmSetActiveForm(frmP);

		// Set the event handler for the form.  The handler of the currently
		// active form is called by FrmHandleEvent each time is receives an
		// event.
		switch (formId)
			{
			case MainForm:
				FrmSetEventHandler(frmP, MainFormHandleEvent);
				break;

			default:
//				ErrFatalDisplay("Invalid Form Load Event");
				break;

			}
		return true;
		}
	
	return false;
}


/***********************************************************************
 *
 * FUNCTION:    AppEventLoop
 *
 * DESCRIPTION: This routine is the event loop for the application.  
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void AppEventLoop(void)
{
	UInt16 error;
	EventType event;

	do {
		EvtGetEvent(&event, evtWaitForever);

		if (! SysHandleEvent(&event))
			if (! MenuHandleEvent(0, &event, &error))
				if (! AppHandleEvent(&event))
					FrmDispatchEvent(&event);

	} while (event.eType != appStopEvent);
}


/***********************************************************************
 *
 * FUNCTION:     AppStart
 *
 * DESCRIPTION:  Get the current application's preferences.
 *
 * PARAMETERS:   nothing
 *
 * RETURNED:     Err value 0 if nothing went wrong
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Err AppStart(void)
{
	WavesPreferenceType prefs;
	UInt16 prefsSize;

	// Read the saved preferences / saved-state information.
	prefsSize = sizeof(WavesPreferenceType);
	if (PrefGetAppPreferences(appFileCreator, appPrefID, &prefs, &prefsSize, true) != 
		noPreferenceFound)
		{
		}
	
	return errNone;
}


/***********************************************************************
 *
 * FUNCTION:    AppStop
 *
 * DESCRIPTION: Save the current state of the application.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void AppStop(void)
{
	WavesPreferenceType prefs;

	// Write the saved preferences / saved-state information.  This data 
	// will saved during a HotSync backup.
	PrefSetAppPreferences (appFileCreator, appPrefID, appPrefVersionNum, 
		&prefs, sizeof (prefs), true);
		
	// Close all the open forms.
	FrmCloseAllForms ();
}


/***********************************************************************
 *
 * FUNCTION:    WavesPalmMain
 *
 * DESCRIPTION: This is the main entry point for the application.
 *
 * PARAMETERS:  cmd - word value specifying the launch code. 
 *              cmdPB - pointer to a structure that is associated with the launch code. 
 *              launchFlags -  word value providing extra information about the launch.
 *
 * RETURNED:    Result of launch
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static UInt32 WavesPalmMain(UInt16 cmd, MemPtr /*cmdPBP*/, UInt16 launchFlags)
{
	Err error;

	error = RomVersionCompatible (ourMinVersion, launchFlags);
	if (error) return (error);

	switch (cmd)
		{
		case sysAppLaunchCmdNormalLaunch:
			error = AppStart();
			if (error) 
				return error;
				
			FrmGotoForm(MainForm);
			AppEventLoop();
			AppStop();
			break;

		default:
			break;

		}
	
	return errNone;
}


/***********************************************************************
 *
 * FUNCTION:    PilotMain
 *
 * DESCRIPTION: This is the main entry point for the application.
 *
 * PARAMETERS:  cmd - word value specifying the launch code. 
 *              cmdPB - pointer to a structure that is associated with the launch code. 
 *              launchFlags -  word value providing extra information about the launch.
 * RETURNED:    Result of launch
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
UInt32 PilotMain( UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
	return WavesPalmMain(cmd, cmdPBP, launchFlags);
}
