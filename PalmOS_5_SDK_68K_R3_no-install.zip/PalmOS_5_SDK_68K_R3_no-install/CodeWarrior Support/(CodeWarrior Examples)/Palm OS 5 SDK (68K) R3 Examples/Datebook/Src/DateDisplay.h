/******************************************************************************
 *
 * Copyright (c) 1995-2002 PalmSource, Inc. All rights reserved.
 *
 * File: DateDisplay.h
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 * Description:
 *	  This file defines the display options functions.
 *
 *****************************************************************************/

extern Boolean DisplayOptionsHandleEvent (EventType * event);
