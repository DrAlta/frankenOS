/******************************************************************************
 *
 * Copyright (c) 1995-2002 PalmSource, Inc. All rights reserved.
 *
 * File: DatePref.h
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 * Description:
 *	  This file defines the preference functions.
 *
 *****************************************************************************/

extern Boolean PreferencesHandleEvent (EventType * event);
