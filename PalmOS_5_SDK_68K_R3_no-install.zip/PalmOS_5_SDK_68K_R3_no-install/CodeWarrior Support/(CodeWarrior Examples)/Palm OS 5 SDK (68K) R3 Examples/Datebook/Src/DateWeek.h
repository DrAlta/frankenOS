/******************************************************************************
 *
 * Copyright (c) 1995-2002 PalmSource, Inc. All rights reserved.
 *
 * File: DateWeek.h
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 * Description:
 *	  This file defines the Datebook's Week View functions.
 *
 *****************************************************************************/

extern Boolean WeekViewHandleEvent (EventType * event);
