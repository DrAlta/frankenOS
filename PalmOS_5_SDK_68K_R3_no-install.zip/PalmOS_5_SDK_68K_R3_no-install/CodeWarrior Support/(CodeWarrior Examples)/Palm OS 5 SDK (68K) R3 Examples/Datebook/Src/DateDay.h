/******************************************************************************
 *
 * Copyright (c) 1995-2002 PalmSource, Inc. All rights reserved.
 *
 * File: DateDay.h
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 * Description:
 *	  This file defines the Datebook's Main modual's functions anf globals.
 *
 *****************************************************************************/

#include <Event.h>

Boolean RepeatHandleEvent (EventType* event);
Boolean DetailsHandleEvent (EventType* event);
Boolean NoteViewHandleEvent (EventType* event);
Boolean DayViewHandleEvent (EventType* event);
