/******************************************************************************
 *
 * Copyright (c) 1995-2003 PalmSource, Inc. All rights reserved.
 *
 * File: DateLunar.c
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 * Description:
 *	  This file contains the (temporary) lunar calendar support for the
 *	Datebook application.  These routines will be part of Time Manager 6.0.
 *
 *****************************************************************************/

#include <PalmTypes.h>

#include <Chars.h>
#include <DateTime.h>
#include <DataMgr.h>						// For DmGetResource
#include <ErrorMgr.h>
#include <MemoryMgr.h>					// For memErrInvalidParam
#include <StringMgr.h>					// For StrNCopy, StrIToA, etc
#include <TextMgr.h>						// For TxtReplaceStr
#include <SysUtils.h>					// For SysStringByIndex
#include "UIResources.h"				// For strListRscType

#include "DateLunar.h"

/* Drop this in here so that the table processing code can be more easily
ported to Sahara.
*/
#ifndef BUS_ALIGN
	#define  BUS_ALIGN_16       	16     // 16-bit data must be read/written at 16-bit address
	#define  BUS_ALIGN_32			32     // 32-bit data must be read/written at 32-bit address
	#define BUS_ALIGN BUS_ALIGN_16
#endif

/***********************************************************************
 * Private constants
 **********************************************************************/

/* Resource types and IDs
*/
#define kLunarCalendarSupportedID			10200
#define kMiscStrListID							10208
#define kLunarStemsStrListID					10209
#define kLunarBranchesStrListID				10210
#define kLunarAnimalsStrListID				10211
#define kLunarMonthsStrListID					10212
#define kLunarDaysStrListID					10213
#define kLunarCalendarRscType					'luca'	// Lunar calendar data
#define kChineseLunarCalendarID				19000		// Chinese lunar calendar data

/* Max length of any date template string (before expansion), excluding the null.
*/
#define				maxDateTemplateLen					31	

const
UInt16				kLunarCalendarDataVersion			= 1;

/* Maximum substring lengths for building Chinese lunar date string
*/
#define				kMaxLunarStemStrLen					15
#define				kMaxLunarBranchStrLen				15
#define				kMaxLunarAnimalStrLen				15
#define				kMaxLunarMonthStrLen					15
#define				kMaxLunarDayStrLen					15
#define				kMaxLunarLeapMonthStrLen			15

/* Miscellaneous string list resource (kMiscStrListID) indexes
*/
const
UInt16				kLunarTemplateMiscStrListIndex	= 0;
const
UInt16				kLunarLeapMonthMiscStrListIndex	= 1;

/* Substring parameter indexes for building Chinese lunar date string
*/
const
UInt16				kLunarStemParamIndex					= 0;
const
UInt16				kLunarBranchParamIndex				= 1;
const
UInt16				kLunarAnimalParamIndex				= 2;
const
UInt16				kLunarMonthParamIndex				= 3;
const
UInt16				kLunarDayParamIndex					= 4;
const
UInt16				kLunarLeapMonthParamIndex			= 5;

/***********************************************************************
 * Private macros
 ***********************************************************************/

/* Convert <inputValue> from 68K format to ARM format (or vice-versa)
and put the result in <outputValue>.

WARNING!	The <inputValue> and <outputValue> arguments are evaluated more
			than once, and cannot refer to the same area of memory.
*/
#define	SwapBytes_(inputValue, outputValue)												\
				switch (sizeof(outputValue)) {												\
					case 1:																			\
						outputValue = inputValue;												\
					break;																			\
					case 2:																			\
						((UInt8*)&outputValue)[0] = ((UInt8*)(&inputValue))[1];		\
						((UInt8*)&outputValue)[1] = ((UInt8*)(&inputValue))[0];		\
					break;																			\
					case 4:																			\
						((UInt8*)&outputValue)[0] = ((UInt8*)(&inputValue))[3];		\
						((UInt8*)&outputValue)[1] = ((UInt8*)(&inputValue))[2];		\
						((UInt8*)&outputValue)[2] = ((UInt8*)(&inputValue))[1];		\
						((UInt8*)&outputValue)[3] = ((UInt8*)(&inputValue))[0];		\
					break;																			\
				}

/***********************************************************************
 * Private types
 **********************************************************************/

/* Description of a single month in the Chinese lunar calendar 
*/
typedef struct _LunarMonthType LunarMonthType;
struct _LunarMonthType {
	UInt8		monthNumber;		// 1..13 (0 if unused)
	UInt8		daysInThisMonth;	// 29..30 (0 if unused)
};

/* Description of a single year in the Chinese solar/lunar calendar
*/
typedef struct _LunarYearType LunarYearType;
struct _LunarYearType {
	Int32					yearStartDay;		// Offset from 1904-1-1, -337..46409 (1903-1-29..2031-1-23)
	LunarMonthType		lunarMonths[timMaxChineseLunarMonths];		// Month info array (last might not be used)
};

/* Database of lunar calendar information

The complete database is (2+4+(13*2))*128=4096 bytes.
*/
typedef struct _LunarCalendarDataType LunarCalendarDataType;
struct _LunarCalendarDataType {
	UInt16				version;
	UInt16				lunarYearOfYearIndex0;	// Position of lunarYear[0] in sexigesimal cycle 1..60
	UInt16				numKnownYears;		// # elements in lunarYears
	LunarYearType		lunarYears[1];		// Variable length record
};

/***********************************************************************
 * Private forward declarations
 ***********************************************************************/

static LunarCalendarDataType*
PrvGetLunarCalendarP(void);

static UInt16
PrvFindLunarYearIndex(
	const
	LunarCalendarDataType*	iLunarCalendarDataP,
	Int32					iDayCount);

static Char*
PrvStringByIndex(
	UInt16				iStringListID,
	UInt16				iStringIndex,
	Char*					oResultStr,
	UInt16				iMaxSize);

/***********************************************************************
 * Private global variables
 ***********************************************************************/

static
LunarCalendarDataType*	pLunarCalendarP = NULL;


/***********************************************************************/
Boolean
DateSupportsLunarCalendar(void)
/*
Return true if the system locale supports the Chinese lunar calendar.
*/
{
	Boolean				systemSupportsLunarCalendar
								= (Boolean)ResLoadConstant(kLunarCalendarSupportedID);

	return(systemSupportsLunarCalendar);

} // DateSupportsLunarCalendar

  
/***********************************************************************/
Err
DateSecondsToLunarDate(
	UInt32				iSeconds,
	UInt16*				oLunarYear,
	UInt16*				oLunarMonth,
	UInt16*				oLunarDay,
	Boolean*				oIsLeapMonth)
/*
Convert <iSeconds> (since 1/1/1904) to the Chinese *<oLunarYear>,
*<oLunarMonth> and *<oLunarDay>.  Set *<oIsLeapMonth> to true if this is
the second month in this year with *<oLunarMonth>.
*/
{
	LunarCalendarDataType*	chineseLunarCalendarP = NULL;
	Int32					dayCount;
	LunarYearType*		lunarYearP = NULL;
	UInt16				lunarYearIndex;
	UInt16				lunarMonthIndex;
	Int32					yearStartDay;
	UInt16				lunarYearOfYearIndex0;

	/* Initialize our outputs in case we're unsuccessful.
	*/
	*oLunarYear = 1;
	*oLunarMonth = 1;
	*oLunarDay = 1;
	*oIsLeapMonth = false;

	if (!DateSupportsLunarCalendar())
		return(timErrNoLunarCalendarSupport);

	/* Convert the input seconds to days since 1904
	*/
	dayCount = iSeconds / daysInSeconds;

	/* Grab the lunar calendar resource
	*/
	chineseLunarCalendarP = PrvGetLunarCalendarP();
	if (!chineseLunarCalendarP) {
		ErrNonFatalDisplay("Unable to load lunar calendar data resource.");
		return(timErrNoLunarCalendarSupport);
	}

	/* Find the year record that corresponds to this date, and calculate its
	position in the sexigesimal cycle.
	*/
#if BUS_ALIGN == BUS_ALIGN_32
	lunarYearOfYearIndex0 = chineseLunarCalendarP->lunarYearOfYearIndex0;
#else
	SwapBytes_(chineseLunarCalendarP->lunarYearOfYearIndex0, lunarYearOfYearIndex0);
#endif
	lunarYearIndex = PrvFindLunarYearIndex(chineseLunarCalendarP, dayCount);
	lunarYearP =	(	chineseLunarCalendarP->lunarYears
						+	lunarYearIndex);
	*oLunarYear =	(	(	(	lunarYearIndex
								+	lunarYearOfYearIndex0
								-	timFirstChineseLunarYear)
							%	(	timLastChineseLunarYear
								-	timFirstChineseLunarYear
								+	1))
						+	timFirstChineseLunarYear);

	/* We now know the year, and can calculate day number within it.
	*/
#if BUS_ALIGN == BUS_ALIGN_32
	yearStartDay = lunarYearP->yearStartDay;
#else
	SwapBytes_(lunarYearP->yearStartDay, yearStartDay);
#endif
	*oLunarDay = (UInt16)(dayCount - yearStartDay);

	/* Search for the correct lunar month, and calculate the lunar day.
	*/
	for (	lunarMonthIndex = 0;
			*oLunarDay >= lunarYearP->lunarMonths[lunarMonthIndex].daysInThisMonth;
			lunarMonthIndex++) {
		if (	(lunarMonthIndex >= timMaxChineseLunarMonths)
			||	(lunarYearP->lunarMonths[lunarMonthIndex].monthNumber == 0)
			||	(lunarYearP->lunarMonths[lunarMonthIndex].daysInThisMonth == 0)) {
			ErrNonFatalDisplay("Unable to find correct lunar month in lunar year.");
			return(timErrNoLunarCalendarSupport);
		}
		(*oLunarDay) -= lunarYearP->lunarMonths[lunarMonthIndex].daysInThisMonth;
	}
	(*oLunarDay)++;	// First day in month is returned as 1 (not 0)

	/* Return its month number and whether it's a leap month
	*/
	*oLunarMonth = lunarYearP->lunarMonths[lunarMonthIndex].monthNumber;
	*oIsLeapMonth =	(	(lunarMonthIndex > 0)
							&&	(	lunarYearP->lunarMonths[lunarMonthIndex-1].monthNumber
								==	lunarYearP->lunarMonths[lunarMonthIndex].monthNumber));

	return(errNone);

} // DateSecondsToLunarDate


/***********************************************************************/
Err
DateToLunarStr(
	UInt16				iLunarYear,
	UInt16				iLunarMonth,
	UInt16				iLunarDay,
	Boolean				iIsLeapMonth,
	Char*					oLunarDateStr,
	UInt16				iMaxStrLen)
/*
Convert the Chinese <iLunarYear>, <iLunarMonth>, <iLunarDay> and
<iIsLeapMonth> into a Chinese string describing this lunar date,
and place the result in *<oLunarDateStr>, which can hold <iMaxStrLen>
bytes (excluding the null).  timOmitLunarYear, timOmitLunarMonth,
and timOmitLunarDay may be passed in <iLunarYear>, <iLunarMonth> and
<iLunarDay> (respectively) in order to omit these portions of the string.

History:
2002-10-23	CS		Added support for timOmitLunarYear, timOmitLunarMonth,
						and timOmitLunarDay.
2003-01-17	CS		Build output in separate buffer in case caller's
						isn't long enough for temporary results (i.e., caller
						is omitting one or more fields, but we haven't yet
						removed the replacement tokens from the template).
*/
{
	Char					stemStr[kMaxLunarStemStrLen+1];
	Char					branchStr[kMaxLunarBranchStrLen+1];
	Char					animalStr[kMaxLunarAnimalStrLen+1];
	Char					monthStr[kMaxLunarMonthStrLen+1];
	Char					dayStr[kMaxLunarDayStrLen+1];
	Char					leapMonthStr[kMaxLunarLeapMonthStrLen+1];
	Char					lunarDateStr[timMaxLunarDateStrLen+1];

	stemStr[0] = 0;
	branchStr[0] = 0;
	animalStr[0] = 0;
	monthStr[0] = 0;
	dayStr[0] = 0;
	leapMonthStr[0] = 0;

	if (!DateSupportsLunarCalendar())
		return(timErrNoLunarCalendarSupport);
		
	/* Load the template string and then jam it with the year stem & branch,
	animal, month, optional leap month text, and day.
	*/
	PrvStringByIndex(	kMiscStrListID,
							kLunarTemplateMiscStrListIndex,
							lunarDateStr,
							timMaxLunarDateStrLen+1);
	if (StrLen(lunarDateStr) == 0) {
		ErrNonFatalDisplay("Unable to load lunar date template.");
		return(timErrNoLunarCalendarSupport);
	}

	if (iLunarYear != timOmitLunarYear) {
		PrvStringByIndex(	kLunarStemsStrListID,
								(UInt16)	(	(iLunarYear-timFirstChineseLunarYear)
											%	timNumChineseStems),
								stemStr,
								kMaxLunarStemStrLen+1);
		if (StrLen(stemStr) == 0) {
			ErrNonFatalDisplay("Unable to load lunar stem string.");
			return(timErrNoLunarCalendarSupport);
		}

		PrvStringByIndex(	kLunarBranchesStrListID,
								(UInt16)	(	(iLunarYear-timFirstChineseLunarYear)
											%	timNumChineseBranches),
								branchStr,
								kMaxLunarBranchStrLen+1);
		if (StrLen(branchStr) == 0) {
			ErrNonFatalDisplay("Unable to load lunar branch string.");
			return(timErrNoLunarCalendarSupport);
		}

		PrvStringByIndex(	kLunarAnimalsStrListID,
								(UInt16)	(	(iLunarYear-timFirstChineseLunarYear)
											%	timNumChineseBranches),
								animalStr,
								kMaxLunarAnimalStrLen+1);
		if (StrLen(animalStr) == 0) {
			ErrNonFatalDisplay("Unable to load lunar year animal string.");
			return(timErrNoLunarCalendarSupport);
		}
	}
	TxtReplaceStr(	lunarDateStr,
						timMaxLunarDateStrLen,
						stemStr,
						kLunarStemParamIndex);
	TxtReplaceStr(	lunarDateStr,
						timMaxLunarDateStrLen,
						branchStr,
						kLunarBranchParamIndex);
	TxtReplaceStr(	lunarDateStr,
						timMaxLunarDateStrLen,
						animalStr,
						kLunarAnimalParamIndex);

	if (iLunarMonth != timOmitLunarMonth) {
		PrvStringByIndex(	kLunarMonthsStrListID,
								(UInt16)(iLunarMonth-timFirstChineseLunarMonth),
								monthStr,
								kMaxLunarMonthStrLen+1);
		if (StrLen(monthStr) == 0) {
			ErrNonFatalDisplay("Unable to load lunar month string.");
			return(timErrNoLunarCalendarSupport);
		}
	}
	TxtReplaceStr(	lunarDateStr,
						timMaxLunarDateStrLen,
						monthStr,
						kLunarMonthParamIndex);

	if (iLunarDay != timOmitLunarDay) {
		PrvStringByIndex(	kLunarDaysStrListID,
								(UInt16)(iLunarDay-timFirstChineseLunarDay),
								dayStr,
								kMaxLunarDayStrLen+1);
		if (StrLen(dayStr) == 0) {
			ErrNonFatalDisplay("Unable to load lunar day string.");
			return(timErrNoLunarCalendarSupport);
		}
	}
	TxtReplaceStr(	lunarDateStr,
						timMaxLunarDateStrLen,
						dayStr,
						kLunarDayParamIndex);

	if	(	(iLunarMonth != timOmitLunarMonth)
		&&	(iIsLeapMonth)) {
		PrvStringByIndex(	kMiscStrListID,
								kLunarLeapMonthMiscStrListIndex,
								leapMonthStr,
								kMaxLunarLeapMonthStrLen+1);
		if (StrLen(leapMonthStr) == 0) {
			ErrNonFatalDisplay("Unable to load lunar leap month string.");
			return(timErrNoLunarCalendarSupport);
		}
	}
	TxtReplaceStr(	lunarDateStr,
						timMaxLunarDateStrLen,
						leapMonthStr,
						kLunarLeapMonthParamIndex);
						
	/* Now that we've built the result, copy it to the caller's buffer.
	
	DOLATER CS - Return an error if result doesn't fit?
	*/
	if (StrLen(lunarDateStr) <= iMaxStrLen) {
		StrCopy(oLunarDateStr, lunarDateStr);
	} else {
		UInt16	truncatedLen = TxtGetTruncationOffset(lunarDateStr, iMaxStrLen);
		
		MemMove(	oLunarDateStr,
					lunarDateStr,
					truncatedLen);
		oLunarDateStr[truncatedLen] = chrNull;
		ErrNonFatalDisplay("Lunar date string overflows buffer.");
	}

	return(errNone);

} // DateToLunarStr


/***********************************************************************/
Boolean
SelectLunarDayIsSupported(void)
/*
Return true if there is a Chinese lunar calendar application installed
(used by the DateBook application).
*/
{
	// DOLATER CS -	Implement this routine.

	return(false);

} // SelectLunarDayIsSupported


/***********************************************************************/
void
TerminateDateLunar(void)
/*
Temporary routine to unlock resources used by the lunar calendar support
code, etc.
*/
{
	if (pLunarCalendarP) {
		MemPtrUnlock(pLunarCalendarP);
	}
	pLunarCalendarP = NULL;
	
} // TerminateDateLunar


/***********************************************************************/
static LunarCalendarDataType*
PrvGetLunarCalendarP(void)
/*
Return a pointer to the locked lunar calendar data resource.
*/
{
	if (!pLunarCalendarP) {
		MemHandle			lunarCalendarH = NULL;
		UInt16				version;
	
		lunarCalendarH = DmGetResource(	kLunarCalendarRscType,
													kChineseLunarCalendarID);
		if (lunarCalendarH) {
			pLunarCalendarP = MemHandleLock(lunarCalendarH);
#if BUS_ALIGN == BUS_ALIGN_32
			version = pLunarCalendarP->version;
#else
			SwapBytes_(pLunarCalendarP->version, version);
#endif
			if (version != kLunarCalendarDataVersion) {
				return(NULL);
			}
		}
	}
	return(pLunarCalendarP);
	
} // PrvGetLunarCalendarP


/***********************************************************************/
static UInt16
PrvFindLunarYearIndex(
	const
	LunarCalendarDataType*	iLunarCalendarDataP,
	Int32					iDayCount)
/*
Return the index into <iLunarCalendarDataP>->lunarYears of the lunar year
in which <iDayCount> (since 1904-1-1) appears, where *<iLunarCalendarDataP>
contains a description of all supported lunar years.

DOLATER CS -	Do the bsearch thing here.
*/
{
	UInt16				lunarYearIndex;
	UInt16				numKnownYears;

#if BUS_ALIGN == BUS_ALIGN_32
			numKnownYears = pLunarCalendarP->numKnownYears;
#else
			SwapBytes_(pLunarCalendarP->numKnownYears, numKnownYears);
#endif
	for (	lunarYearIndex = numKnownYears-1;
			lunarYearIndex >= 0;
			lunarYearIndex--) {
		Int32					yearStartDay;
		
#if BUS_ALIGN == BUS_ALIGN_32
		yearStartDay
			= iLunarCalendarDataP->lunarYears[lunarYearIndex].yearStartDay;
#else
		SwapBytes_(	iLunarCalendarDataP->lunarYears[lunarYearIndex].yearStartDay,
						yearStartDay);
#endif
		if	(iDayCount >= yearStartDay) {
		
			/* If date is beyond beginning of last year in data, then we need to
			make sure it's not beyond the end of the last year.
			*/
			if (lunarYearIndex == (numKnownYears-1)) {
				UInt16				monthIndex;
				UInt16				daysInLastYear = 0;
				
				for (	monthIndex = 0;
						monthIndex < timMaxChineseLunarMonths;
						monthIndex++) {
					daysInLastYear += iLunarCalendarDataP->lunarYears[lunarYearIndex].lunarMonths[monthIndex].daysInThisMonth;
				}
				
				if (iDayCount >= (yearStartDay + daysInLastYear)) {
					break;
				}
			}
			return(lunarYearIndex);
		}
	}
	ErrNonFatalDisplay("Unable to find lunar year for input date.");
	return(0);

} // PrvFindLunarYearIndex


/***********************************************************************/
static Char*
PrvStringByIndex(
	UInt16				iStringListID,
	UInt16				iStringIndex,
	Char*					oResultStr,
	UInt16				iMaxSize)
/*
Place the <iStringIndex>th string from the tSTL resource <stringListID>
(including the prefix string) into <oResultStr>, and return the result.
Copy at most <iMaxSize> bytes of it (including the chrNull).
*/
{
	return(SysStringByIndex(iStringListID, iStringIndex, oResultStr, iMaxSize));

} // PrvStringByIndex
