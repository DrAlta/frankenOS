/******************************************************************************
 *
 * Copyright (c) 1995-2003 PalmSource, Inc. All rights reserved.
 *
 * File: DateLunar.h
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 * Description:
 *	  This file declares the (temporary) lunar calendar support for the
 *	Datebook application.  These declarations will be part of Time Manager 6.0.
 *
 *****************************************************************************/

#ifndef __DATELUNAR_H__
#define __DATELUNAR_H__

#define timErrNoLunarCalendarSupport		(timErrorClass | 2)

/************************************************************
 * Date Time Constants
 *************************************************************/

/* Chinese lunar years, months, and days are 1-based
*/
#define timFirstChineseLunarYear		1
#define timLastChineseLunarYear			60	// Sexigesimal (60-year cycle)
#define timNumChineseStems				10	// Celestial stems in sexigesmial cycle
#define timNumChineseBranches			12	// Terrestrial branches in sexigesmial cycle
#define timFirstChineseLunarMonth		1
#define timMaxChineseLunarMonths		13	// Can be either 12 or 13
#define timFirstChineseLunarDay			1
#define timNewMoonChineseLunarDay		timFirstChineseLunarDay
#define timFullMoonChineseLunarDay		15

/* Pass these to DateToLunarStr to omit portions of output
*/
#define timOmitLunarDay					0
#define timOmitLunarMonth				0
#define timOmitLunarYear				0

/* 17 is the longest possible Chinese date string, but note that this is longer
than longDateStrLength (15).  Note also that the latter, (unlike our constants)
includes space for the chrNull.
*/
#define timMaxLunarDateStrLen			31

//************************************************************
//* Date Time procedures
//************************************************************
#ifdef __cplusplus
extern "C" {
#endif

/* Return true if the system locale supports the Chinese lunar calendar.
*/
Boolean
DateSupportsLunarCalendar(void);

/* Convert <iSeconds> (since 1/1/1904) to the Chinese *<oLunarYear>,
*<oLunarMonth> and *<oLunarDay>.  Set *<oIsLeapMonth> to true if this is
the second month in this year with *<oLunarMonth>.
*/
Err
DateSecondsToLunarDate(
	UInt32				iSeconds,
	UInt16*				oLunarYear,
	UInt16*				oLunarMonth,
	UInt16*				oLunarDay,
	Boolean*			oIsLeapMonth);

/* Convert the Chinese <iLunarYear>, <iLunarMonth>, <iLunarDay> and
<iIsLeapMonth> into a Chinese string describing this lunar date,
and place the result in *<oLunarDateStr>, which can hold <iMaxStrLen>
bytes (excluding the null).
*/
Err
DateToLunarStr(
	UInt16				iLunarYear,
	UInt16				iLunarMonth,
	UInt16				iLunarDay,
	Boolean				iMonthIsRepeat,
	Char*				oLunarDateStr,
	UInt16				iMaxStrLen);

/* Return true if there is a Chinese lunar calendar application installed
(used by the DateBook application).
*/
Boolean
SelectLunarDayIsSupported(void);

/* Temporary routine to unlock resources used by the lunar calendar support
code, etc.
*/
void
TerminateDateLunar(void);

#ifdef __cplusplus 
}
#endif


#endif //__DATELUNAR_H__
