/******************************************************************************
 *
 * Copyright (c) 1995-2003 PalmSource, Inc. All rights reserved.
 *
 * File: AddrView.h
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 *****************************************************************************/

#ifndef ADDRVIEW_H
#define ADDRVIEW_H

#include <Event.h>


// Custom resource types that drive the layout of the address record in the 
// Display view mode.
//
// The display of a record can be thought of as follows :
//			an address is layed out in blocks
//			each block comprises of rows
//			each row has one or more fields

#define ViewBlockLayoutRscType		'VBLT'	// This resource contains Block layouts for laying out
															// an address.  The blocks are :
															// 	The address header (name, first name, company, etc)
															// 	The Title (this is separated from the header because we use a 
															//			different font to draw this field - we could combine it with
															//			the header). 
															// 	The Phones 
															//		The Address Body (address, state, city, zip, etc)
															// 	The Custom fields
															//		The Note field
															// The layouts consist of the resource IDs of the 
															// 'VRLT' resources.
															// If a layout needs to specify that at least one field
															// in a row should be present it can do so by specifying
															// the value 0xFFFF (-1) as the next resourceID in layout
															// resource.
															// Multiple layouts can thus be specified - the first defined
															// has the highest priority.
															

#define ViewRowLayoutRscType			'VRLT'	// This resource contains fields that are arranged
															// as rows that can be laid out to form an address
															
#define ViewAlternateLayoutRscType	'VALT'	// This resource is used to choose an alternate VBLT
															// resource if the contents of the fields listed in 
															// this resource can be encoded in the alternate
															// character encoding specified.
															// This is an "optional" resource.



// Constants used by the template layout engine.

#define kMaxPrefixSuffixLen		32				// A prefix or suffix string can be at most 32 bytes including NULL


// Defines for the different sections or "blocks" in the display.
#define kViewBlockLayout_Header		1700		
#define kViewBlockLayout_Phones		1701
#define kViewBlockLayout_Body			1702
#define kViewBlockLayout_Custom		1703
#define kViewBlockLayout_Note			1704


// Constants used by the template layout engine when adding fields to the RecordViewLines. 
#define kViewRecordFieldNum	0
#define kViewRecordPrefix		1
#define kViewRecordSuffix		2

#define kRecordViewLayoutRow_SwitchFont	1		// This is the row number at which the layout engine will switch to 
																// using the user preference font (AddrRecordFont).
// Special resource ID.
#define kSuffixSpaceStrID			1700		// This is the blank space string that will be used
														// in place of a normal suffix when the immediate 
														// next field is empty in a row
														// e.g. if you have 
														//		city, state zip
														// Then, if state is empty we need to replace the 
														// ", " with just a " " between the city and zip


// Typedef and structures used by the template layout engine.

typedef struct ViewFieldLayoutType {
	UInt16 		fieldNum;						// Field number as defined by the AddressFields enum.
	UInt16	 	prefixStrId;					// Id of a tSTR resource that needs to be used as a prefix.
	UInt16		suffixStrId;					// Id of a tSTR resource that needs to be used as a suffix.
} ViewFieldLayoutType;


typedef struct ViewRowLayoutType {
	Int16 					numElements;
	ViewFieldLayoutType  fields[];
} ViewRowLayoutType;

#define kNumMaxRowElements	6

typedef struct ViewRowIndexLayoutType {
	UInt16 rowIndexArr[kNumMaxRowElements];
} ViewRowIndexLayoutType;


typedef struct ViewBlockLayoutType {
	Int16	numLayouts;						// The number of layouts that could be applied
												// The order of the layout is based on highest precendence.
	ViewRowIndexLayoutType	rowIndexLayouts[];
} ViewBlockLayoutType;


typedef struct ViewAlternateListType {
	UInt16	charEncoding;
	UInt16	altResId;
	UInt16	numFields;
	UInt16	fields[];
} ViewAlternateListType;



/************************************************************
 * Function Prototypes
 *************************************************************/

Boolean ViewHandleEvent (EventType * event);

#endif // ADDRVIEW_H
