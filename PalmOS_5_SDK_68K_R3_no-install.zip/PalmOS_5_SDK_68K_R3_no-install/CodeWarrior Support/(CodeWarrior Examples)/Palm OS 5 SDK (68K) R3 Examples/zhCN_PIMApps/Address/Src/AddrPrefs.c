/******************************************************************************
 *
 * Copyright (c) 1995-2003 PalmSource, Inc. All rights reserved.
 *
 * File: AddrPrefs.c
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 * Description:
 *  This is the Address Book application's pref screen
 *
 *****************************************************************************/

#include "AddrPrefs.h"
#include "Address.h"
#include "AddrTools.h"
#include "AddressTransfer.h"
#include "AddrDialList.h"
#include "AddressRsc.h"

#include <ErrorMgr.h>
#include <FeatureMgr.h>

/***********************************************************************
 *
 *	Defines
 *
 ***********************************************************************/

#define addrPrefVersionNum					0x04
#define addrPrefID							0x00


/***********************************************************************
 *
 *	Internal Functions
 *
 ***********************************************************************/

static void PrvPrefsSave (FormPtr frm);
static void PrvPrefsInit (FormPtr frm);


/***********************************************************************
 *
 *   Internal Structures
 *
 ***********************************************************************/

typedef struct {
	UInt16			currentCategory;
	FontID			v20NoteFont;				// For 2.0 compatibility (BGT)
	Boolean			showAllCategories;
	Boolean			saveBackup;
	Boolean			rememberLastCategory;

	// Version 3 preferences
	FontID			addrListFont;
	FontID			addrRecordFont;
	FontID			addrEditFont;
	UInt8 			reserved1;
	UInt32			businessCardRecordID;
	FontID			noteFont;
	UInt8 			reserved2;

	// Version 4 preferences
	Boolean			enableTapDialing;
} AddrPreferenceType;


/***********************************************************************
 *
 * FUNCTION:    AddressLoadPrefs
 *
 * DESCRIPTION: Load the application preferences and fix them up if
 *				there's a version mismatch.
 *
 * PARAMETERS:  appInfoPtr	-- Pointer to the app info structure
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         BGT   1/8/98     Initial revision
 *
 ***********************************************************************/

void PrefsLoad(AddrAppInfoPtr appInfoPtr)
{
	Int16 prefsVersion;
	UInt16 prefsSize;
	AddrPreferenceType prefs;
	UInt32 tem;
		
	NoteFont = AddrListFont =
		(FtrGet(sysFtrCreator, sysFtrDefaultFont, &tem) == 0 ? (FontID) tem : stdFont);

// Do not initialize AddrRecordFont, AddrEditFont using sysFtrDefaultBoldFont - we want it set up as 
// largeBold always.
//	AddrRecordFont = AddrEditFont = 
//		(FtrGet(sysFtrCreator, sysFtrDefaultBoldFont, &tem) == 0 ? (FontID) tem : largeBoldFont);

	// Read the preferences / saved-state information.  There is only one
	// version of the Address Book preferences so don't worry about multiple
	// versions.  Users appreciate the transferal of their preferences from prior
	// versions.
	prefsSize = sizeof (AddrPreferenceType);
	prefsVersion = PrefGetAppPreferences (sysFileCAddress, addrPrefID, &prefs, &prefsSize, true);
	if (prefsVersion > addrPrefVersionNum) {
		prefsVersion = noPreferenceFound;
	}
	if (prefsVersion > noPreferenceFound)
	{
		if (prefsVersion < addrPrefVersionNum) {
			prefs.noteFont = prefs.v20NoteFont;
		}
		SaveBackup = prefs.saveBackup;
		RememberLastCategory = prefs.rememberLastCategory;
		
		NoteFont = prefs.noteFont;
		if (prefsVersion < 3)
		{
			if (prefs.noteFont == largeFont)
				NoteFont = largeBoldFont;
		}

		// If the preferences are set to use the last category and if the
		// category hasn't been deleted then use the last category.
		if (RememberLastCategory &&
			prefs.currentCategory != dmAllCategories &&
			appInfoPtr->categoryLabels[prefs.currentCategory][0] != '\0')
		{
			CurrentCategory = prefs.currentCategory;
			ShowAllCategories = prefs.showAllCategories;
		}

		// Support transferal of preferences from the previous version of the software.
		if (prefsVersion >= 3)
		{
			// Values not set here are left at their default values
			AddrListFont = prefs.addrListFont;
			AddrRecordFont = prefs.addrRecordFont;
			AddrEditFont = prefs.addrEditFont;
			BusinessCardRecordID = prefs.businessCardRecordID;
		}

		// Support transferal of preferences from the previous version of the software.
		if (prefsVersion >= addrPrefVersionNum)
		{
			EnableTapDialing = prefs.enableTapDialing;
		}
	}

	// The first time this app starts register to handle vCard data.
	if (prefsVersion != addrPrefVersionNum)
		TransferRegisterData();

	MemPtrUnlock(appInfoPtr);
}

/***********************************************************************
 *
 * FUNCTION:    AddressSavePrefs
 *
 * DESCRIPTION: Save the Address preferences with fixups so that
 *				previous versions won't go crazy.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         BGT   1/8/98     Initial Revision
 *         SCL   2/12/99    Clear reserved fields before writing saved prefs
 *			  gap  12/06/00	 EnableTapDialing is now false by default, only
 *									 checked if turned on by user
 *
 ***********************************************************************/

void PrefsSave(void)
{
	AddrPreferenceType prefs;

	// Write the preferences / saved-state information.
	prefs.currentCategory = CurrentCategory;
	ErrNonFatalDisplayIf(NoteFont > largeBoldFont, "Note font invalid.");
	prefs.noteFont = NoteFont;
	if (prefs.noteFont > largeFont) {
		prefs.v20NoteFont = stdFont;
	}
	else {
		prefs.v20NoteFont = prefs.noteFont;
	}
	prefs.addrListFont = AddrListFont;
	prefs.addrRecordFont = AddrRecordFont;
	prefs.addrEditFont = AddrEditFont;
	prefs.showAllCategories = ShowAllCategories;
	prefs.saveBackup = SaveBackup;
	prefs.rememberLastCategory = RememberLastCategory;
	prefs.businessCardRecordID = BusinessCardRecordID;
//	if (!DialerPresent)
//		prefs.enableTapDialing = true;	// If we're installing telephony components on a non-telephony ROM, then "EnableTapDialing" check box will be checked by default
//	else
		prefs.enableTapDialing = EnableTapDialing;

	// Clear reserved fields so prefs don't look "different" just from stack garbage!
	prefs.reserved1 = 0;
	prefs.reserved2 = 0;

	// Write the state information.
	PrefSetAppPreferences (sysFileCAddress, addrPrefID, addrPrefVersionNum, &prefs,
						   sizeof (AddrPreferenceType), true);
}


/***********************************************************************
 *
 * FUNCTION:    PrefsHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the "List By
 *              Dialog" of the Address application.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event was handled and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         roger   8/2/95   Initial Revision
 *
 ***********************************************************************/
Boolean PrefsHandleEvent (EventType * event)
{
	Boolean handled = false;
	FormPtr frm;


	if (event->eType == ctlSelectEvent)
	{
		switch (event->data.ctlSelect.controlID)
		{
		case PreferencesOkButton:
			frm = FrmGetActiveForm();
			PrvPrefsSave(frm);
			ToolsLeaveForm();
			handled = true;
			break;

		case PreferencesCancelButton:
			ToolsLeaveForm();
			handled = true;
			break;

		default:
			break;

		}
	}


	else if (event->eType == frmOpenEvent)
	{
		frm = FrmGetActiveForm ();
		PrvPrefsInit (frm);
		FrmDrawForm (frm);
		handled = true;
	}

	return (handled);
}


#pragma mark -

/***********************************************************************
 *
 * FUNCTION:    PrvPrefsInit
 *
 * DESCRIPTION: Initialize the dialog's ui.  Sets the database sort by
 * buttons.
 *
 * PARAMETERS:  frm
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *         Name   Date     	 Description
 *         ----   ----       -----------
 *         roger  08/02/95   Initial Revision
 *         FPa    11/23/00   Added PreferencesEnableTapDialingHeightGadget
 *							 handling
 *
 ***********************************************************************/
void PrvPrefsInit (FormPtr frm)
{
	UInt16 objNumber;
	UInt16 rememberCategoryIndex;
	UInt16 enableTapDialingIndex;

	rememberCategoryIndex = FrmGetObjectIndex (frm, PreferencesRememberCategoryCheckbox);
	CtlSetValue(FrmGetObjectPtr (frm, rememberCategoryIndex), RememberLastCategory);

	enableTapDialingIndex = FrmGetObjectIndex (frm, PreferencesEnableTapDialingCheckbox);
	
	if (!ToolsIsDialerPresent())
	{
		ControlType* enableTapDialingP;
		Coord x,y;
		UInt16 numberOfObjects;
		UInt16 index;
		RectangleType rect;
		WinHandle windowH;
		UInt16 enableTapDialingHeightIndex;
		UInt16 prefsHeightDelta;
	
		enableTapDialingHeightIndex = FrmGetObjectIndex (frm, PreferencesEnableTapDialingHeightGadget);
	
		// Hide "Enable tap-dialing" control
		enableTapDialingP = FrmGetObjectPtr (frm, enableTapDialingIndex);
		CtlHideControl(enableTapDialingP);

		// Move "Remember last category" control down
		FrmGetObjectPosition(frm, enableTapDialingIndex, &x, &y);
		FrmSetObjectPosition(frm, rememberCategoryIndex, x, y);

		// Change form size
		FrmGetObjectBounds(frm, enableTapDialingHeightIndex, &rect);	// PreferencesEnableTapDialingHeightGadget goal is only to provide the number of pixel that we should used to move all components up when Dial App is not active
		prefsHeightDelta = rect.extent.y;
		windowH = FrmGetWindowHandle(frm);
		WinSetDrawWindow(windowH);
		WinGetDrawWindowBounds(&rect);
		rect.topLeft.y += prefsHeightDelta;
		rect.extent.y -= prefsHeightDelta;
		WinSetWindowBounds(windowH, &rect);


		// Move all controls up
		numberOfObjects = FrmGetNumberOfObjects(frm);
		for (index = 0 ; index < numberOfObjects ; index++)
		{
			FrmGetObjectBounds(frm, index, &rect);
			rect.topLeft.y -= prefsHeightDelta;
			FrmSetObjectBounds(frm, index, &rect);
		}
	}
	else
		// Check or uncheck "Enable Tap Dialing" checkbox
		CtlSetValue(FrmGetObjectPtr (frm, enableTapDialingIndex), EnableTapDialing);



	// Set the current sort by setting
	if (SortByCompany)
		objNumber = PreferencesCompanyName;
	else
		objNumber = PreferencesLastName;

	CtlSetValue(FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, objNumber)),
				true);

}


/***********************************************************************
 *
 * FUNCTION:    PrvPrefsSave
 *
 * DESCRIPTION: Write the renamed field labels
 *
 * PARAMETERS:  frm
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *				Name		Date		Description
 *				----		----		-----------
 *				roger		8/2/95	Initial Revision
 *				jmp		11/02/99	Don't reset CurrentRecord to zero if it's been set to
 *										noRecord.  Fixes bug #23571.
 *				gap		10/27/00	actually, when the records are resorted, the current
 *										selection should always be cleared.
 *
 ***********************************************************************/
void PrvPrefsSave (FormPtr frm)
{
	FormPtr curFormP;
	FormPtr formP;
	Boolean sortByCompany;

	RememberLastCategory = CtlGetValue(FrmGetObjectPtr (frm,
														FrmGetObjectIndex (frm, PreferencesRememberCategoryCheckbox)));

	EnableTapDialing = CtlGetValue(FrmGetObjectPtr (frm,
													FrmGetObjectIndex (frm, PreferencesEnableTapDialingCheckbox)));

	sortByCompany = CtlGetValue(FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, PreferencesCompanyName)));

	if (sortByCompany != SortByCompany)
	{
		// Put up the sorting message dialog so the user knows what's going on
		// while the sort locks up the device.
		curFormP = FrmGetActiveForm ();
		formP = FrmInitForm (SortingMessageDialog);
		FrmSetActiveForm (formP);
		FrmDrawForm (formP);

		// Peform the sort.
		SortByCompany = sortByCompany;
		AddrDBChangeSortOrder(AddrDB, SortByCompany);
		
		// clear the current selection 
		CurrentRecord = noRecord;
		TopVisibleRecord = 0;
		
		// post an event to update the form
		FrmUpdateForm (ListView, updateRedrawAll);

		// Remove the sorting message.
		FrmEraseForm (formP);
		FrmDeleteForm (formP);
		FrmSetActiveForm (curFormP);
	}
}
