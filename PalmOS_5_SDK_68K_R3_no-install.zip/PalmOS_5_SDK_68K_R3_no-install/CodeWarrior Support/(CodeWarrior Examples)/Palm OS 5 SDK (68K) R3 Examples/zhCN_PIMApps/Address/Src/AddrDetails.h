/******************************************************************************
 *
 * Copyright (c) 1995-2003 PalmSource, Inc. All rights reserved.
 *
 * File: AddrDetails.h
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 *****************************************************************************/

#ifndef ADDRDETAILS_H
#define ADDRDETAILS_H

#include <Event.h>


/************************************************************
 * Function Prototypes
 *************************************************************/

Boolean DetailsHandleEvent (EventType * event);
Boolean DetailsDeleteRecord (void);

#endif // ADDRDETAILS_H
