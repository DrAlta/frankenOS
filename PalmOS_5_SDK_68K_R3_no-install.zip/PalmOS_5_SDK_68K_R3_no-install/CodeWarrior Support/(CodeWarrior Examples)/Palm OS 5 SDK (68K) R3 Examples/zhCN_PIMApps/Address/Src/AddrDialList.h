/******************************************************************************
 *
 * Copyright (c) 1995-2003 PalmSource, Inc. All rights reserved.
 *
 * File: AddrDialList.h
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 *****************************************************************************/

#ifndef ADDRDIALLIST_H
#define ADDRDIALLIST_H

#include <Event.h>

#include "AddressDB.h"


/************************************************************
 * Function Prototypes
 *************************************************************/

Boolean DialListShowDialog( UInt16 recordIndex, UInt16 phoneIndex, UInt16 lineIndex );
Boolean DialListHandleEvent( EventType * event );


#endif // ADDRDIALLIST_H
