/******************************************************************************
 *
 * Copyright (c) 1995-2003 PalmSource, Inc. All rights reserved.
 *
 * File: ToDoRelPrefix.h
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 *****************************************************************************/

//#include <BuildDefines.h>
//#include <MemCheckBuildDefines.h>

#define ERROR_CHECK_LEVEL	ERROR_CHECK_NONE
#define MEM_CHECK_LEVEL		MEM_CHECK_NONE
#define TRACE_OUTPUT		TRACE_OUTPUT_OFF

//#include <BuildDefaults.h>
//#include <MemCheckBuildDefault.h>
