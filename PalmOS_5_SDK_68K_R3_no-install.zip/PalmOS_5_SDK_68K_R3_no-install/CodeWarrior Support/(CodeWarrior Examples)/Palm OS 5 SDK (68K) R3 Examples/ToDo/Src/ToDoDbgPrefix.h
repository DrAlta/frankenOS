/******************************************************************************
 *
 * Copyright (c) 1995-2002 PalmSource, Inc. All rights reserved.
 *
 * File: ToDoDbgPrefix.h
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 *****************************************************************************/

//#include <BuildDefines.h>
//#include <MemCheckBuildDefines.h>

#define ERROR_CHECK_LEVEL	ERROR_CHECK_FULL
#define MEM_CHECK_LEVEL		MEM_CHECK_FULL
#define TRACE_OUTPUT		TRACE_OUTPUT_ON

//#include <BuildDefaults.h>
//#include <MemCheckBuildDefault.h>

//#include <MemCheckMgr.h>
