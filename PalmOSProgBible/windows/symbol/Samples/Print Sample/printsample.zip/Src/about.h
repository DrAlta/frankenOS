/************************************************************************
* COPYRIGHT:   Copyright  �  1999 Symbol Technologies, Inc. 
*
* FILE:        about.h
*
* SYSTEM:      Symbol Print API for Palm III.
* 
*
* DESCRIPTION: Provides a sample application for the Symbol Print API.*
*
* HISTORY:     03/22/99    MS   Created
*              ...
*************************************************************************/
#pragma once

Boolean AboutHandleEvent( EventPtr pEvent );

